#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LITEPICK PRO Bot v14.1-stamina — Local-first IconCaptcha + multi-account ready

- Shared SQLite IC memory (ko'p papka / 100+ akk bir xil o'rganadi)
- Local frequency solver (Pillow) birinchi — Gemini faqat fallback
- Success da DB ga yozadi → keyin AI kam ishlatiladi
- Cookie auto-save, countdown, TG, continuous loop
- config_litepick.json  |  ixtiyoriy accounts[]  |  ic_db yo'li
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import os
import random
import re
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from typing import Optional

try:
    import requests
except ImportError:
    print("pip install requests")
    raise SystemExit(1)

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

HOST = "https://litepick.io/"
HCAPTCHA_KEY = "6ef421cc-2fbc-493a-96ec-550c43f8ecd2"
RECAPTCHA_KEY = "6LcqLB8rAAAAAGxzcVp9W7i4uSZHr-DmHvWQb-KO"
IC_ENDPOINT = HOST + "iconcaptcha.php"
BASE = Path(__file__).resolve().parent
CFG_PATH = BASE / "config_litepick.json"
COOKIE_FILE = BASE / "cookie_ltc.txt"
STATS_PATH = BASE / "stats_litepick.json"

# Umumiy o'rganish bazasi (barcha hisoblar ulashadi)
def default_ic_db() -> Path:
    for p in (
        Path(os.environ.get("IC_DB", "")),
        Path("/sdcard/pul/caps/ic_shared.db"),
        Path("/storage/emulated/0/pul/caps/ic_shared.db"),
        BASE.parent / "ic_shared.db",
        BASE / "ic_shared.db",
    ):
        if str(p) in ("", "."):
            continue
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            return p
        except Exception:
            continue
    return BASE / "ic_shared.db"


DEFAULT_CFG = {
    "cookie": "",
    "email": "",
    "password": "",
    "totp_secret": "",
    "user_agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "wallet": "",
    "auto_withdraw": "0",
    "min_withdraw": 0.1,
    "gemini_api_keys": [],
    "openrouter_api_keys": [],
    "xevil_apikey": "",
    "tg_bot_token": "",
    "tg_chat_id": "",
    "tz": "Asia/Tashkent",
    "no_proxy": True,
    "proxy": "",
    "ic_db": "",  # bo'sh = avto /sdcard/pul/caps/ic_shared.db
    "accounts": [],
    "dice_min_bet": 0.0001,
    "dice_min_balance": 0.005,
    "dice_payout": 1.01,
    "dice_session_bets": 15,
    "dice_daily_cap": 0,  # 0 → random 100-350 per day
    "dice_enabled": 1,  # 0=random 100-350,
}

UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
]


def load_cfg() -> dict:
    cfg = dict(DEFAULT_CFG)
    if CFG_PATH.is_file():
        try:
            j = json.loads(CFG_PATH.read_text(encoding="utf-8"))
            if isinstance(j, dict):
                cfg.update(j)
        except Exception as e:
            print(f" config read error: {e}")
    # Cookie: faqat haqiqiy qiymat (manager bo'sh string yozishi mumkin)
    ck = (cfg.get("cookie") or "").strip()
    if ck in ("", "null", "None", "none"):
        cfg["cookie"] = ""
        if COOKIE_FILE.is_file():
            try:
                c = COOKIE_FILE.read_text(encoding="utf-8").strip().splitlines()[0].strip()
                if c and c not in ("null", "None"):
                    cfg["cookie"] = c
            except Exception:
                pass
    else:
        cfg["cookie"] = ck
    for ek, ck in (
        ("LOGIN_EMAIL", "email"),
        ("LOGIN_PASSWORD", "password"),
        ("COOKIE", "cookie"),
        ("TG_BOT_TOKEN", "tg_bot_token"),
        ("TG_CHAT_ID", "tg_chat_id"),
        ("XEVIL_API_KEY", "xevil_apikey"),
        ("XEVIL_APIKEY", "xevil_apikey"),
        ("USER_AGENT", "user_agent"),
        ("IC_DB", "ic_db"),
    ):
        v = os.environ.get(ek, "").strip()
        if v:
            cfg[ck] = v
    for ek, ck in (("GEMINI_API_KEY", "gemini_api_keys"), ("OPENROUTER_API_KEY", "openrouter_api_keys")):
        v = os.environ.get(ek, "").strip()
        if v:
            extra = [x.strip() for x in v.split(",") if x.strip()]
            cfg[ck] = list(dict.fromkeys(list(cfg.get(ck) or []) + extra))
    if not cfg.get("user_agent"):
        seed = (cfg.get("cookie") or "") + (cfg.get("email") or "")
        cfg["user_agent"] = UA_POOL[int(abs(hash(seed))) % len(UA_POOL)]
    return cfg


def save_cfg(cfg: dict) -> None:
    try:
        out = {k: v for k, v in cfg.items() if k != "accounts" or v}
        CFG_PATH.write_text(json.dumps(out, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f" config save: {e}")


def now_str(cfg: dict) -> str:
    try:
        from datetime import datetime
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo(cfg.get("tz") or "Asia/Tashkent")).strftime("%Y-%m-%d %H:%M:%S") + " UZT"
    except Exception:
        return time.strftime("%Y-%m-%d %H:%M:%S")


class C:
    R, B, RED, GRN, YEL, CYN, W, BG = (
        "\033[0m", "\033[1m", "\033[91m", "\033[92m", "\033[93m", "\033[96m", "\033[97m", "\033[44m",
    )


def banner():
    print(f"{C.BG}{C.W}{C.B}{'  LITEPICK PRO  v14.1  ·  Site DB · email login · IC local  ':^48}{C.R}")
    print(f"{C.CYN}┌{'─'*46}┐{C.R}")
    print(f"{C.CYN}│{C.R}  Local IC+pCap · learn · save API   {C.CYN}│{C.R}")
    print(f"{C.CYN}└{'─'*46}┘{C.R}")


def info(k, v): print(f" {C.GRN}[{C.W}{k:<10}{C.GRN}]{C.R} {v}")
def ok(m): print(f" {C.GRN}[✓]{C.R} {m}")
def err(m): print(f" {C.RED}[!]{C.R} {m}")
def warn(m): print(f" {C.YEL}[!]{C.R} {m}")
def line(): print(f"{C.CYN}{'─'*48}{C.R}")


def tg_send(cfg: dict, text: str) -> bool:
    token = (cfg.get("tg_bot_token") or "").strip()
    chat = (cfg.get("tg_chat_id") or "").strip()
    if not token or not chat:
        return False
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data={"chat_id": chat, "text": text, "parse_mode": "HTML", "disable_web_page_preview": "1"},
            timeout=20,
        )
        return bool(r.json().get("ok"))
    except Exception:
        return False


def tg_start(cfg, user, bal, db_path: str):
    g, o = len(cfg.get("gemini_api_keys") or []), len(cfg.get("openrouter_api_keys") or [])
    tg_send(
        cfg,
        "🚀 <b>LITEPICK PRO v13 — START</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <code>{user or '—'}</code>\n💰 <code>{bal} LTC</code>\n"
        f"🧩 Gemini:{g} · OR:{o} · Local:{'PIL' if HAS_PIL else 'off'}\n"
        f"🗄 <code>{db_path}</code>\n⏰ {now_str(cfg)}\n"
        "━━━━━━━━━━━━━━━━━━━━\n✅ Bot ishga tushdi",
    )


def tg_claim(cfg, user, bal, cap, result, stats):
    goal, done = 24, int(stats.get("claims_today") or 0)
    filled = int(round(min(goal, done) / max(1, goal) * 12))
    bar = "█" * filled + "░" * (12 - filled)
    pct = int(round(min(goal, done) / max(1, goal) * 100))
    tg_send(
        cfg,
        "🚀 <b>LITEPICK — Claim Success</b>\n━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 <code>{user}</code>\n💰 <code>{bal} LTC</code>\n🧩 {cap}\n✅ {result}\n"
        "━━━━━━━━━━━━━━━━━━━━\n"
        f"📊 {done}/{goal} ({pct}%)\n📈 <code>[{bar}]</code>\n"
        f"📦 {int(stats.get('total_claims') or 0)} · ❌ {int(stats.get('fails_today') or 0)}\n"
        f"⏰ {now_str(cfg)}",
    )


def tg_fail(cfg, msg):
    tg_send(cfg, f"⚠️ <b>LITEPICK</b>\n<code>{msg[:350]}</code>\n⏰ {now_str(cfg)}")


def load_stats() -> dict:
    today = time.strftime("%Y-%m-%d")
    d = {"day": today, "claims_today": 0, "fails_today": 0, "total_claims": 0}
    if STATS_PATH.is_file():
        try:
            j = json.loads(STATS_PATH.read_text(encoding="utf-8"))
            if isinstance(j, dict):
                d.update(j)
        except Exception:
            pass
    if d.get("day") != today:
        d.update({"day": today, "claims_today": 0, "fails_today": 0, "dice_today": 0, "skips_today": 0})
    return d


def save_stats(s: dict):
    try:
        STATS_PATH.write_text(json.dumps(s, indent=2), encoding="utf-8")
    except Exception:
        pass


# ─── Shared SQLite IC memory ──────────────────────────
class ICStore:
    """Barcha akkauntlar bir DB dan o'rganadi — JSON dan tezroq."""

    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), timeout=30, check_same_thread=False)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS ic_solve (
                img_hash TEXT PRIMARY KEY,
                idx INTEGER NOT NULL,
                n_icons INTEGER NOT NULL,
                source TEXT,
                hits INTEGER DEFAULT 1,
                ts INTEGER
            )"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS pc_solve (
                q_hash TEXT PRIMARY KEY,
                question TEXT,
                boxes TEXT NOT NULL,
                source TEXT,
                hits INTEGER DEFAULT 1,
                ts INTEGER
            )"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS ai_cache (
                key_hash TEXT PRIMARY KEY,
                kind TEXT,
                answer TEXT NOT NULL,
                hits INTEGER DEFAULT 1,
                ts INTEGER
            )"""
        )
        self.conn.execute(
            """CREATE TABLE IF NOT EXISTS ic_stats (
                k TEXT PRIMARY KEY,
                v INTEGER
            )"""
        )
        self.conn.commit()
        n = self.count()
        npc = 0
        try:
            npc = int(self.conn.execute("SELECT COUNT(*) FROM pc_solve").fetchone()[0])
        except Exception:
            pass
        info("IC DB", f"{self.path} (IC:{n} pCap:{npc})")

    def count(self) -> int:
        try:
            return int(self.conn.execute("SELECT COUNT(*) FROM ic_solve").fetchone()[0])
        except Exception:
            return 0

    def lookup(self, img_hash: str) -> Optional[tuple]:
        row = self.conn.execute(
            "SELECT idx, n_icons FROM ic_solve WHERE img_hash=?", (img_hash,)
        ).fetchone()
        if row:
            self.conn.execute(
                "UPDATE ic_solve SET hits=hits+1, ts=? WHERE img_hash=?",
                (int(time.time()), img_hash),
            )
            self.conn.commit()
            return int(row[0]), int(row[1])
        return None

    def save(self, img_hash: str, idx: int, n: int, source: str):
        self.conn.execute(
            """INSERT INTO ic_solve (img_hash, idx, n_icons, source, hits, ts)
               VALUES (?,?,?,?,1,?)
               ON CONFLICT(img_hash) DO UPDATE SET
                 idx=excluded.idx, n_icons=excluded.n_icons,
                 source=excluded.source, hits=hits+1, ts=excluded.ts""",
            (img_hash, idx, n, source, int(time.time())),
        )
        self.conn.commit()

    def forget(self, img_hash: str):
        """Noto'g'ri yechim — DB dan o'chirish."""
        try:
            self.conn.execute("DELETE FROM ic_solve WHERE img_hash=?", (img_hash,))
            self.conn.commit()
        except Exception:
            pass

    @staticmethod
    def qhash(question: str, img_bytes: bytes = b"") -> str:
        q = re.sub(r"\s+", " ", (question or "").strip().lower())
        # rasm + savol — bir xil savol turli rasm bo'lishi mumkin
        raw = q.encode() + b"|" + (img_bytes[:2048] if img_bytes else b"")
        return hashlib.sha256(raw).hexdigest()[:32]

    def pc_lookup(self, question: str, img_bytes: bytes) -> Optional[list]:
        h = self.qhash(question, img_bytes)
        row = self.conn.execute(
            "SELECT boxes FROM pc_solve WHERE q_hash=?", (h,)
        ).fetchone()
        if row:
            self.conn.execute(
                "UPDATE pc_solve SET hits=hits+1, ts=? WHERE q_hash=?",
                (int(time.time()), h),
            )
            self.conn.commit()
            try:
                boxes = json.loads(row[0])
                if isinstance(boxes, list) and boxes:
                    return [int(x) for x in boxes]
            except Exception:
                pass
        # faqat savol bo'yicha (zaifroq match)
        qn = re.sub(r"\s+", " ", (question or "").strip().lower())
        if len(qn) > 8:
            rows = self.conn.execute(
                "SELECT boxes, question FROM pc_solve WHERE question=?", (qn,)
            ).fetchall()
            if len(rows) == 1:
                try:
                    return [int(x) for x in json.loads(rows[0][0])]
                except Exception:
                    pass
        return None

    def pc_save(self, question: str, img_bytes: bytes, boxes: list, source: str):
        h = self.qhash(question, img_bytes)
        qn = re.sub(r"\s+", " ", (question or "").strip().lower())
        self.conn.execute(
            """INSERT INTO pc_solve (q_hash, question, boxes, source, hits, ts)
               VALUES (?,?,?,?,1,?)
               ON CONFLICT(q_hash) DO UPDATE SET
                 boxes=excluded.boxes, source=excluded.source,
                 hits=hits+1, ts=excluded.ts""",
            (h, qn, json.dumps(sorted(set(int(x) for x in boxes))), source, int(time.time())),
        )
        self.conn.commit()

    def ai_cache_get(self, key: str) -> Optional[str]:
        row = self.conn.execute(
            "SELECT answer FROM ai_cache WHERE key_hash=?", (key,)
        ).fetchone()
        if row:
            self.conn.execute(
                "UPDATE ai_cache SET hits=hits+1, ts=? WHERE key_hash=?",
                (int(time.time()), key),
            )
            self.conn.commit()
            return row[0]
        return None

    def ai_cache_set(self, key: str, kind: str, answer: str):
        self.conn.execute(
            """INSERT INTO ai_cache (key_hash, kind, answer, hits, ts)
               VALUES (?,?,?,1,?)
               ON CONFLICT(key_hash) DO UPDATE SET
                 answer=excluded.answer, hits=hits+1, ts=excluded.ts""",
            (key, kind, answer, int(time.time())),
        )
        self.conn.commit()


def img_bytes_from_b64(img_b64: str) -> bytes:
    if "," in img_b64[:80]:
        img_b64 = img_b64.split(",", 1)[1]
    return base64.b64decode(img_b64)


def img_hash_b64(img_b64: str) -> str:
    return hashlib.sha256(img_bytes_from_b64(img_b64)).hexdigest()[:32]


def _tile_sig(im: "Image.Image", size: int = 10) -> str:
    """Yengil perceptual signature — getdata o'rniga load."""
    g = im.convert("L").resize((size, size), Image.Resampling.BILINEAR)
    pix = g.load()
    vals = [pix[x, y] for y in range(size) for x in range(size)]
    avg = sum(vals) / len(vals)
    bits = "".join("1" if v >= avg else "0" for v in vals)
    # coarse histogram 4 bands
    hist = [0, 0, 0, 0]
    for v in vals:
        hist[min(3, v // 64)] += 1
    return hashlib.md5((bits + str(hist)).encode()).hexdigest()[:16]


def _sig_close(a: str, b: str, max_diff: int = 3) -> bool:
    if a == b:
        return True
    # compare underlying by re-hash is hard; use hex distance on first part
    return sum(x != y for x, y in zip(a, b)) <= max_diff


def local_least_candidates(img_b64: str) -> list:
    """[(idx, n, score), ...] eng yaxshidan yomonroqqa. Kamida 1 ta."""
    if not HAS_PIL:
        return []
    try:
        raw = img_bytes_from_b64(img_b64)
        im = Image.open(io.BytesIO(raw))
        if im.mode in ("P", "RGBA"):
            im = im.convert("RGBA").convert("RGB")
        else:
            im = im.convert("RGB")
        w, h = im.size
        ranked = []
        for n in (5, 6, 7, 8):
            cw = w // n
            if cw < 14:
                continue
            sigs = []
            for i in range(n):
                x0 = i * cw
                x1 = (i + 1) * cw if i < n - 1 else w
                tile = im.crop((x0, 2, x1, h - 2 if h > 8 else h))
                sigs.append(_tile_sig(tile))
            groups: list[dict] = []
            for i, s in enumerate(sigs):
                placed = False
                for g in groups:
                    if _sig_close(s, g["s"]):
                        g["idxs"].append(i)
                        placed = True
                        break
                if not placed:
                    groups.append({"s": s, "idxs": [i]})
            counts = {i: 1 for i in range(n)}
            for g in groups:
                c = len(g["idxs"])
                for i in g["idxs"]:
                    counts[i] = c
            min_c = min(counts.values())
            cands = [i for i, c in counts.items() if c == min_c]
            unique = (min_c == 1 and len(cands) == 1)
            for idx in cands:
                # past ball = yaxshiroq
                score = (0 if unique else 1, min_c, len(cands), abs(n - 6))
                ranked.append((score, idx, n))
        ranked.sort(key=lambda x: x[0])
        out, seen = [], set()
        for _, idx, n in ranked:
            key = (idx, n)
            if key not in seen:
                seen.add(key)
                out.append((idx, n))
        return out[:6]
    except Exception as e:
        warn(f"Local IC: {e}")
        return []


def local_least_index(img_b64: str) -> Optional[tuple]:
    """(index, n_icons) — eng yaxshi nomzod."""
    c = local_least_candidates(img_b64)
    return c[0] if c else None


# ─── Vision AI (fallback only) ────────────────────────
class VisionAI:
    def __init__(self, cfg: dict):
        self.gemini = [k for k in (cfg.get("gemini_api_keys") or []) if k]
        self.openrouter = [k for k in (cfg.get("openrouter_api_keys") or []) if k]
        info("VisionAI", f"Gemini={len(self.gemini)} OR={len(self.openrouter)} PIL={HAS_PIL}")

    def _gemini(self, parts, max_tok=80) -> Optional[str]:
        for key in self.gemini:
            for model in ("gemini-flash-latest", "gemini-2.0-flash", "gemini-1.5-flash"):
                try:
                    r = requests.post(
                        f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={key}",
                        json={
                            "contents": [{"parts": parts}],
                            "generationConfig": {"temperature": 0.05, "maxOutputTokens": max_tok},
                        },
                        timeout=50,
                    )
                    j = r.json()
                    if j.get("error"):
                        if j["error"].get("code") == 429 or "quota" in str(j["error"]).lower():
                            warn("Gemini quota → next")
                            break
                        continue
                    t = ((j.get("candidates") or [{}])[0].get("content") or {}).get("parts", [{}])[0].get("text", "")
                    if (t or "").strip():
                        return t.strip()
                except Exception:
                    continue
        return None

    def _openrouter(self, parts) -> Optional[str]:
        content = []
        for p in parts:
            if "text" in p:
                content.append({"type": "text", "text": p["text"]})
            if "inline_data" in p:
                mime = p["inline_data"].get("mime_type", "image/png")
                data = p["inline_data"]["data"]
                content.append({"type": "image_url", "image_url": {"url": f"data:{mime};base64,{data}"}})
        for key in self.openrouter:
            for model in ("google/gemini-2.0-flash-001", "google/gemini-flash-1.5", "qwen/qwen-2.5-vl-7b-instruct"):
                try:
                    r = requests.post(
                        "https://openrouter.ai/api/v1/chat/completions",
                        headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                        json={"model": model, "messages": [{"role": "user", "content": content}], "temperature": 0.05, "max_tokens": 80},
                        timeout=55,
                    )
                    t = ((r.json().get("choices") or [{}])[0].get("message") or {}).get("content", "")
                    if (t or "").strip():
                        return t.strip()
                except Exception:
                    continue
        return None

    def ask(self, parts, max_tok=80) -> Optional[str]:
        return self._gemini(parts, max_tok) or self._openrouter(parts)

    def icon_index(self, img_b64: str, n_hint: int = 8, cache=None) -> Optional[tuple]:
        b64 = img_b64.split(",", 1)[1] if "," in img_b64[:50] else img_b64
        key = hashlib.sha256(b64[:2000].encode() if isinstance(b64, str) else b64[:2000]).hexdigest()[:32]
        if cache is not None:
            hit = cache.ai_cache_get(key)
            if hit and hit.isdigit():
                idx = int(hit)
                ok(f"IC AI-cache → i={idx}")
                return idx, max(idx + 1, 5)
        prompt = (
            "IconCaptcha: select the image shown the LEAST number of times "
            "(or the odd one out). Icons are in a horizontal row, count 5 to 8.\n"
            f"Often about {n_hint} icons. Reply ONLY one digit: 0-based index "
            "(leftmost=0). Example: 2"
        )
        t = self.ask(
            [{"text": prompt}, {"inline_data": {"mime_type": "image/png", "data": b64}}],
            12,
        )
        if not t:
            return None
        m = re.search(r"[0-7]", t)
        if not m:
            return None
        idx = int(m.group(0))
        if cache is not None:
            try:
                cache.ai_cache_set(key, "icon", str(idx))
            except Exception:
                pass
        return idx, max(idx + 1, 5)

    def pcaptcha_boxes(self, question: str, img: bytes, cache=None) -> Optional[list]:
        key = hashlib.sha256(
            (question or "").encode() + b"|" + img[:1500]
        ).hexdigest()[:32]
        if cache is not None:
            hit = cache.ai_cache_get(key)
            if hit:
                try:
                    nums = [int(x) for x in hit.split(",") if x.strip().isdigit()]
                    if nums:
                        ok(f"pCaptcha AI-cache → {nums}")
                        return nums
                except Exception:
                    pass
        prompt = (
            "This is a 3x3 image grid captcha (cells numbered 1-9 left-to-right, top-to-bottom).\n"
            f"Question: {question}\n"
            "If it asks for a PATH/road/trail, list ALL cells that form the continuous path.\n"
            "If it asks for objects matching a description, list those cells.\n"
            "Reply ONLY numbers 1-9 separated by commas. Example: 2,5,8"
        )
        t = self.ask(
            [
                {"text": prompt},
                {"inline_data": {"mime_type": "image/png", "data": base64.b64encode(img).decode()}},
            ],
            40,
        )
        if not t:
            return None
        nums = sorted(set(int(x) for x in re.findall(r"[1-9]", t)))
        if nums and cache is not None:
            try:
                cache.ai_cache_set(key, "pcaptcha", ",".join(str(x) for x in nums))
            except Exception:
                pass
        return nums or None


class Xevil:
    def __init__(self, key: str):
        self.key = (key or "").strip()
        if self.key and "|SOFTID" not in self.key:
            self.key += "|SOFTID1204538927"

    @property
    def ok(self):
        return bool(self.key)

    def solve(self, method: str, sitekey: str, pageurl: str, timeout: int = 100) -> Optional[str]:
        if not self.ok:
            return None
        try:
            j = requests.get(
                "https://sctg.xyz/in.php",
                params={"key": self.key, "method": method, "sitekey": sitekey, "pageurl": pageurl, "json": 1},
                timeout=35,
            ).json()
            if not j.get("status"):
                warn(f"Xevil: {j}")
                return None
            tid, t0 = j["request"], time.time()
            while time.time() - t0 < timeout:
                time.sleep(4)
                rr = requests.get(
                    "https://sctg.xyz/res.php",
                    params={"key": self.key, "action": "get", "id": tid, "json": 1},
                    timeout=25,
                ).json()
                req = rr.get("request", "")
                if req in ("CAPCHA_NOT_READY", "CAPTCHA_NOT_READY"):
                    continue
                if rr.get("status") and req:
                    return req
                return None
        except Exception as e:
            warn(f"Xevil: {e}")
        return None

    def recaptcha(self, url: str) -> Optional[str]:
        info("Captcha", "reCAPTCHA (Xevil)")
        t = self.solve("userrecaptcha", RECAPTCHA_KEY, url)
        if t:
            ok("reCAPTCHA ok")
        return t

    def hcaptcha(self, url: str) -> Optional[str]:
        info("Captcha", "hCaptcha (Xevil)")
        t = self.solve("hcaptcha", HCAPTCHA_KEY, url)
        if t:
            ok("hCaptcha ok")
        return t


class Bot:
    def __init__(self, cfg: dict, ic_store: ICStore):
        self.cfg = cfg
        self.ic = ic_store
        self.s = requests.Session()
        self.s.trust_env = False
        proxy = (cfg.get("proxy") or "").strip()
        if cfg.get("no_proxy") in (True, "1", 1, "true", "True"):
            proxy = ""
            for k in ("HTTP_PROXY", "HTTPS_PROXY", "http_proxy", "https_proxy", "ALL_PROXY", "all_proxy"):
                os.environ.pop(k, None)
        if proxy:
            self.s.proxies.update({"http": proxy, "https": proxy})
        else:
            self.s.proxies.clear()

        self.ua = cfg.get("user_agent") or DEFAULT_CFG["user_agent"]
        self.cookie = (cfg.get("cookie") or "").strip()
        self.s.headers.update({"User-Agent": self.ua, "Accept-Language": "en-US,en;q=0.9", "Origin": HOST.rstrip("/")})
        if self.cookie:
            self.s.headers["Cookie"] = self.cookie
        self.vision = VisionAI(cfg)
        self.xevil = Xevil(cfg.get("xevil_apikey") or "")
        try:
            import urllib3
            urllib3.disable_warnings()
        except Exception:
            pass

    def _merge(self, r: requests.Response):
        parts = {}
        if self.cookie:
            for p in self.cookie.split(";"):
                p = p.strip()
                if "=" in p:
                    k, v = p.split("=", 1)
                    parts[k.strip()] = v.strip()
        for c in r.cookies:
            parts[c.name] = c.value
        self.cookie = "; ".join(f"{k}={v}" for k, v in parts.items())
        self.s.headers["Cookie"] = self.cookie
        self.cfg["cookie"] = self.cookie
        if (
            "user_session=" in self.cookie
            or "remember_token=" in self.cookie
            or "adbit_session=" in self.cookie
            or len(self.cookie) > 20
        ):
            try:
                save_cfg(self.cfg)
            except Exception:
                pass
            try:
                COOKIE_FILE.write_text(self.cookie + "\n", encoding="utf-8")
            except Exception:
                pass

    def csrf(self) -> str:
        m = re.search(r"csrf_cookie_name=([^;\s]+)", self.cookie or "")
        return m.group(1) if m else ""

    def get(self, path: str) -> str:
        url = path if path.startswith("http") else HOST + path.lstrip("/")
        r = self.s.get(url, timeout=90, verify=False)
        self._merge(r)
        return r.text

    def post(self, path: str, data: dict, referer: str = "faucet.php") -> str:
        url = path if path.startswith("http") else HOST + path.lstrip("/")
        r = self.s.post(
            url,
            data=data,
            headers={
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                "X-Requested-With": "XMLHttpRequest",
                "Referer": HOST + referer,
                "Accept": "application/json, text/javascript, */*; q=0.01",
            },
            timeout=90,
            verify=False,
        )
        self._merge(r)
        return r.text

    def _parse_profile(self, body: str) -> tuple:
        user = bal = ""
        for pat in (
            r'class="profile-name">\s*([^<]+)',
            r"class='profile-name'>\s*([^<]+)",
            r'class="[^"]*profile-name[^"]*"[^>]*>\s*([^<]+)',
        ):
            m = re.search(pat, body, re.I)
            if m:
                u = re.sub(r"\s+", " ", m.group(1)).strip()
                if u and u.lower() not in ("profile", "user", "login", "logout"):
                    user = u
                    break
        for pat in (
            r'class="[^"]*user_balance[^"]*"[^>]*>\s*([0-9.]+)',
            r'user_balance">\s*([0-9.]+)',
            r'user_balance[^>]*>\s*([0-9.]+)',
            r'([0-9]+\.[0-9]{4,10})\s*TON',
        ):
            m = re.search(pat, body, re.I)
            if m:
                bal = m.group(1).strip()
                break
        return user, bal

    def dashboard(self) -> dict:
        bodies = []
        for path in ("", "faucet.php"):
            try:
                bodies.append(self.get(path))
            except Exception:
                pass
        user = bal = ""
        body = bodies[0] if bodies else ""
        for b in bodies:
            u, bb = self._parse_profile(b)
            if u and not user:
                user = u
            if bb and (not bal or bal == "0"):
                bal = bb
            if u or bb:
                body = b
        low = (body or "").lower()
        has_auth = "remember_token=" in (self.cookie or "") or "adbit_session=" in (self.cookie or "")
        logged = bool(user) or (
            has_auth
            and ("profile-name" in low or "user_balance" in low or "logout" in low or "select_captcha" in low)
        )
        return {"username": user, "balance": bal or "0", "body": body, "logged": logged or bool(user)}


    def totp_code(self) -> str:
        """Authenticator 6 xonali kod — cfg totp_secret dan."""
        secret = (self.cfg.get("totp_secret") or "").strip().replace(" ", "")
        if not secret:
            return ""
        # otpauth URI
        if secret.lower().startswith("otpauth://"):
            m = re.search(r"[?&]secret=([A-Z2-7]+)", secret, re.I)
            if m:
                secret = m.group(1)
            else:
                return ""
        secret = secret.upper().replace("-", "")
        try:
            import pyotp
            return pyotp.TOTP(secret).now()
        except ImportError:
            # pure python fallback HOTP/TOTP (RFC 6238)
            try:
                import hmac, hashlib, struct, time as _t
                # base32 decode
                b = secret + "=" * ((8 - len(secret) % 8) % 8)
                import base64
                key = base64.b32decode(b, casefold=True)
                counter = int(_t.time()) // 30
                msg = struct.pack(">Q", counter)
                h = hmac.new(key, msg, hashlib.sha1).digest()
                o = h[-1] & 0x0F
                code = (struct.unpack(">I", h[o:o+4])[0] & 0x7FFFFFFF) % 1000000
                return f"{code:06d}"
            except Exception as e:
                try:
                    warn(f"TOTP: {e}")
                except Exception:
                    pass
                return ""
        except Exception as e:
            try:
                warn(f"TOTP: {e}")
            except Exception:
                pass
            return ""

    def login(self) -> bool:
        # Bo'sh cookie — email/password yo'liga o't
        if self.cookie and not str(self.cookie).strip():
            self.cookie = ""
        if self.cookie:
            try:
                d = self.dashboard()
                fb = d.get("body") or ""
                hk = self.extract_hash_key(fb)
                if d.get("username") or hk or (
                    "profile-name" in fb.lower() and "user_balance" in fb.lower()
                ):
                    ok(f"Cookie session: {d.get('username') or 'ok'}")
                    info("User", d.get("username") or "—")
                    info("Balance", f"{d.get('balance') or '0'} LTC")
                    if hk:
                        info("Hash", "faucet da bor")
                    save_cfg(self.cfg)
                    try:
                        self.write_panel_status(fb, {"status": "RUN", "last": "cookie ok",
                            "user": d.get("username"),
                            "balance": float(str(d.get("balance") or "0").replace(",", "").split()[0] or 0)})
                    except Exception:
                        pass
                    return True
            except Exception as e:
                warn(f"Cookie: {e}")
            warn("Cookie eskirgan yoki chala — email login")

        email = (self.cfg.get("email") or "").strip()
        password = (self.cfg.get("password") or "").strip()
        if not email or not password:
            err("cookie yoki email+password kerak")
            return False

        info("Login", email)
        for attempt in range(1, 4):
            body = self.get("login.php")
            if "Just a moment" in body:
                err("Cloudflare — cf_clearance kerak")
                return False

            types = self.detect_captchas(body)
            order = [t for t in (0, 4, 2, 1) if t in types]
            for t in types:
                if t not in order:
                    order.append(t)

            names = {0: "IconCaptcha", 1: "reCAPTCHA", 2: "hCaptcha", 4: "pCaptcha"}
            cap = None
            for t in order:
                info("Try", f"{names.get(t)} (login {attempt})")
                g = h = pc = ""
                ic: dict = {}
                if t == 0:
                    ic = self.solve_icon(body) or {}
                    if not ic:
                        continue
                elif t == 4:
                    pc = self.solve_pcaptcha() or ""
                    if not pc:
                        continue
                elif t == 2:
                    if not self.xevil.ok:
                        continue
                    h = self.xevil.hcaptcha(HOST + "login.php") or ""
                    if not h:
                        continue
                elif t == 1:
                    if not self.xevil.ok:
                        continue
                    g = self.xevil.recaptcha(HOST + "login.php") or ""
                    if not g:
                        continue
                else:
                    continue
                cap = {"type": t, "g": g, "h": h, "pc": pc, "ic": ic}
                ok(f"{names[t]} — login")
                break

            if not cap:
                err("Login captcha yechilmadi")
                time.sleep(2)
                continue

            post = {
                "action": "login",
                "email": email,
                "password": password,
                "twofa": (self.totp_code() or ""),
                "captcha_type": str(cap["type"]),
                "g-recaptcha-response": cap.get("g") or "",
                "h-captcha-response": cap.get("h") or "",
                "c_captcha_response": "",
                "pcaptcha_token": cap.get("pc") or "",
                "csrf_test_name": self.csrf(),
            }
            post.update(cap.get("ic") or {})
            raw = self.post("process.php", post, "login.php")
            mes = self.parse_mes(raw)
            msg = (mes or {}).get("mes") if mes else raw[:120]
            # 2FA talab qilinsa — TOTP bilan qayta
            if re.search(r"2fa|two.?fa|authenticator|otp|google auth", str(msg), re.I):
                code = self.totp_code()
                if code:
                    post["twofa"] = code
                    raw = self.post("process.php", post, "login.php")
                    mes = self.parse_mes(raw)
                    msg = (mes or {}).get("mes") if mes else raw[:120]
                    try:
                        info("2FA", f"TOTP yuborildi ({code[:2]}****)")
                    except Exception:
                        pass
            time.sleep(0.8)
            d = self.dashboard()
            fb = d.get("body") or ""
            # haqiqiy sessiya: username yoki faucet da hash/profile
            hk = self.extract_hash_key(fb)
            real = bool(d.get("username")) or bool(hk) or (
                "user_balance" in fb.lower() and "profile-name" in fb.lower()
            )
            if real:
                ok(f"Login OK: {d.get('username') or 'session'}")
                info("User", d.get("username") or "—")
                info("Balance", f"{d.get('balance') or '0'} LTC")
                save_cfg(self.cfg)
                try:
                    COOKIE_FILE.write_text(self.cookie + "\n", encoding="utf-8")
                except Exception:
                    pass
                try:
                    self.write_panel_status(fb, {"status": "RUN", "last": "login ok",
                        "user": d.get("username"), "balance": float(str(d.get("balance") or "0").replace(",", "").split()[0] or 0)})
                except Exception:
                    pass
                return True
            # Xevil IP / chala cookie
            warn(f"Sessiya to'liq emas (user/hash yo'q). Javob: {(msg or '')[:80]}")
            if "invalid captcha" in str(msg).lower() or not msg:
                warn("Brauzer cookie tavsiya (Xevil IP mos kelmasligi mumkin)")
            time.sleep(2)
        err("Login fail — config ga brauzer cookie yozing")
        return False

    def parse_mes(self, raw: str) -> Optional[dict]:
        try:
            j = json.loads(raw)
            if isinstance(j, dict):
                return j
        except Exception:
            pass
        m = re.search(r'"ret"\s*:\s*(\d+).*?"mes"\s*:\s*"([^"]*)"', raw, re.S)
        if m:
            return {"ret": int(m.group(1)), "mes": m.group(2)}
        return None

    def parse_countdown(self, body: str) -> int:
        """Qolgan sekund. Agar sayt unix timestamp bersa — real qolgan vaqt."""
        now = int(time.time())
        for pat in (
            r"show_countdown_clock\s*\(\s*(\d+)\s*\)",
            r"next_claim_time\s*[=:]\s*(\d+)",
            r"FlipClock\s*\([^,]+,\s*(\d+)",
            r"data-countdown\s*=\s*[\"'](\d+)",
            r"countdown\s*[:=]\s*(\d{3,})",
        ):
            m = re.search(pat, body, re.I)
            if m:
                v = int(m.group(1))
                # unix ts (2001+)
                if v > 1_000_000_000:
                    return max(0, v - now)
                return max(0, v)
        return 0

    def extract_hash_key(self, body: str) -> str:
        for pat in (
            r"get_hash\s*\(\s*event\s*,\s*'([a-f0-9]+)'",
            r'get_hash\s*\(\s*event\s*,\s*"([a-f0-9]+)"',
            r"get_hash\s*\([^,]+,\s*'([a-f0-9]{16,})'",
            r'get_hash\s*\([^,]+,\s*"([a-f0-9]{16,})"',
            r'hash[_-]?key["\']?\s*[:=]\s*["\']([a-f0-9]{16,})["\']',
            r'var\s+hash_key\s*=\s*["\']([a-f0-9]{16,})["\']',
            r'["\']hash["\']\s*:\s*["\']([a-f0-9]{16,})["\']',
            r'name=["\']hash["\'][^>]*value=["\']([a-f0-9]{16,})["\']',
            r'data-hash=["\']([a-f0-9]{16,})["\']',
        ):
            m = re.search(pat, body, re.I)
            if m:
                return m.group(1)
        # oxirgi chora: uzun hex claim skript ichida
        m = re.search(r"claim_hourly[^\n]{0,200}([a-f0-9]{24,64})", body, re.I)
        if m:
            return m.group(1)
        return ""

    def make_hash(self, key: str) -> str:
        if not key:
            return ""
        data = f"{random.randint(50,110)}:{random.randint(15,40)}:{int(time.time())}"
        enc = "".join(chr(ord(data[i]) ^ ord(key[i % len(key)])) for i in range(len(data)))
        return base64.b64encode(enc.encode("latin-1")).decode()

    def detect_captchas(self, body: str) -> list:
        """Selectdagi selected captcha ustun; disabled select → faqat shu type."""
        selected = []
        for val, t in (("0", 0), ("4", 4), ("2", 2), ("1", 1)):
            if re.search(r'option[^>]*value=["\']?' + val + r'["\']?[^>]*selected', body, re.I):
                selected.append(t)
            elif re.search(r'option[^>]*selected[^>]*value=["\']?' + val + r'["\']?', body, re.I):
                selected.append(t)
        forced = bool(
            re.search(r'select[_-]?captcha[^>]*disabled', body, re.I)
            or re.search(r'<select[^>]*(id|name)=["\']select_captcha["\'][^>]*disabled', body, re.I)
        )
        if forced and selected:
            return selected[:1]
        low = body.lower()
        avail = []
        for t, key in ((0, "iconcaptcha"), (4, "pcaptcha"), (2, "hcaptcha"), (1, "recaptcha")):
            if key in low or t in selected:
                avail.append(t)
        if not avail:
            avail = [0, 4, 2, 1]
        out, seen = [], set()
        for t in selected + avail:
            if t not in seen:
                seen.add(t)
                out.append(t)
        return out


    def resolve_icon_candidates(self, img_b64: str) -> list:
        """[(idx, n, source), ...] — DB → local (bir necha) → AI"""
        out = []
        h = img_hash_b64(img_b64)
        hit = self.ic.lookup(h)
        if hit is not None:
            ok(f"IC DB hit → i={hit[0]} n={hit[1]}")
            out.append((hit[0], hit[1], "db"))
        for idx, n in local_least_candidates(img_b64):
            if not out or (idx, n) != (out[0][0], out[0][1]):
                out.append((idx, n, "local"))
        if len(out) < 2:
            info("IC", "Vision AI (fallback)...")
            ai = self.vision.icon_index(img_b64, 8, cache=self.ic)
            if ai is not None:
                idx, n = ai
                ok(f"IC AI → i={idx}")
                out.append((idx, max(n, idx + 1), "ai"))
        # unique by idx+n
        seen, uniq = set(), []
        for t in out:
            k = (t[0], t[1])
            if k not in seen:
                seen.add(k)
                uniq.append(t)
        return uniq

    def resolve_icon_index(self, img_b64: str) -> Optional[tuple]:
        c = self.resolve_icon_candidates(img_b64)
        return (c[0][0], c[0][1], c[0][2]) if c else None

    def solve_icon(self, body: str, max_rounds: int = 3) -> Optional[dict]:
        """3 marta yangi challenge + bir nechta lokal indeks sinovi."""
        m = re.search(r"_iconcaptcha-token['\"]?\s*value=['\"]([^'\"]+)", body, re.I)
        if not m:
            m = re.search(r'name=["\']_iconcaptcha-token["\'][^>]*value=["\']([^"\']+)', body, re.I)
        if not m:
            return None
        token = m.group(1)
        last_hash = None

        for round_i in range(1, max_rounds + 1):
            wid = str(uuid.uuid4())
            ts = int(time.time() * 1000)
            payload = base64.b64encode(
                json.dumps(
                    {"widgetId": wid, "action": "LOAD", "theme": "light", "token": token,
                     "timestamp": ts, "initTimestamp": ts},
                    separators=(",", ":"),
                ).encode()
            ).decode()
            try:
                r = self.s.post(
                    IC_ENDPOINT,
                    data={"payload": payload},
                    headers={
                        "X-IconCaptcha-Token": token,
                        "X-Requested-With": "XMLHttpRequest",
                        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                        "Referer": HOST + "faucet.php",
                    },
                    timeout=50,
                    verify=False,
                )
                self._merge(r)
                raw = r.text.strip()
                try:
                    data = json.loads(base64.b64decode(raw))
                except Exception:
                    data = json.loads(raw)
            except Exception as e:
                warn(f"IC LOAD: {e}")
                time.sleep(1)
                continue

            img = data.get("challenge") or data.get("base64")
            cid = data.get("identifier") or data.get("challengeId") or ""
            if not img:
                continue

            time.sleep(random.uniform(0.7, 1.4))
            cands = self.resolve_icon_candidates(img if isinstance(img, str) else "")
            if not cands:
                warn(f"IC round {round_i}: indeks yo'q")
                continue
            if cands[0][2] == "local":
                ok(f"IC local → i={cands[0][0]} n={cands[0][1]} (round {round_i})")

            h = img_hash_b64(img if isinstance(img, str) else "")
            last_hash = h

            for idx, n_icons, source in cands[:4]:
                n_icons = max(5, min(8, int(n_icons)))
                if idx < 0 or idx >= n_icons:
                    continue
                time.sleep(random.uniform(0.35, 0.85))
                done = False
                for w in (320, 300, 280, 340, 360):
                    x = int(round((idx + 0.5) * (w / float(n_icons))))
                    y = random.randint(28, 52)
                    ts = int(time.time() * 1000)
                    payload = base64.b64encode(
                        json.dumps(
                            {
                                "widgetId": wid,
                                "challengeId": cid,
                                "action": "SELECTION",
                                "x": x, "y": y, "width": w,
                                "token": token,
                                "timestamp": ts,
                                "initTimestamp": ts,
                            },
                            separators=(",", ":"),
                        ).encode()
                    ).decode()
                    try:
                        r = self.s.post(
                            IC_ENDPOINT,
                            data={"payload": payload},
                            headers={
                                "X-IconCaptcha-Token": token,
                                "X-Requested-With": "XMLHttpRequest",
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                "Referer": HOST + "faucet.php",
                            },
                            timeout=50,
                            verify=False,
                        )
                        self._merge(r)
                        try:
                            d = json.loads(base64.b64decode(r.text.strip()))
                        except Exception:
                            d = json.loads(r.text.strip())
                    except Exception:
                        d = {}
                    if d.get("completed"):
                        ok(f"IconCaptcha OK i={idx} n={n_icons} src={source}")
                        try:
                            self.ic.save(h, idx, n_icons, source)
                        except Exception:
                            pass
                        return {
                            "_iconcaptcha-token": token,
                            "ic-rq": "1",
                            "ic-wid": wid,
                            "ic-cid": cid,
                            "ic-hp": "",
                            "_ic_hash": h,
                        }
                    time.sleep(0.15)
                # completed bo'lmadi — keyingi nomzod
            warn(f"IC round {round_i}/{max_rounds} fail")
            time.sleep(random.uniform(0.5, 1.2))
            # yangi body token olish
            try:
                body = self.get("faucet.php")
                m2 = re.search(r"_iconcaptcha-token['\"]?\s*value=['\"]([^'\"]+)", body, re.I)
                if m2:
                    token = m2.group(1)
            except Exception:
                pass
        return None


    def solve_pcaptcha(self) -> Optional[str]:
        """Lokal DB → AI → token. Muvaffaqiyatli boxes DB ga yoziladi."""
        for attempt in range(1, 4):
            info("pCaptcha", f"{attempt}/3")
            try:
                self.get("faucet.php")
            except Exception:
                pass
            try:
                r = self.s.post(
                    HOST + "generate_pcaptcha.php",
                    headers={"X-Requested-With": "XMLHttpRequest", "Referer": HOST + "faucet.php"},
                    timeout=50,
                    verify=False,
                )
                self._merge(r)
                data = r.json()
            except Exception as e:
                warn(f"pCaptcha gen: {e}")
                continue
            if not data.get("image"):
                continue
            img_url = data["image"]
            if not img_url.startswith("http"):
                img_url = HOST.rstrip("/") + "/" + img_url.lstrip("/")
            try:
                img = self.s.get(img_url, timeout=50, verify=False).content
            except Exception:
                continue
            question = (data.get("question") or data.get("text") or "").strip()
            boxes = None
            source = "local"

            # 1) lokal o'rganish
            boxes = self.ic.pc_lookup(question, img)
            if boxes:
                ok(f"pCaptcha local → {boxes}")
            else:
                # 2) oddiy heuristic (matn kalit so'zlari)
                boxes = self._pc_heuristic(question, img)
                if boxes:
                    source = "heuristic"
                    ok(f"pCaptcha heuristic → {boxes}")
                else:
                    # 3) AI
                    boxes = self.vision.pcaptcha_boxes(question, img, cache=self.ic)
                    source = "ai"
                    if boxes:
                        ok(f"pCaptcha AI → {boxes}")
            if not boxes:
                continue

            raw = self.post(
                "process.php",
                {
                    "action": "verify_pcaptcha",
                    "selected_boxes": json.dumps(boxes),
                    "csrf_test_name": self.csrf(),
                },
            )
            try:
                j = json.loads(raw)
            except Exception:
                continue
            if j.get("success") and j.get("token"):
                ok("pCaptcha ok")
                try:
                    self.ic.pc_save(question, img, boxes, source)
                except Exception:
                    pass
                return j["token"]
            # xato — keyingi urinish
            time.sleep(0.8)
        return None

    def _pc_heuristic(self, question: str, img: bytes) -> Optional[list]:
        """Oddiy savollar uchun (AI tejam). Murakkab 'yo'lak' uchun AI/DB."""
        if not HAS_PIL or not img:
            return None
        q = (question or "").lower()
        try:
            im = Image.open(io.BytesIO(img)).convert("RGB")
            w, h = im.size
            # 3x3 grid
            cells = []
            for row in range(3):
                for col in range(3):
                    x0, y0 = col * w // 3, row * h // 3
                    x1, y1 = (col + 1) * w // 3, (row + 1) * h // 3
                    tile = im.crop((x0, y0, x1, y1))
                    cells.append(tile)
            # brightness / color stats
            stats = []
            for t in cells:
                g = t.convert("L").resize((8, 8), Image.Resampling.BILINEAR)
                pix = list(g.getdata()) if hasattr(g, "getdata") else [g.load()[x, y] for y in range(8) for x in range(8)]
                avg = sum(pix) / max(1, len(pix))
                # colorfulness rough
                rgb = t.resize((4, 4), Image.Resampling.BILINEAR)
                rp = list(rgb.getdata())
                var = 0
                if rp:
                    means = [sum(c[i] for c in rp) / len(rp) for i in range(3)]
                    var = sum((c[i] - means[i]) ** 2 for c in rp for i in range(3)) / len(rp)
                stats.append((avg, var))

            # "darkest" / "eng qorong'u"
            if any(k in q for k in ("dark", "qorong", "qora", "black", "eng qora")):
                i = min(range(9), key=lambda i: stats[i][0])
                return [i + 1]
            if any(k in q for k in ("bright", "yorug", "oq", "white", "eng yorug")):
                i = max(range(9), key=lambda i: stats[i][0])
                return [i + 1]
            # path / yolak — lokal ishonchsiz, AI ga qoldiramiz
            if any(k in q for k in ("path", "yo'lak", "yolak", "road", "line", "connect")):
                return None
        except Exception:
            return None
        return None


    def solve_captcha(self, body: str, pageurl: str) -> Optional[dict]:
        names = {0: "IconCaptcha", 1: "reCAPTCHA", 2: "hCaptcha", 4: "pCaptcha"}
        types = self.detect_captchas(body)
        # Icon birinchi (lokal), keyin p, keyin xevil
        order = []
        for t in (0, 4, 2, 1):
            if t in types:
                order.append(t)
        for t in types:
            if t not in order:
                order.append(t)

        for t in order:
            info("Try", names.get(t, str(t)))
            g = h = pc = ""
            ic: dict = {}
            if t == 0:
                ic = self.solve_icon(body, max_rounds=3) or {}
                if not ic:
                    continue
            elif t == 4:
                pc = self.solve_pcaptcha() or ""
                if not pc:
                    continue
            elif t == 2:
                if not self.xevil.ok:
                    continue
                h = self.xevil.hcaptcha(pageurl) or ""
                if not h:
                    continue
            elif t == 1:
                if not self.xevil.ok:
                    continue
                g = self.xevil.recaptcha(pageurl) or ""
                if not g:
                    continue
            else:
                continue
            ok(f"{names[t]} yechildi")
            return {"type": t, "g": g, "h": h, "pc": pc, "ic": ic}
        return None



    def timer(self, sec: int, next_ts: int | None = None):
        """Kutish. >=15 daq → next_ts saqlab process EXIT (slot bo'shaydi).
        Manager next_ts kelganda qayta start qiladi."""
        sec = max(1, int(sec))
        end = float(next_ts) if next_ts and next_ts > time.time() else (time.time() + sec)
        end_i = int(end)
        left0 = max(1, end_i - int(time.time()))

        # Uzoq uyqu: slotni band qilmaslik
        if left0 >= 900:  # 15 daqiqa
            try:
                self.write_panel_status("", {
                    "status": "SLEEP",
                    "last": f"sleep {left0}s",
                    "next_ts": end_i,
                    "wait_sec": left0,
                    "sleep": True,
                })
            except Exception:
                pass
            try:
                (BASE / "next_claim.json").write_text(
                    json.dumps({"next_ts": end_i, "wait_sec": left0, "saved_at": int(time.time())}),
                    encoding="utf-8",
                )
            except Exception:
                pass
            try:
                info("SLEEP", f"{left0}s · slot bo'shatildi · uyg'onish {time.strftime('%H:%M:%S', time.localtime(end_i))}")
            except Exception:
                print(f"  SLEEP {left0}s until {end_i}", flush=True)
            import sys as _sys
            _sys.exit(0)

        spin, i = "-/|\\", 0
        last_print = 0.0
        last_panel = 0.0
        while True:
            left = int(end - time.time())
            if left < 1:
                break
            # kutish paytida 15 daq dan oshib ketsa (qayta hisob) — ham exit
            if left >= 900 and i > 5:
                try:
                    self.write_panel_status("", {
                        "status": "SLEEP", "last": f"sleep {left}s",
                        "next_ts": end_i, "wait_sec": left, "sleep": True,
                    })
                except Exception:
                    pass
                import sys as _sys
                _sys.exit(0)
            hh, rem = divmod(left, 3600)
            mm, ss = divmod(rem, 60)
            now = time.time()
            interval = 2 if left <= 20 else (5 if left <= 60 else 12)
            if now - last_print >= interval or i == 0:
                print(f"  {C.CYN}{spin[i % 4]}{C.R} Next: {C.GRN}{hh:02d}:{mm:02d}:{ss:02d}{C.R}", flush=True)
                last_print = now
            if now - last_panel >= (3 if left <= 60 else 12) or i == 0:
                try:
                    self.write_panel_status("", {
                        "status": "WAIT",
                        "last": f"{hh:02d}:{mm:02d}:{ss:02d}",
                        "next_ts": end_i,
                        "wait_sec": left,
                    })
                except Exception:
                    pass
                last_panel = now
            if left > 720 and i > 0 and i % 180 == 0:
                try:
                    st = load_stats()
                    if int(st.get("dice_today") or 0) < self.dice_day_cap():
                        d = self.dashboard()
                        bal = float(str(d.get("balance") or "0").replace(",", "").split()[0] or 0)
                        self.micro_dice_session(bal, max_bets=random.randint(4, 10), reason="wait")
                except Exception:
                    pass
            i += 1
            time.sleep(min(1.0, max(0.3, left)))
        try:
            self.write_panel_status("", {"status": "RUN", "last": "claim window", "next_ts": 0, "wait_sec": 0})
        except Exception:
            pass

    def human_pause(self, a=0.8, b=2.5):
        """Odam kabi qisqa kutish."""
        time.sleep(random.uniform(a, b))


    def parse_stamina(self, body: str) -> dict:
        """Remaining claims, stamina %, level wager %."""
        out = {
            "claims_left": None,
            "stamina_pct": None,
            "wager_pct": None,
            "level": "",
        }
        m = re.search(r'claims_remaining["\']?\s*>\s*(\d+)', body, re.I)
        if not m:
            m = re.search(r'Remaining claims:\s*(\d+)', body, re.I)
        if m:
            out["claims_left"] = int(m.group(1))
        m = re.search(r'progress-percentage-stamina["\']?\s*>\s*([0-9.]+)\s*%', body, re.I)
        if not m:
            m = re.search(r'progress-bar--stamina[^>]*aria-valuenow=["\']?([0-9.]+)', body, re.I)
        if m:
            try:
                out["stamina_pct"] = float(m.group(1))
            except Exception:
                pass
        m = re.search(r'id=["\']wagering_progress["\'][^>]*style=["\'][^"\']*width:\s*([0-9.]+)%', body, re.I)
        if not m:
            m = re.search(r'progress-percentage["\']?\s*>\s*([0-9.]+)\s*%', body, re.I)
        if m:
            try:
                out["wager_pct"] = float(m.group(1))
            except Exception:
                pass
        m = re.search(r'(Bronze|Silver|Gold|Platinum)\s*[→\->]+\s*(Bronze|Silver|Gold|Platinum)', body, re.I)
        if m:
            out["level"] = f"{m.group(1)}→{m.group(2)}"
        return out


    def write_panel_status(self, body: str = "", extra: dict | None = None):
        """Dashboard / manager uchun real-time holat."""
        try:
            st = self.parse_stamina(body) if body else {}
            d = {}
            try:
                d = self.dashboard()
            except Exception:
                d = {}
            user = (d.get("username") or getattr(self, "_last_user", None) or "")
            bal = d.get("balance")
            try:
                bal_f = float(str(bal or "0").replace(",", "").split()[0])
            except Exception:
                bal_f = None
            coin = "TRX" if "tron" in HOST else ("SUI" if "sui" in HOST else ("DOGE" if "doge" in HOST else ("LTC" if "lite" in HOST else "TON")))
            payload = {
                "user": user or None,
                "balance": bal_f,
                "coin": coin,
                "status": (extra or {}).get("status") or "RUN",
                "last": (extra or {}).get("last") or "",
                "claims_today": int(load_stats().get("claims_today") or 0),
                "claims_left": st.get("claims_left"),
                "stamina_pct": st.get("stamina_pct"),
                "wager_pct": st.get("wager_pct"),
                "level": st.get("level") or "",
                "updated": int(time.time()),
                "source": "bot",
            }
            if extra:
                for k, v in extra.items():
                    if v is not None:
                        payload[k] = v
            path = BASE / "panel_status.json"
            path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            if user:
                self._last_user = user
        except Exception:
            pass


    def show_stamina(self, body: str):
        st = self.parse_stamina(body)
        left = st.get("claims_left")
        sp = st.get("stamina_pct")
        wp = st.get("wager_pct")
        lvl = st.get("level") or ""
        # 1 kun ≈ 24 claim — qizil ogohlantirish
        low = left is not None and left <= 24
        parts = []
        if sp is not None:
            parts.append(f"stamina {sp:.0f}%")
        if wp is not None:
            parts.append(f"wager {wp:.0f}%")
        if lvl:
            parts.append(lvl)
        if left is not None:
            parts.append(f"left {left}")
        msg = " · ".join(parts) if parts else "—"
        if low:
            print(f" {C.RED}[{C.W}{'Stamina':<10}{C.RED}]{C.R} {C.RED}{C.B}{msg}  ⚠ ≤1 kun{C.R}")
        else:
            info("Stamina", msg)
        # caps_panel uchun aniq qator
        if left is not None:
            print(f" [ClaimsLeft] {left}")
        if sp is not None:
            print(f" [StaminaPct] {sp:.0f}%")
        if wp is not None:
            print(f" [WagerPct  ] {wp:.0f}%")
        try:
            self.write_panel_status(body, {"status": "WAIT" if (left is not None) else "RUN", "last": f"left={left}" if left is not None else "stamina"})
        except Exception:
            pass
        return st


    def hour_of_day(self) -> int:
        try:
            from datetime import datetime
            from zoneinfo import ZoneInfo
            return datetime.now(ZoneInfo(self.cfg.get("tz") or "Asia/Tashkent")).hour
        except Exception:
            return int(time.strftime("%H"))

    def should_skip_claim(self) -> bool:
        """Kuniga MAX 3 ta claim o'tkazish (odam). 4-chi skip bo'lmaydi."""
        st = load_stats()
        skips = int(st.get("skips_today") or 0)
        if skips >= 3:
            return False
        h = self.hour_of_day()
        # Kuniga max 3 skip; ehtimol pastroq → odatda 1-2 skip, 21-23 claim
        p = 0.05
        if 19 <= h <= 23:
            p = 0.12
        elif 0 <= h <= 6:
            p = 0.14
        elif 12 <= h <= 14:
            p = 0.07
        if random.random() < p:
            st["skips_today"] = skips + 1
            save_stats(st)
            return True
        return False

    def post_claim_wait(self) -> int:
        """1 soat + 2-10 min jitter. Kuniga ~22+ oyna → 3 skip bilan ham >=21 claim."""
        base = 3600
        r = random.random()
        if r < 0.70:
            extra = random.randint(120, 360)      # 2-6 min
        elif r < 0.95:
            extra = random.randint(360, 540)      # 6-9 min
        else:
            extra = random.randint(540, 720)      # 9-12 min (kamdan-kam)
        return base + extra

    def try_claim_commissions(self):
        """Affiliate / ref commission claim (50% ref)."""
        try:
            self.human_pause(1.0, 3.0)
            raw = self.post("process.php", {
                "action": "claim_commissions",
                "csrf_test_name": self.csrf(),
            })
            try:
                j = json.loads(raw)
            except Exception:
                return
            mes = str(j.get("mes") or j.get("message") or "")
            if j.get("ret") in (1, "1", True) or "success" in mes.lower():
                ok(f"Affiliate claim: {mes[:80] or 'ok'}")
            elif mes:
                # "nothing to claim" — jim
                if "no " in mes.lower() or "nothing" in mes.lower() or "0" == mes.strip():
                    pass
                else:
                    info("Aff", mes[:60])
        except Exception as e:
            warn(f"aff: {e}")

    def try_bonus_faucet(self):
        try:
            raw = self.post("process.php", {
                "action": "claim_bonus_faucet",
                "csrf_test_name": self.csrf(),
            })
            j = json.loads(raw) if raw.strip().startswith("{") else {}
            if j.get("ret") in (1, "1", True):
                ok(f"Bonus: {j.get('mes', 'ok')[:60]}")
        except Exception:
            pass


    def detect_min_bet(self) -> float:
        """Saytdan minimal bet — dice sahifasi yoki xabar orqali."""
        cached = getattr(self, "_min_bet_detected", None)
        if cached and cached > 0:
            return cached
        cfg_b = float(self.cfg.get("dice_min_bet") or 0)
        host = getattr(self, "host", "") or ""
        paths = ["games/dice.php", "dice.php", "games.php"]
        found = 0.0
        for path in paths:
            try:
                body = self.get(path)
            except Exception:
                continue
            if not body or len(body) < 500:
                continue
            # MIN_BET = 0.0001 / min bet 0.000100
            for pat in (
                r'MIN_BET\s*=\s*([0-9.]+)',
                r'min[_ ]?bet\s*[=:]\s*([0-9.]+)',
                r'at least\s+([0-9.]+)\s*(?:TRX|TON|SOL|SUI|LTC|DOGE)?',
                r'must be at least\s+([0-9.]+)',
                r'minimum(?:\s+bet)?[^0-9]{0,20}([0-9]+\.[0-9]+)',
                r'data-min[=\"\']+\s*([0-9.]+)',
            ):
                m = re.search(pat, body, re.I)
                if m:
                    try:
                        v = float(m.group(1))
                        if 1e-8 < v < 1.0:
                            found = v
                            break
                    except Exception:
                        pass
            if found:
                break
            # platform defaults from host
        if not found:
            h = (host or "").lower()
            if "tron" in h:
                found = 0.0001
            elif "ton" in h:
                found = 0.00001
            elif "sol" in h:
                found = 0.0001
            else:
                found = cfg_b if cfg_b > 0 else 0.0001
        if cfg_b > 0 and abs(cfg_b - found) / max(found, 1e-12) < 0.01:
            pass
        # config override only if higher precision explicit and site failed
        self._min_bet_detected = found
        try:
            info("Min bet", f"{found:g} (site)")
        except Exception:
            pass
        return found

    def dice_day_cap(self) -> int:
        """Kunlik target: 100..350 random (bir marta saqlanadi)."""
        st = load_stats()
        cap = int(st.get("dice_day_cap") or 0)
        if cap >= 100:
            return cap
        cfg_cap = int(self.cfg.get("dice_daily_cap") or 0)
        if cfg_cap >= 100:
            cap = cfg_cap
        else:
            # triangular 100-350, mode ~180
            cap = int(random.triangular(100, 350, 180))
        st["dice_day_cap"] = cap
        save_stats(st)
        return cap

    def micro_dice_session(self, balance: float, max_bets: int | None = None, reason: str = "session"):
        """
        Professional micro-dice / abarot.
        - min bet saytdan
        - kunlik 100-350
        - claim timer/sleep ga halaqit qilmaydi (qisqa batch)
        """
        if self.cfg.get("dice_enabled") in (0, "0", False, "false", "False"):
            return 0
        min_bet = self.detect_min_bet()
        min_bal = float(self.cfg.get("dice_min_balance") or (min_bet * 30))
        if balance < max(min_bal, min_bet * 3):
            return 0

        st = load_stats()
        day_bets = int(st.get("dice_today") or 0)
        day_cap = self.dice_day_cap()
        if day_bets >= day_cap:
            return 0

        # batch size: claim dan keyin biroz ko'proq, timer ichida kichik
        if max_bets is None:
            if reason == "claim":
                max_bets = int(random.randint(12, 28))
            else:
                max_bets = int(random.randint(5, 14))
        left = min(max_bets, day_cap - day_bets)
        if left <= 0:
            return 0

        payout = float(self.cfg.get("dice_payout") or 1.01)
        side = random.choice(["higher", "lower"])
        wins = losses = done = 0
        try:
            info("Dice", f"{reason} ×{left} min={min_bet:g} day={day_bets}/{day_cap}")
        except Exception:
            pass

        bet_str = f"{min_bet:.8f}".rstrip("0").rstrip(".")
        if "e" in bet_str.lower():
            bet_str = f"{min_bet:.8f}"

        for i in range(left):
            # odamga o'xshash pauza
            try:
                self.human_pause(0.25, 0.9)
            except Exception:
                time.sleep(random.uniform(0.25, 0.9))
            if random.random() < 0.10:
                side = "higher" if side == "lower" else "lower"
            post = {
                "action": "bet_game_dice",
                "bet_amount": bet_str,
                "payout": str(payout),
                "bet_on": side,
                "csrf_test_name": self.csrf(),
            }
            try:
                raw = self.post("process.php", post)
                j = json.loads(raw) if isinstance(raw, str) and raw.strip()[:1] == "{" else {}
            except Exception as e:
                try:
                    warn(f"dice: {e}")
                except Exception:
                    pass
                break

            mes = str(j.get("mes") or j.get("message") or "")
            # min bet xabari — o'rganib qayta urin
            mmin = re.search(r'at least\s+([0-9.]+)', mes, re.I)
            if mmin:
                try:
                    nb = float(mmin.group(1))
                    if nb > min_bet:
                        self._min_bet_detected = nb
                        min_bet = nb
                        bet_str = f"{min_bet:.8f}".rstrip("0").rstrip(".")
                        continue
                except Exception:
                    pass
            if j.get("ret") in (0, "0") and re.search(r'error|invalid|csrf|login', mes, re.I):
                try:
                    warn(f"dice stop: {mes[:80]}")
                except Exception:
                    pass
                break

            done += 1
            day_bets += 1
            st["dice_today"] = day_bets
            if j.get("win") is True or re.search(r'\bwin\b', mes, re.I):
                wins += 1
            elif j.get("win") is False or re.search(r'lose|lost|loss', mes, re.I):
                losses += 1
            # balans yangilanishi
            if j.get("balance") is not None:
                try:
                    bv = float(j["balance"])
                    balance = bv / 1_000_000.0 if bv > 1000 else bv
                except Exception:
                    pass
            if random.random() < 0.06:
                try:
                    self.human_pause(1.2, 3.5)
                except Exception:
                    time.sleep(random.uniform(1.2, 3.5))
            # kamida saqlash
            if done % 5 == 0:
                save_stats(st)

        save_stats(st)
        try:
            ok(f"Dice {reason}: {done} spin W{wins}/L{losses} · day {day_bets}/{day_cap}")
            self.write_panel_status("", {
                "status": "RUN",
                "last": f"dice {day_bets}/{day_cap}",
                "dice_today": day_bets,
            })
        except Exception:
            pass
        return done


    def loop(self):
        fail = 0
        last_ic_hash = None
        claims_session = 0
        while True:
            try:
                body = self.get("faucet.php")
            except Exception as e:
                err(f"faucet: {e}")
                time.sleep(random.randint(20, 45))
                continue

            if "Just a moment" in body:
                err("Cloudflare — 90s")
                time.sleep(90)
                continue

            lowb = body.lower()
            if "too many request" in lowb or "too many requests" in lowb:
                warn("Too many requests — kutish")
                self.timer(90 + random.randint(30, 90))
                continue

            sess_ok = (
                "profile-name" in lowb
                or "user_balance" in lowb
                or ("logout" in lowb and "login.php" not in lowb)
                or "remember_token=" in (self.cookie or "")
            )
            if not sess_ok:
                warn("Session yo'q")
                if not self.login():
                    time.sleep(45)
                continue

            # Stamina / remaining claims (har aylanish)
            try:
                self.show_stamina(body)
            except Exception:
                pass

            # Affiliate — ba'zan claim oldidan
            if random.random() < 0.35:
                self.try_claim_commissions()

            wait = self.parse_countdown(body)
            for pat, mult in (
                (r"wait\s+for\s+(\d+)\s+minute", 60),
                (r"(\d+)\s+minute[s]?\s*,\s*(\d+)\s+second", None),
                (r"please wait[^\d]{0,40}(\d+)\s*min", 60),
            ):
                mm = re.search(pat, body, re.I)
                if mm:
                    if mult is None and mm.lastindex and mm.lastindex >= 2:
                        wait = max(wait, int(mm.group(1)) * 60 + int(mm.group(2)))
                    elif mult:
                        wait = max(wait, int(mm.group(1)) * mult)
            if wait > 15:
                info("Countdown", f"{wait}s — odam kutadi")
                # kichik jitter
                _jitter = random.randint(20, 90); _nts = int(time.time()) + int(wait) + _jitter; self.timer(wait + _jitter, next_ts=_nts)
                fail = 0
                continue

            # Skip claim (odam o'tkazib yuboradi)
            if self.should_skip_claim():
                # 1 soatlik oynani o'tkazib yuborish — keyingi claim uchun ~1h+jitter
                skip_s = 3600 + random.randint(90, 360)
                warn(f"Skip claim (human) · ~{skip_s//60} min · kunlik max 3")
                self.timer(skip_s)
                continue

            hash_key = self.extract_hash_key(body)
            if not hash_key:
                err("Hash key topilmadi")
                if "login.php" in lowb or 'name="email"' in body or "sign in" in lowb:
                    self.cookie = ""
                    self.s.headers.pop("Cookie", None)
                    if not self.login():
                        time.sleep(30)
                    fail = 0
                    continue
                fail += 1
                if fail >= 2:
                    if not self.login():
                        time.sleep(20)
                    fail = 0
                time.sleep(4)
                continue

            info("Hash", hash_key[:16] + "...")
            self.human_pause(0.5, 1.8)
            body = self.get("faucet.php")
            hash_key = self.extract_hash_key(body) or hash_key
            wait = self.parse_countdown(body)
            if wait > 15:
                info("Countdown", f"{wait}s (refresh)")
                _jitter = random.randint(20, 80); _nts = int(time.time()) + int(wait) + _jitter; self.timer(wait + _jitter, next_ts=_nts)
                continue

            # captcha oldidan odam pausa
            self.human_pause(1.2, 4.0)

            cap = self.solve_captcha(body, HOST + "faucet.php")
            if not cap:
                fail += 1
                s = load_stats()
                s["fails_today"] = int(s.get("fails_today") or 0) + 1
                save_stats(s)
                warn("Captcha yechilmadi — refresh")
                time.sleep(20 + random.randint(10, 25))
                if fail >= 4:
                    self.timer(180 + random.randint(60, 120))
                    fail = 0
                continue

            last_ic_hash = (cap.get("ic") or {}).get("_ic_hash")
            self.human_pause(0.3, 1.0)
            ft = ""
            mm = re.search(r"_ft=([^;\s]+)", self.cookie or "")
            if mm:
                ft = mm.group(1)

            post = {
                "action": "claim_hourly_faucet",
                "hash": self.make_hash(hash_key),
                "ft": ft,
                "captcha_type": str(cap["type"]),
                "g-recaptcha-response": cap.get("g") or "",
                "h-captcha-response": cap.get("h") or "",
                "c_captcha_response": "",
                "pcaptcha_token": cap.get("pc") or "",
                "csrf_test_name": self.csrf(),
            }
            icf = dict(cap.get("ic") or {})
            icf.pop("_ic_hash", None)
            post.update(icf)
            raw = self.post("process.php", post)
            claim = self.parse_mes(raw)

            if isinstance(claim, dict) and claim.get("ret") in (1, "1", True):
                fail = 0
                claims_session += 1
                msg = claim.get("mes") or "Success"
                ok(msg)
                d = self.dashboard()
                try:
                    _capn = names.get(cap.get("type"), "?") if isinstance(cap, dict) else "?"
                    _ct = int(load_stats().get("claims_today") or 0) + 1
                    try:
                        _ev = {
                            "ts": int(time.time()),
                            "claim_kind": "hourly",
                            "kind": "hourly",
                            "claim_ok": True,
                            "claim_msg": (msg or "")[:120],
                            "msg": (msg or "")[:120],
                            "claim_captcha": _capn,
                            "captcha": _capn,
                            "claim_amount": (msg or "")[:80],
                            "amount": (msg or "")[:80],
                            "claims_today": _ct,
                            "user": d.get("username"),
                            "balance": float(str(d.get("balance") or "0").replace(",", "").split()[0]),
                        }
                        (BASE / "claim_event.json").write_text(json.dumps(_ev, ensure_ascii=False), encoding="utf-8")
                    except Exception:
                        pass
                    self.write_panel_status("", {
                        "status": "OK", "last": (msg or "CLAIM")[:48],
                        "user": d.get("username"),
                        "balance": float(str(d.get("balance") or "0").replace(",", "").split()[0]),
                        "claim_ok": True,
                        "claim_kind": "hourly",
                        "claim_msg": (msg or "")[:120],
                        "claim_captcha": _capn,
                        "claim_amount": (msg or "")[:80],
                        "claims_today": _ct,
                        "next_ts": 0,
                    })
                except Exception:
                    try:
                        self.write_panel_status("", {"status": "OK", "last": "CLAIM"})
                    except Exception:
                        pass
                try:
                    bal_f = float(str(d.get("balance") or "0").replace(",", ""))
                except Exception:
                    bal_f = 0.0
                info("Balance", f"{d.get('balance')} LTC")
                names = {0: "IconCaptcha", 1: "reCAPTCHA", 2: "hCaptcha", 4: "pCaptcha"}
                s = load_stats()
                s["claims_today"] = int(s.get("claims_today") or 0) + 1
                s["total_claims"] = int(s.get("total_claims") or 0) + 1
                save_stats(s)
                try:
                    import json as _json
                    with open(BASE / "claims_history.jsonl", "a", encoding="utf-8") as _hf:
                        _hf.write(_json.dumps({
                            "ts": int(time.time()),
                            "kind": "hourly",
                            "captcha": names.get(cap.get("type"), "?") if isinstance(cap, dict) else "?",
                            "msg": (msg or "")[:120],
                            "balance": d.get("balance"),
                        }, ensure_ascii=False) + "\n")
                except Exception:
                    pass
                tg_claim(self.cfg, d["username"], d["balance"], names.get(cap["type"], "?"), msg, s)
                line()

                # bonus + affiliate
                if random.random() < 0.5:
                    self.try_bonus_faucet()
                self.try_claim_commissions()

                # micro dice / abarot — claim dan keyin (sleep ga halaqit yo'q)
                try:
                    self.micro_dice_session(bal_f, reason="claim")
                except Exception as _de:
                    try: warn(f"dice: {_de}")
                    except Exception: pass

                wait_s = self.post_claim_wait()
                info("Kutish", f"{wait_s}s (human jitter)")
                _nts = int(time.time()) + int(wait_s)
                self.timer(wait_s, next_ts=_nts)
                continue

            msg = (claim or {}).get("mes") if isinstance(claim, dict) else ""
            if not msg:
                msg = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", raw))[:180]
            err(msg or "Noma'lum")

            lowm = (msg or "").lower()
            if "invalid captcha" in lowm and last_ic_hash:
                try:
                    self.ic.forget(last_ic_hash)
                    warn("IC hash unutildi")
                except Exception:
                    pass

            sec = 0
            mw = re.search(r"wait\s+for\s+(\d+)\s+minute", msg or "", re.I)
            if mw:
                sec += int(mw.group(1)) * 60
            sw = re.search(r"(\d+)\s+second", msg or "", re.I)
            if sw:
                sec += int(sw.group(1))
            if "too many" in lowm and "10 minute" in lowm:
                sec = max(sec, 600)
            if "failed captcha too many" in lowm:
                sec = max(sec, 600 + random.randint(40, 120))
            if "too many request" in lowm:
                sec = max(sec, 90)

            if sec > 0:
                info("Kutish", f"{sec}s — captcha yechilMAYDI")
                self.timer(sec + random.randint(20, 60))
                fail = 0
                continue

            # "Please wait N minutes" → to'g'ri uxla, spam qilma
            wait_msg = 0
            try:
                raw_l = (raw if isinstance(raw, str) else str(claim)) if 'claim' in dir() else ""
            except Exception:
                raw_l = ""
            try:
                blob = (raw if isinstance(raw, str) else "") + " " + str(claim)
            except Exception:
                blob = str(claim) if 'claim' in dir() else ""
            mm = re.search(r'wait\s+for\s+(\d+)\s+minute', blob, re.I) or re.search(r'(\d+)\s+minute[s]?\s*,\s*(\d+)\s+second', blob, re.I)
            if mm:
                if mm.lastindex and mm.lastindex >= 2:
                    wait_msg = int(mm.group(1)) * 60 + int(mm.group(2))
                else:
                    wait_msg = int(mm.group(1)) * 60
            if wait_msg > 30:
                info("Countdown", f"{wait_msg}s (server)")
                _nts = int(time.time()) + wait_msg + random.randint(15, 45)
                self.timer(wait_msg + 20, next_ts=_nts)
                fail = 0
                continue
            if re.search(r'invalid captcha|failed captcha', blob, re.I):
                fail += 1
                warn("Invalid captcha — yangi challenge")
                time.sleep(8 + random.randint(4, 12))
                try:
                    body = self.get("faucet.php")
                except Exception:
                    pass
                if fail >= 3:
                    self.timer(180 + random.randint(30, 90))
                    fail = 0
                continue
            fail += 1
            s = load_stats()
            s["fails_today"] = int(s.get("fails_today") or 0) + 1
            save_stats(s)
            warn("Refresh + qayta urinish")
            time.sleep(10 + random.randint(5, 20))
            try:
                self.get("faucet.php")
            except Exception:
                pass
            if fail >= 5:
                self.timer(300 + random.randint(60, 180))
                fail = 0




    def withdraw_action_name(self) -> str:
        h = HOST.lower()
        if "tron" in h: return "withdraw_tron"
        if "sui" in h: return "withdraw_sui"
        if "doge" in h: return "withdraw_dogecoin"
        if "lite" in h: return "withdraw_litecoin"
        if "sol" in h: return "withdraw_solana"
        return "withdraw_toncoin"

    def parse_min_withdraw(self, body: str) -> float:
        """Saytdan minimal yechish miqdorini o'qiydi."""
        cands = []
        for pat in (
            r'min(?:imum)?[_\s\-]?withdraw(?:al)?[^0-9]{0,48}([0-9]+(?:\.[0-9]+)?)',
            r'minimum_withdrawal["\']?\s*[:=]\s*["\']?([0-9.]+)',
            r'id=["\']min_amount["\'][^>]*>\s*Min',
            r'withdrawal_amount[^>]{0,80}min=["\']([0-9.]+)',
            r'Min(?:imum)?\s*(?:withdraw)?[^0-9]{0,20}([0-9]+(?:\.[0-9]+)?)',
        ):
            for m in re.finditer(pat, body or "", re.I):
                try:
                    cands.append(float(m.group(1)))
                except Exception:
                    pass
        # fallback by coin
        if not cands:
            h = HOST.lower()
            if "sol" in h: return 0.0025
            if "tron" in h: return 1.0
            if "sui" in h: return 0.1
            if "doge" in h: return 1.0
            if "lite" in h: return 0.001
            return 0.1
        # eng keng tarqalgan / eng kichik mantiqiy
        cands = [x for x in cands if 0 < x < 1e6]
        return min(cands) if cands else 0.1

    def get_withdraw_info(self) -> dict:
        """Balance + min withdraw + wallet."""
        try:
            body = self.get("withdraw.php")
        except Exception as e:
            return {"ok": False, "error": str(e)}
        if "Just a moment" in body:
            return {"ok": False, "error": "cloudflare"}
        d = self.dashboard()
        try:
            bal = float(str(d.get("balance") or "0").replace(",", "").split()[0])
        except Exception:
            bal = 0.0
        mn = self.parse_min_withdraw(body)
        wallet = (self.cfg.get("wallet") or "").strip()
        # page da address input default?
        m = re.search(r'id=["\']withdrawal_address["\'][^>]*>([^<]*)</', body, re.I)
        if m and m.group(1).strip():
            wallet = wallet or m.group(1).strip()
        m = re.search(r'id=["\']withdrawal_address["\'][^>]*value=["\']([^"\']+)', body, re.I)
        if m:
            wallet = wallet or m.group(1).strip()
        return {
            "ok": True,
            "balance": bal,
            "min_withdraw": mn,
            "wallet": wallet,
            "coin": "TRX" if "tron" in HOST else ("SUI" if "sui" in HOST else ("DOGE" if "doge" in HOST else ("LTC" if "lite" in HOST else ("SOL" if "sol" in HOST else "TON")))),
            "user": d.get("username") or "",
            "action": self.withdraw_action_name(),
        }

    def do_withdraw(self, amount: float, address: str, tag: str = "") -> dict:
        """Captcha yechib withdraw qiladi."""
        address = (address or "").strip()
        if len(address) < 10:
            return {"ok": False, "error": "address short"}
        try:
            body = self.get("withdraw.php")
        except Exception as e:
            return {"ok": False, "error": str(e)}
        info_w = self.get_withdraw_info()
        mn = float(info_w.get("min_withdraw") or 0.1)
        bal = float(info_w.get("balance") or 0)
        if amount + 1e-12 < mn:
            return {"ok": False, "error": f"min {mn}", "min_withdraw": mn, "balance": bal}
        if amount > bal + 1e-9:
            return {"ok": False, "error": f"balance {bal}", "balance": bal, "min_withdraw": mn}

        # captcha on withdraw page
        self.human_pause(0.8, 2.0)
        body = self.get("withdraw.php")
        cap = self.solve_captcha(body, HOST + "withdraw.php")
        if not cap:
            return {"ok": False, "error": "captcha fail", "min_withdraw": mn, "balance": bal}

        post = {
            "action": self.withdraw_action_name(),
            "withdrawal_address": address,
            "withdrawal_tag": tag or "",
            "withdrawal_amount": f"{amount:.9f}".rstrip("0").rstrip(".") if amount >= 0.000000001 else str(amount),
            "withdrawal_2fa_code": (self.totp_code() or ""),
            "captcha_type": str(cap.get("type", 0)),
            "g-recaptcha-response": cap.get("g") or "",
            "h-captcha-response": cap.get("h") or "",
            "c_captcha_response": "",
            "pcaptcha_token": cap.get("pc") or "",
            "csrf_test_name": self.csrf(),
        }
        icf = dict(cap.get("ic") or {})
        icf.pop("_ic_hash", None)
        post.update(icf)
        raw = self.post("process.php", post)
        try:
            j = json.loads(raw) if raw.strip()[:1] == "{" else {}
        except Exception:
            j = {}
        # 2FA xato bo'lsa — yangi TOTP bilan 1 marta qayta
        _mes = str((j or {}).get("mes") or raw or "")
        if re.search(r"2fa|two.?fa|authenticator|otp|invalid code", _mes, re.I):
            code2 = self.totp_code()
            if code2 and code2 != post.get("withdrawal_2fa_code"):
                post["withdrawal_2fa_code"] = code2
                time.sleep(1.0)
                raw = self.post("process.php", post)
                try:
                    j = json.loads(raw) if raw.strip()[:1] == "{" else {}
                except Exception:
                    j = {}
        # sometimes double json
        if not j and raw:
            for part in re.findall(r'\{[^{}]+\}', raw):
                try:
                    j = json.loads(part)
                    if "ret" in j:
                        break
                except Exception:
                    pass
        mes = str(j.get("mes") or j.get("message") or raw[:180])
        if j.get("ret") in (1, "1", True):
            ok(f"Withdraw: {mes[:80]}")
            try:
                self.write_panel_status("", {"status": "OK", "last": f"WD {amount}"})
            except Exception:
                pass
            return {"ok": True, "mes": mes, "balance": j.get("balance"), "request_id": j.get("request_id")}
        err(f"Withdraw fail: {mes[:100]}")
        return {"ok": False, "error": mes, "raw": raw[:200]}



def run_one(cfg: dict, ic: ICStore):
    bot = Bot(cfg, ic)
    # Login muvaffaqiyatsiz bo'lsa ham chiqma — manager EXIT ko'rmasin
    login_try = 0
    while not bot.login():
        login_try += 1
        tg_fail(cfg, f"Login failed #{login_try}")
        err(f"Login fail #{login_try} — 40s kutib qayta (process tirik)")
        time.sleep(40 + min(120, login_try * 5))
        cfg = load_cfg()
        bot = Bot(cfg, ic)
    d = bot.dashboard()
    try:
        bal_raw = d.get("balance")
        bal_f = None
        if bal_raw not in (None, ""):
            bal_f = float(str(bal_raw).replace(",", "").split()[0])
        bot.write_panel_status("", {
            "status": "RUN",
            "last": "online",
            "user": d.get("username"),
            "balance": bal_f,
        })
    except Exception:
        pass
    info("User", d.get("username") or "—")
    info("Balance", f"{d.get('balance') or '0'} LTC")
    line()
    tg_start(cfg, d.get("username"), d.get("balance"), str(ic.path))
    bot.loop()
    return True


def main():
    banner()
    if not HAS_PIL:
        warn("Pillow yo'q — lokal IC o'chiq. pkg/pip install pillow")
    cfg = load_cfg()
    if not CFG_PATH.is_file():
        save_cfg(cfg)
        warn(f"Yozildi: {CFG_PATH}")

    db_path = Path(cfg.get("ic_db") or "") if cfg.get("ic_db") else default_ic_db()
    if not str(db_path):
        db_path = default_ic_db()
    ic = ICStore(db_path)
    info("Config", CFG_PATH.name)

    # Bitta process = bitta akk (manager papka). Hech qachon o'zi to'xtamasin.
    while True:
        try:
            run_one(cfg, ic)
        except KeyboardInterrupt:
            raise
        except Exception as e:
            err(f"crash: {e} — 30s keyin qayta")
            time.sleep(30)
            cfg = load_cfg()
            db_path = Path(cfg.get("ic_db") or "") if cfg.get("ic_db") else default_ic_db()
            if not str(db_path):
                db_path = default_ic_db()
            ic = ICStore(db_path)



def cli_withdraw():
    """python bot.py --withdraw AMOUNT --address ADDR"""
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--withdraw", type=float, default=None)
    ap.add_argument("--address", type=str, default="")
    ap.add_argument("--tag", type=str, default="")
    ap.add_argument("--info", action="store_true")
    args, _ = ap.parse_known_args()
    if not args.withdraw and not args.info:
        return False
    banner()
    cfg = load_cfg()
    db_path = Path(cfg.get("ic_db") or "") if cfg.get("ic_db") else default_ic_db()
    if not str(db_path):
        db_path = default_ic_db()
    ic = ICStore(db_path)
    bot = Bot(cfg, ic)
    if not bot.login():
        print(json.dumps({"ok": False, "error": "login fail"}))
        return True
    if args.info:
        print(json.dumps(bot.get_withdraw_info(), ensure_ascii=False))
        return True
    addr = args.address or (cfg.get("wallet") or "")
    res = bot.do_withdraw(float(args.withdraw), addr, args.tag or "")
    print(json.dumps(res, ensure_ascii=False))
    return True



if __name__ == "__main__":
    try:
        if not cli_withdraw():
            main()
    except KeyboardInterrupt:
        print("\nStop")
