# CAPS UNIFIED PRO (Humanized)

Professional multi-account claimer + local IconCaptcha.

## Features
- **Humanize v2**: har akkaunt har kuni random 18–24 claim target
- Wait: 52–110 min real jitter (odam kabi, pattern yo‘q)
- Max parallel bots: PC 16GB uchun 18–26 (auto + kunlik random)
- Local IconCaptcha (ICStore) + optional Gemini / OpenRouter
- CAPS Monitor Hub integration (faqat status, secret yo‘q)

## Run (PC)
```bash
cd caps-unified
pip install -r requirements.txt
python run.py --port 5051
```

## Env
- `CAPS_MAX_BOTS=24`  (ixtiyoriy, 1–40)
- Hub uchun: `reporter.py` + config.json (hub_url + device_code)

## Security
Reporter hubga faqat balance/status yuboradi. Cookie/password lokal qoladi.
