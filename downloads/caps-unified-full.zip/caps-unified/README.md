# CAPS UNIFIED PRO

```bash
cd caps-unified
pip install flask requests
python run.py --port 5051
python run.py --import /sdcard/pul/caps --port 5051
```

Pages: Dashboard, Accounts, Add, Profile, Currencies, **Analytics**, **Alerts**, Settings
Features: health scan, auto-heal, backup, CSV export, captcha stats, portfolio USD, IconCaptcha preferred
