#!/data/data/com.termux/files/usr/bin/bash
# CAPS mustaqil ishga tushirish (ekran o'chsa ham)
cd "$(dirname "$0")"
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
if command -v tmux >/dev/null 2>&1; then
  tmux has-session -t caps 2>/dev/null && tmux kill-session -t caps
  tmux new-session -d -s caps "python run.py"
  echo "CAPS tmux session 'caps' ishga tushdi"
  echo "Qaytish: tmux attach -t caps"
else
  nohup python run.py >/dev/null 2>&1 &
  echo "CAPS nohup PID $!"
fi
