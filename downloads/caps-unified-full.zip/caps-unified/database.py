
import json, time
from pathlib import Path
DATA = Path(__file__).parent / "data"
_price_cache = {"ts": 0.0, "data": {}}
def fetch_prices():
    global _price_cache
    now = time.time()
    if now - float(_price_cache.get("ts") or 0) < 300 and _price_cache.get("data"):
        return dict(_price_cache["data"])
    ids = {"the-open-network":"TON","tron":"TRX","sui":"SUI","dogecoin":"DOGE","litecoin":"LTC","solana":"SOL","matic-network":"POL"}
    try:
        import urllib.request
        url = "https://api.coingecko.com/api/v3/simple/price?ids="+",".join(ids)+"&vs_currencies=usd"
        req = urllib.request.Request(url, headers={"User-Agent":"CAPS-Unified/2"})
        with urllib.request.urlopen(req, timeout=10) as r:
            raw = json.loads(r.read().decode())
        out = {sym: float(raw[gid]["usd"]) for gid,sym in ids.items() if gid in raw and "usd" in raw[gid]}
        if out:
            _price_cache = {"ts": now, "data": out}
            try:
                (DATA/"prices.json").write_text(json.dumps({"ts":now,"prices":out}), encoding="utf-8")
            except Exception:
                pass
            return out
    except Exception:
        pass
    try:
        j = json.loads((DATA/"prices.json").read_text(encoding="utf-8"))
        return dict(j.get("prices") or {})
    except Exception:
        return dict(_price_cache.get("data") or {})
