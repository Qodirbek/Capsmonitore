#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Qurilma reporter — caps-unified yonida ishlaydi, bot kodiga tegmaydi.
Faqat: register, heartbeat, ixtiyoriy UA check.
"""
from __future__ import annotations
import argparse, json, os, platform, sys, time
from pathlib import Path

try:
    import requests
except ImportError:
    print("pip install requests"); raise

def find_root():
    # server/ ichidan ishga tushsa parent = caps-unified
    here = Path(__file__).resolve().parent
    if (here.parent / "run.py").is_file() or (here.parent / "app.py").is_file():
        return here.parent
    return Path(os.environ.get("CAPS_ROOT") or ".")

def scan(root: Path):
    out = {"accounts": 0, "online": 0, "claims_today": 0, "coins": {}}
    if not root.is_dir():
        return out
    for p in root.rglob("panel_status.json"):
        try:
            j = json.loads(p.read_text(encoding="utf-8"))
            out["accounts"] += 1
            st = (j.get("status") or "").upper()
            if st in ("RUN", "OK", "CAP", "WAIT", "WARN"):
                out["online"] += 1
            out["claims_today"] += int(j.get("claims_today") or 0)
            coin = (j.get("coin") or "").upper()
            if not coin:
                coin = p.parent.name.split("_")[0].upper()
            out["coins"][coin] = out["coins"].get(coin, 0) + 1
        except Exception:
            pass
    return out

def scan_uas(root: Path):
    """config lardan UA yigish — hub check."""
    items = []
    for cfg in root.rglob("config*.json"):
        try:
            j = json.loads(cfg.read_text(encoding="utf-8"))
            j0 = j["accounts"][0] if isinstance(j.get("accounts"), list) and j["accounts"] else j
            ua = (j0.get("user_agent") or j.get("user_agent") or "").strip()
            if not ua:
                continue
            folder = cfg.parent.name
            coin = folder.split("_")[0].upper() if "_" in folder else ""
            items.append((cfg, folder, coin, ua, j))
        except Exception:
            pass
    return items

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hub", required=True)
    ap.add_argument("--code", default="")
    ap.add_argument("--name", default="")
    ap.add_argument("--token", default="")
    ap.add_argument("--token-file", default="")
    ap.add_argument("--caps-root", default="")
    ap.add_argument("--check-ua", action="store_true", help="UA konflikt tekshir + config yozish")
    ap.add_argument("--once", action="store_true")
    args = ap.parse_args()
    hub = args.hub.rstrip("/")
    root = Path(args.caps_root) if args.caps_root else find_root()
    tf = Path(args.token_file) if args.token_file else (Path(__file__).parent / "device_token.txt")
    tok = (args.token or "").strip() or (tf.read_text().strip() if tf.is_file() else "")
    name = args.name or platform.node() or "device"

    if not tok:
        if not args.code:
            print("TG bot: /device → kod\n  python server/reporter.py --hub URL --code 123456 --name phone1")
            sys.exit(1)
        r = requests.post(hub + "/api/device/register", json={"name": name, "code": args.code, "platform": sys.platform}, timeout=30)
        j = r.json()
        if not j.get("ok"):
            print("fail", j); sys.exit(1)
        tok = j["token"]
        tf.write_text(tok + "\n")
        print("OK token:", tf)

    print("hub", hub, "token", tok[:8] + "…", "root", root)

    if args.check_ua:
        for cfg, folder, coin, ua, j in scan_uas(root):
            try:
                r = requests.post(hub + "/api/ua/check", json={"user_agent": ua, "account_key": folder, "coin": coin},
                                  headers={"X-Device-Token": tok}, timeout=20)
                res = r.json()
                if res.get("replace") and res.get("user_agent"):
                    new = res["user_agent"]
                    if isinstance(j.get("accounts"), list) and j["accounts"]:
                        j["accounts"][0]["user_agent"] = new
                    else:
                        j["user_agent"] = new
                    cfg.write_text(json.dumps(j, ensure_ascii=False, indent=2), encoding="utf-8")
                    print("[UA fixed]", folder)
                else:
                    print("[UA ok]", folder, res.get("status"))
            except Exception as e:
                print("[UA]", folder, e)

    while True:
        payload = scan(root)
        try:
            r = requests.post(hub + "/api/device/heartbeat", json=payload, headers={"X-Device-Token": tok}, timeout=20)
            print(time.strftime("%H:%M:%S"), r.status_code, f"akk={payload['accounts']} on={payload['online']}")
        except Exception as e:
            print("hb", e)
        if args.once:
            break
        time.sleep(50)

if __name__ == "__main__":
    main()
