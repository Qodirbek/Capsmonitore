# server/ — CAPS Monitor (Render free)

**Asosiy caps-unified kodiga tegilmagan.** Botlar qurilmada ishlaydi.

## Maqsad
- Ko‘p qurilma / 100–500 akk monitoring (faqat sonlar)
- TG orqali new device kodi
- Bir valyutada bir xil User-Agent bo‘lmasin

## Render
1. Shu `server/` papkasini deploy qiling
2. Env: `SECRET_KEY`, `TG_BOT_TOKEN`, `TG_ADMIN_IDS`, `HUB_PUBLIC_URL`
3. Ixtiyoriy: Render PostgreSQL → `DATABASE_URL`
4. Start: `gunicorn -b 0.0.0.0:$PORT -w 1 --threads 2 app:app`

Webhook:
`https://api.telegram.org/botTOKEN/setWebhook?url=https://xxx.onrender.com/tg/webhook`

## Qurilma
```bash
# TG: /device → kod
cd caps-unified
python server/reporter.py --hub https://xxx.onrender.com --code 123456 --name phone1
# fon
python server/reporter.py --hub URL --token-file server/device_token.txt &
# UA tekshir (ixtiyoriy)
python server/reporter.py --hub URL --check-ua --once
```

Reyting: hub saytida qurilmalar akk soni (15, 18…) — batafsil balanc qurilmada qoladi.
