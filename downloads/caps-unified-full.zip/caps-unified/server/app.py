#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""CAPS Monitor Server — Render free, yengil.
Maqsad: qurilmalar monitoring, TG kod, UA konflikt (bir valyutada bir xil UA yo'q).
Bot/claim ISHLAMAYDI — faqat hisob-kitob.
"""
from __future__ import annotations
import hashlib, json, os, random, re, secrets, string, threading, time
from functools import wraps
from pathlib import Path
from flask import Flask, jsonify, request, Response, render_template_string

SECRET_KEY = os.environ.get("SECRET_KEY") or secrets.token_hex(16)
ADMIN_TOKEN = os.environ.get("ADMIN_TOKEN") or ""
TG_BOT_TOKEN = (os.environ.get("TG_BOT_TOKEN") or "").strip()
TG_ADMIN_IDS = {int(x) for x in re.findall(r"-?\d+", os.environ.get("TG_ADMIN_IDS") or "")}
HUB_URL = (os.environ.get("HUB_PUBLIC_URL") or "").rstrip("/")
DATABASE_URL = os.environ.get("DATABASE_URL") or os.environ.get("POSTGRES_URL") or ""
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = "postgresql://" + DATABASE_URL[len("postgres://"):]

DATA = Path(__file__).resolve().parent / "data"
DATA.mkdir(exist_ok=True)
app = Flask(__name__)
app.secret_key = SECRET_KEY
_lock = threading.RLock()
_PG = bool(DATABASE_URL.startswith("postgres"))

def now():
    return int(time.time())

def _conn():
    if _PG:
        import psycopg2
        return psycopg2.connect(DATABASE_URL)
    import sqlite3
    c = sqlite3.connect(str(DATA / "hub.db"), check_same_thread=False, timeout=20)
    c.row_factory = sqlite3.Row
    return c

def db(sql, args=(), fetch=None):
    with _lock:
        c = _conn()
        try:
            if _PG:
                import psycopg2.extras
                c.autocommit = True
                cur = c.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
                cur.execute(sql.replace("?", "%s"), args)
                if fetch == "one":
                    r = cur.fetchone(); return dict(r) if r else None
                if fetch == "all":
                    return [dict(x) for x in cur.fetchall()]
                return None
            cur = c.execute(sql, args)
            if fetch == "one":
                r = cur.fetchone(); return dict(r) if r else None
            if fetch == "all":
                return [dict(x) for x in cur.fetchall()]
            c.commit(); return None
        finally:
            try: c.close()
            except Exception: pass

def init_db():
    if _PG:
        qs = [
            "CREATE TABLE IF NOT EXISTS devices (id SERIAL PRIMARY KEY, token TEXT UNIQUE, name TEXT, platform TEXT, tg_id BIGINT, phone TEXT, last_seen BIGINT, status TEXT, created_at BIGINT)",
            "CREATE TABLE IF NOT EXISTS codes (id SERIAL PRIMARY KEY, code TEXT, purpose TEXT, tg_id BIGINT, expires_at BIGINT, used INT DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS stats (token TEXT PRIMARY KEY, accounts INT, online INT, claims_today INT, coins_json TEXT, updated_at BIGINT)",
            "CREATE TABLE IF NOT EXISTS uas (id SERIAL PRIMARY KEY, ua_hash TEXT UNIQUE, user_agent TEXT, token TEXT, account_key TEXT, coin TEXT, updated_at BIGINT)",
        ]
    else:
        qs = [
            "CREATE TABLE IF NOT EXISTS devices (id INTEGER PRIMARY KEY AUTOINCREMENT, token TEXT UNIQUE, name TEXT, platform TEXT, tg_id INTEGER, phone TEXT, last_seen INTEGER, status TEXT, created_at INTEGER)",
            "CREATE TABLE IF NOT EXISTS codes (id INTEGER PRIMARY KEY AUTOINCREMENT, code TEXT, purpose TEXT, tg_id INTEGER, expires_at INTEGER, used INTEGER DEFAULT 0)",
            "CREATE TABLE IF NOT EXISTS stats (token TEXT PRIMARY KEY, accounts INTEGER, online INTEGER, claims_today INTEGER, coins_json TEXT, updated_at INTEGER)",
            "CREATE TABLE IF NOT EXISTS uas (id INTEGER PRIMARY KEY AUTOINCREMENT, ua_hash TEXT UNIQUE, user_agent TEXT, token TEXT, account_key TEXT, coin TEXT, updated_at INTEGER)",
        ]
    for q in qs:
        try: db(q)
        except Exception as e: print("[db]", e)

init_db()

def tg(chat_id, text):
    if not TG_BOT_TOKEN or not chat_id: return False
    try:
        import requests
        return requests.post(
            f"https://api.telegram.org/bot{TG_BOT_TOKEN}/sendMessage",
            json={"chat_id": chat_id, "text": text[:3500], "parse_mode": "HTML"},
            timeout=12,
        ).ok
    except Exception as e:
        print("[tg]", e); return False

def code6():
    return "".join(random.choices(string.digits, k=6))

def ua_hash(ua):
    return hashlib.sha256((ua or "").encode()).hexdigest()[:32]

UA_TPL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v}.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:{v}.0) Gecko/20100101 Firefox/{v}.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v}.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v}.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android {a}; Pixel {p}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{v}.0.0.0 Mobile Safari/537.36",
]

def gen_ua(used):
    for _ in range(60):
        ua = random.choice(UA_TPL).format(v=random.randint(118,131), a=random.randint(11,14), p=random.randint(6,8))
        h = ua_hash(ua)
        if h not in used:
            return ua, h
    ua = f"Mozilla/5.0 (compatible; CAPS/{secrets.token_hex(3)})"
    return ua, ua_hash(ua)

def require_dev(f):
    @wraps(f)
    def w(*a, **k):
        tok = request.headers.get("X-Device-Token") or (request.json or {}).get("token") if request.is_json else None
        if not tok:
            return jsonify({"ok": False, "error": "token"}), 401
        d = db("SELECT * FROM devices WHERE token=?", (tok,), fetch="one")
        if not d or d.get("status") == "blocked":
            return jsonify({"ok": False, "error": "device"}), 401
        request.device = d
        return f(*a, **k)
    return w

HTML = """<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>CAPS Monitor</title>
<style>
body{margin:0;font-family:system-ui;background:#0b1220;color:#e2e8f0;padding:16px}
.card{background:#121a2b;border:1px solid #1e293b;border-radius:12px;padding:14px;margin:10px 0}
.g{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px}
.k{color:#94a3b8;font-size:12px}.v{font-size:22px;font-weight:700}
table{width:100%;border-collapse:collapse;font-size:13px}td,th{padding:8px;border-bottom:1px solid #1e293b;text-align:left}
.ok{color:#22c55e}.w{color:#f59e0b} code{font-size:11px;opacity:.8}
</style></head><body>
<h2 style="margin:0">CAPS Monitor</h2>
<p style="color:#94a3b8;font-size:13px">Faqat monitoring · UA · TG kod · Render free</p>
<div class=g id=s></div>
<div class=card><h3>Qurilmalar / reyting</h3>
<table><thead><tr><th>#</th><th>Qurilma</th><th>Akk</th><th>Online</th><th>Claims</th><th>Coins</th><th>Seen</th></tr></thead>
<tbody id=t></tbody></table></div>
<div class=card><b>New device</b><br>
1) TG: /device → kod<br>
2) <code>python server/reporter.py --hub URL --code KOD --name phone1</code><br>
3) caps-unified odatdagidek ishlayveradi
</div>
<script>
async function L(){
  const j=await fetch('/api/summary').then(r=>r.json());
  document.getElementById('s').innerHTML=`
  <div class=card><div class=k>Qurilmalar</div><div class=v>${j.devices}</div></div>
  <div class=card><div class=k>Online</div><div class="v ok">${j.online}</div></div>
  <div class=card><div class=k>Jami akk</div><div class=v>${j.accounts}</div></div>
  <div class=card><div class=k>Claims</div><div class=v>${j.claims}</div></div>
  <div class=card><div class=k>UA</div><div class=v>${j.uas}</div></div>`;
  document.getElementById('t').innerHTML=(j.rank||[]).map((d,i)=>`<tr>
  <td>${i+1}</td><td>${d.name||'—'}<br><code>${(d.token||'').slice(0,8)}</code></td>
  <td><b>${d.accounts||0}</b></td><td>${d.online||0}</td><td>${d.claims||0}</td>
  <td>${d.coins||'—'}</td><td class="${d.alive?'ok':'w'}">${d.ago}</td></tr>`).join('')||'<tr><td colspan=7>Bo‘sh</td></tr>';
}
L();setInterval(L,10000);
</script></body></html>"""

@app.get("/")
def home():
    return render_template_string(HTML)

@app.get("/health")
def health():
    return jsonify({"ok": True, "db": "pg" if _PG else "sqlite", "ts": now()})

@app.post("/api/device/register")
def register():
    b = request.get_json(force=True, silent=True) or {}
    code = (b.get("code") or "").strip()
    name = (b.get("name") or "device").strip()[:48]
    if not code:
        return jsonify({"ok": False, "error": "TG /device kodi kerak"}), 400
    row = db("SELECT * FROM codes WHERE code=? AND purpose='device' AND used=0 ORDER BY id DESC LIMIT 1", (code,), fetch="one")
    if not row or int(row.get("expires_at") or 0) < now():
        return jsonify({"ok": False, "error": "kod xato/eskirgan"}), 400
    tok = secrets.token_urlsafe(20)
    db("INSERT INTO devices(token,name,platform,tg_id,phone,last_seen,status,created_at) VALUES (?,?,?,?,?,?,?,?)",
       (tok, name, (b.get("platform") or "")[:32], row.get("tg_id"), (b.get("phone") or "")[:20], now(), "active", now()))
    db("UPDATE codes SET used=1 WHERE id=?", (row["id"],))
    if row.get("tg_id"):
        tg(row["tg_id"], f"✅ Qurilma: <b>{name}</b>\n<code>{tok[:10]}…</code>")
    return jsonify({"ok": True, "token": tok})

@app.post("/api/device/heartbeat")
@require_dev
def heartbeat():
    d = request.device
    b = request.get_json(force=True, silent=True) or {}
    tok = d["token"]
    db("UPDATE devices SET last_seen=?, status='active' WHERE token=?", (now(), tok))
    acc, on, cl = int(b.get("accounts") or 0), int(b.get("online") or 0), int(b.get("claims_today") or 0)
    coins = json.dumps(b.get("coins") or {})
    ex = db("SELECT token FROM stats WHERE token=?", (tok,), fetch="one")
    if ex:
        db("UPDATE stats SET accounts=?,online=?,claims_today=?,coins_json=?,updated_at=? WHERE token=?",
           (acc, on, cl, coins, now(), tok))
    else:
        db("INSERT INTO stats(token,accounts,online,claims_today,coins_json,updated_at) VALUES (?,?,?,?,?,?)",
           (tok, acc, on, cl, coins, now()))
    return jsonify({"ok": True, "ts": now()})

@app.post("/api/ua/check")
@require_dev
def ua_check():
    """Bir valyutada bir xil UA bo'lmasin. Konflikt bo'lsa yangi UA + TG ogohlantirish."""
    d = request.device
    b = request.get_json(force=True, silent=True) or {}
    ua = (b.get("user_agent") or "").strip()
    key = (b.get("account_key") or b.get("folder") or "").strip()[:100]
    coin = (b.get("coin") or "").upper()[:12]
    if not ua:
        return jsonify({"ok": False, "error": "user_agent"}), 400
    h = ua_hash(ua)
    rows = db("SELECT * FROM uas", fetch="all") or []
    used = {r["ua_hash"] for r in rows}
    conflict = None
    for r in rows:
        if r["ua_hash"] == h:
            # same device+account ok
            if r.get("token") == d["token"] and r.get("account_key") == key:
                db("UPDATE uas SET updated_at=?, coin=? WHERE ua_hash=?", (now(), coin, h))
                return jsonify({"ok": True, "status": "ok", "user_agent": ua})
            # same coin conflict (or any if coin empty match other coin same ua)
            if (coin and (r.get("coin") or "").upper() == coin) or True:
                # global unique UA preferred
                conflict = r
                break
    if not conflict:
        try:
            db("INSERT INTO uas(ua_hash,user_agent,token,account_key,coin,updated_at) VALUES (?,?,?,?,?,?)",
               (h, ua, d["token"], key, coin, now()))
        except Exception:
            db("UPDATE uas SET token=?,account_key=?,coin=?,updated_at=?,user_agent=? WHERE ua_hash=?",
               (d["token"], key, coin, now(), ua, h))
        return jsonify({"ok": True, "status": "registered", "user_agent": ua})

    # conflict → yangi UA
    new_ua, nh = gen_ua(used | {h})
    try:
        db("INSERT INTO uas(ua_hash,user_agent,token,account_key,coin,updated_at) VALUES (?,?,?,?,?,?)",
           (nh, new_ua, d["token"], key, coin, now()))
    except Exception:
        new_ua, nh = gen_ua(used | {h, nh})
        db("INSERT INTO uas(ua_hash,user_agent,token,account_key,coin,updated_at) VALUES (?,?,?,?,?,?)",
           (nh, new_ua, d["token"], key, coin, now()))

    # TG notify both if possible
    msg = f"⚠️ UA konflikt ({coin or '?'})\nAkk: <code>{key}</code>\nYangi UA berildi — config ga yozing."
    if d.get("tg_id"):
        tg(d["tg_id"], msg + f"\n<code>{new_ua[:80]}…</code>")
    other = db("SELECT tg_id FROM devices WHERE token=?", (conflict.get("token"),), fetch="one")
    if other and other.get("tg_id") and other["tg_id"] != d.get("tg_id"):
        tg(other["tg_id"], f"⚠️ Sizning UA boshqa qurilmada ham topildi ({coin}). Hub yangi UA tavsiya qildi.")

    return jsonify({"ok": True, "status": "conflict", "user_agent": new_ua, "replace": True})

@app.get("/api/summary")
def summary():
    devices = db("SELECT * FROM devices ORDER BY id", fetch="all") or []
    stats = {s["token"]: s for s in (db("SELECT * FROM stats", fetch="all") or [])}
    t = now()
    online = accounts = claims = 0
    rank = []
    for d in devices:
        st = stats.get(d["token"]) or {}
        alive = (t - int(d.get("last_seen") or 0)) < 120
        if alive: online += 1
        accounts += int(st.get("accounts") or 0)
        claims += int(st.get("claims_today") or 0)
        try:
            coins = json.loads(st.get("coins_json") or "{}")
            coins_s = " ".join(f"{k}:{v}" for k,v in coins.items())
        except Exception:
            coins_s = "—"
        ago = t - int(d.get("last_seen") or 0)
        rank.append({
            "name": d.get("name"), "token": d.get("token"), "alive": alive,
            "accounts": int(st.get("accounts") or 0), "online": int(st.get("online") or 0),
            "claims": int(st.get("claims_today") or 0), "coins": coins_s,
            "ago": f"{ago}s" if d.get("last_seen") else "—",
        })
    rank.sort(key=lambda x: -x["accounts"])
    uas = db("SELECT COUNT(*) AS c FROM uas", fetch="one")
    return jsonify({
        "ok": True, "devices": len(devices), "online": online,
        "accounts": accounts, "claims": claims, "uas": (uas or {}).get("c") or 0,
        "rank": rank, "db": "pg" if _PG else "sqlite",
    })

@app.post("/tg/webhook")
def tg_webhook():
    if not TG_BOT_TOKEN:
        return jsonify({"ok": False}), 503
    upd = request.get_json(force=True, silent=True) or {}
    msg = upd.get("message") or {}
    chat_id = (msg.get("chat") or {}).get("id")
    text = (msg.get("text") or "").strip()
    if not chat_id or not text:
        return jsonify({"ok": True})
    if text.startswith("/start"):
        tg(chat_id, "CAPS Monitor\n/device — yangi qurilma kodi\n/status — (admin)")
    elif text.startswith("/device"):
        if TG_ADMIN_IDS and int(chat_id) not in TG_ADMIN_IDS:
            tg(chat_id, "Ruxsat yo‘q"); return jsonify({"ok": True})
        c = code6()
        db("INSERT INTO codes(code,purpose,tg_id,expires_at,used) VALUES (?,?,?,?,0)",
           (c, "device", int(chat_id), now() + 900))
        hub = HUB_URL or "https://YOUR.onrender.com"
        tg(chat_id, f"📱 Kod: <b>{c}</b> (15 min)\n\n<code>python server/reporter.py --hub {hub} --code {c} --name mydevice</code>")
    elif text.startswith("/status"):
        if TG_ADMIN_IDS and int(chat_id) not in TG_ADMIN_IDS:
            tg(chat_id, "Admin emas"); return jsonify({"ok": True})
        n = db("SELECT COUNT(*) AS c FROM devices", fetch="one")
        tg(chat_id, f"Devices: {(n or {}).get('c')}")
    return jsonify({"ok": True})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT") or 8080))
