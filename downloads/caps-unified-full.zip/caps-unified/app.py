#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""python app.py → background | python run.py → foreground logs"""
from __future__ import annotations
import os, sys, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
LOG = DATA / "caps.log"
PID = DATA / "caps.pid"

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0); return True
    except Exception:
        return False

def main():
    args = [a for a in sys.argv[1:]]
    if "--stop" in args:
        if PID.is_file():
            try:
                pid = int(PID.read_text().strip())
                os.kill(pid, 15)
                print("stopped", pid)
            except Exception as e:
                print("stop:", e)
            PID.unlink(missing_ok=True)
        return
    fg = "--fg" in args or "--foreground" in args
    args = [a for a in args if a not in ("--fg", "--foreground", "--daemon", "--stop")]
    if not fg:
        if PID.is_file():
            try:
                pid = int(PID.read_text().strip())
                if _alive(pid):
                    print(f"already running pid={pid}\nlog: {LOG}\nstop: python app.py --stop")
                    return
            except Exception:
                pass
        logf = open(LOG, "a", encoding="utf-8")
        cmd = [sys.executable, str(ROOT / "run.py")] + args
        p = subprocess.Popen(cmd, cwd=str(ROOT), stdout=logf, stderr=subprocess.STDOUT, start_new_session=True)
        PID.write_text(str(p.pid), encoding="utf-8")
        print(f"CAPS background pid={p.pid}\nlog: {LOG}\nstop: python app.py --stop")
        return
    os.chdir(ROOT)
    sys.argv = [sys.argv[0]] + args
    from run import main as run_main
    run_main()

if __name__ == "__main__":
    main()
