#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from app.db import init_db, DB_PATH, DATA
from app import manager as M

def main():
    print("DB:", DB_PATH)
    DATA.mkdir(parents=True, exist_ok=True)
    try:
        print("stop bots:", M.stop_all_bots())
    except Exception as e:
        print("stop:", e)
    init_db()
    print("init_db OK")
    n = M.import_existing_folders()
    print("imported:", n)
    accs = M.list_accounts()
    print("total accounts:", len(accs))
    for a in accs[:25]:
        print(f"  {a.get('folder'):24} {a.get('coin'):4} {a.get('label') or '—'}")
    print("Done → python run.py --port 5051")

if __name__ == "__main__":
    main()
