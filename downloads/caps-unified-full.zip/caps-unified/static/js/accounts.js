
let page=1,per=15,all=[];
async function loadAcc(){
  const qs=new URLSearchParams({
    q:document.getElementById('q').value,
    currency:document.getElementById('cur').value,
    status:document.getElementById('st').value,
    sort:document.getElementById('sort').value
  });
  const [data,st]=await Promise.all([api('/api/accounts?'+qs),api('/api/statistics')]);
  setPrices(st); all=data.accounts||[];
  document.getElementById('liveText').textContent=`${all.length} acc · LIVE`;
  page=1; render();
}
function render(){
  const start=(page-1)*per, slice=all.slice(start,start+per);
  document.getElementById('accBody').innerHTML=slice.map((a,i)=>`
    <tr class="clickable" onclick="location.href='/profile/${a.id}'">
      <td>${start+i+1}</td><td>${esc(a.folder)}</td><td><b>${esc(a.username)}</b></td>
      <td>${ICO[a.currency]||'•'} ${a.currency}</td><td>${fmtBal(a.balance)}</td>
      <td>${fmtUsd(usd(a.currency,a.balance))}</td><td>${tag(a.status)}</td>
      <td>${a.claims_today||0}</td>
      <td>${a.has_cookie?'✓':'✗'}</td><td>${a.has_live_status?'✓':'✗'}</td>
      <td><button class="btn btn-blue btn-sm" onclick="event.stopPropagation();location.href='/profile/${a.id}'">View</button></td>
    </tr>`).join('')||'<tr><td colspan="11" class="empty">Bo\'sh — caps papkani tekshiring</td></tr>';
  const pages=Math.max(1,Math.ceil(all.length/per));
  let pg=''; for(let i=1;i<=pages;i++) pg+=`<button class="btn ${i===page?'btn-gold':'btn-ghost'} btn-sm" onclick="page=${i};render()">${i}</button>`;
  document.getElementById('pager').innerHTML=pg;
}
function exportCsv(){
  const head=['folder','username','currency','balance','status','claims_today','has_cookie'];
  const lines=[head.join(',')].concat(all.map(a=>head.map(h=>JSON.stringify(a[h]??'')).join(',')));
  const blob=new Blob([lines.join('\n')],{type:'text/csv'});
  const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='caps_live.csv'; a.click();
}
loadAcc();
