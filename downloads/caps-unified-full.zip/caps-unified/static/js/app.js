/* CAPS helpers — fixed */

const NAV_SVG = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1v-9.5z"/></svg>',
  accounts: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/></svg>',
  add: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 8v8M8 12h8"/></svg>',
  create: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>',
  currencies: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M12 6v12M15.5 9.5c0-1.5-1.5-2.5-3.5-2.5S8.5 8 8.5 9.5 10 11.5 12 12s3.5 1 3.5 2.5S14 17 12 17s-3.5-1-3.5-2.5"/></svg>',
  analytics: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19V5M4 19h16"/><path d="M8 16v-5M12 16V8M16 16v-3"/></svg>',
  alerts: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 106 8c0 7-3 7-3 7h18s-3 0-3-7"/><path d="M13.7 21a2 2 0 01-3.4 0"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>',
  crown: '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M3 17l2-9 4 4 3-7 3 7 4-4 2 9H3zm1 2h16v2H4v-2z"/></svg>'
};
function navIco(key){ return '<span class="nav-ico">'+(NAV_SVG[key]||NAV_SVG.dashboard)+'</span>'; }

function installBottomNav(){
  if (document.querySelector('.bottom-nav')) return;
  const path = (location.pathname||'/').replace(/\/$/,'') || '/';
  const items = [
    {href:'/', key:'dashboard', label:'Home', match:p=>p==='/'||p===''},
    {href:'/accounts', key:'accounts', label:'Accounts', match:p=>p.startsWith('/accounts')||p.startsWith('/profile')},
    {href:'/add', key:'add', label:'Add', match:p=>p==='/add'||p==='/register'},
    {href:'/currencies', key:'currencies', label:'Coins', match:p=>p.startsWith('/currencies')},
    {href:'/settings', key:'settings', label:'More', match:p=>p.startsWith('/settings')||p.startsWith('/analytics')||p.startsWith('/alerts')},
  ];
  const nav = document.createElement('nav');
  nav.className = 'bottom-nav';
  nav.innerHTML = items.map(it=>{
    const on = it.match(path) ? ' on' : '';
    return '<a href="'+it.href+'" class="'+on.trim()+'">'+navIco(it.key)+'<span>'+it.label+'</span></a>';
  }).join('');
  document.body.appendChild(nav);
}

function enhanceSideNavIcons(){
  const map = [['/','dashboard'],['/accounts','accounts'],['/add','add'],['/register','create'],
    ['/currencies','currencies'],['/analytics','analytics'],['/alerts','alerts'],['/settings','settings']];
  document.querySelectorAll('.side nav a').forEach(a=>{
    const href = a.getAttribute('href')||'';
    const hit = map.find(m=>m[0]===href);
    if (!hit) return;
    // remove emoji / first span text icons
    const spans = a.querySelectorAll('span');
    if (spans.length) {
      const first = spans[0];
      if (!first.classList.contains('nav-ico')) first.outerHTML = navIco(hit[1]);
    } else {
      a.insertAdjacentHTML('afterbegin', navIco(hit[1]));
    }
  });
  // brand crown
  document.querySelectorAll('.side .brand .ico, .logo .ico').forEach(el=>{
    if (!el.querySelector('svg')) el.innerHTML = NAV_SVG.crown;
  });
}


const COIN_CSS={TON:'ton',TRX:'trx',SUI:'sui',DOGE:'doge',LTC:'ltc',SOL:'sol'};

async function api(url, opt){
  opt = opt||{};
  const headers = Object.assign({}, opt.headers||{});
  if(opt.body && !headers['Content-Type']) headers['Content-Type']='application/json';
  // timeout: ms (default 25s). Register/captcha uchun katta qiymat bering.
  const ms = (opt.timeout != null) ? Number(opt.timeout) : 25000;
  const rest = Object.assign({}, opt);
  delete rest.timeout;
  let ctrl = null, to = null;
  if(ms > 0 && !rest.signal){
    ctrl = new AbortController();
    rest.signal = ctrl.signal;
    to = setTimeout(function(){ try{ ctrl.abort(); }catch(e){} }, ms);
  }
  try{
    const r = await fetch(url, Object.assign({}, rest, {headers: headers}));
    let j={}; try{j=await r.json()}catch(e){}
    if(!r.ok) throw new Error(j.error||('HTTP '+r.status));
    return j;
  }catch(e){
    if(e && (e.name==='AbortError' || /aborted/i.test(String(e.message||e))))
      throw new Error('Vaqt tugadi (timeout). Captcha uzoq ketgan bo\'lishi mumkin — qayta urinib ko\'ring.');
    throw e;
  } finally {
    if(to) clearTimeout(to);
  }
}
function tag(s){
  s=String(s||'—').toUpperCase();
  return '<span class="tag tag-'+s.slice(0,8)+'">'+s+'</span>';
}
function esc(t){
  return String(t==null?'':t).replace(/[&<>"']/g, function(m){
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}
function fmtBal(b){
  if(b==null||b==='—') return '—';
  const n=Number(b);
  if(isNaN(n)) return String(b);
  if(Math.abs(n)>=1000) return n.toFixed(4);
  if(Math.abs(n)>=1) return n.toFixed(6);
  return n.toFixed(9);
}
function money(n){ return '$'+(Number(n)||0).toFixed(2); }
function money4(n){ return '$'+(Number(n)||0).toFixed(4); }

function coinSvg(coin, lg){
  const c=(coin||'').toUpperCase();
  const map={
    TON:{cls:'coin-ton',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#0098EA"/><path d="M10.5 13.5h19l-9.5 16.2L10.5 13.5zm4.2 2.4l5.3 9 5.3-9H14.7z" fill="#fff"/></svg>'},
    TRX:{cls:'coin-trx',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#FF0013"/><path d="M11 12.5L20 28.5 29 12.5 20 16.2 11 12.5zm3.2 1.8L20 17.8l5.8-3.5L20 25.2 14.2 14.3z" fill="#fff"/></svg>'},
    SUI:{cls:'coin-sui',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#4DA2FF"/><path d="M20 8c-2.8 5.2-7 8.2-7 13.2a7 7 0 0014 0C27 16.2 22.8 13.2 20 8z" fill="#fff"/></svg>'},
    DOGE:{cls:'coin-doge',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#C2A633"/><path d="M15 12h7.2a5.2 5.2 0 010 10.4H18v3.6h-3V12zm3 2.6v5.2h4.2a2.6 2.6 0 000-5.2H18z" fill="#fff"/></svg>'},
    LTC:{cls:'coin-ltc',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#345D9D"/><path d="M17.2 10h4.2l-1.6 8.2H26l-.8 3.4h-6.4L17.4 30h-4.2l1.8-8.4H11l.8-3.4h4.6L17.2 10z" fill="#fff"/></svg>'},
    SOL:{cls:'coin-sol',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="url(#sg)"/><defs><linearGradient id="sg" x1="8" y1="32" x2="32" y2="8"><stop stop-color="#9945FF"/><stop offset="1" stop-color="#14F195"/></linearGradient></defs><path d="M12 24.2l2.6 2.6h14.2L26.2 24.2H12zm0-5.5l2.6 2.6h14.2l-2.6-2.6H12zM14.6 13l-2.6 2.6h14.2L28.8 13H14.6z" fill="#fff"/></svg>'},
    POL:{cls:'coin-pol',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#8247E5"/><path d="M20 9l8 4.6v9.2L20 27.4 12 22.8v-9.2L20 9zm0 3.2l-5 2.9v5.8l5 2.9 5-2.9v-5.8l-5-2.9z" fill="#fff"/></svg>'}
  };
  const m=map[c]||{cls:'',svg:'<svg viewBox="0 0 40 40" fill="none"><circle cx="20" cy="20" r="20" fill="#334155"/><circle cx="20" cy="20" r="8" fill="#94a3b8"/></svg>'};
  return '<span class="coin-svg '+m.cls+(lg?' svg-lg':'')+'">'+m.svg+'</span>';
}
function fmtUsdBal(coin, bal, prices){
  if(bal==null||!prices) return '';
  const px=prices[coin];
  if(!px) return '';
  return money4(Number(bal)*Number(px));
}
function levelBadge(lvl){
  if(!lvl) return '—';
  return '<span class="badge ok">'+esc(String(lvl))+'</span>';
}
function chgHtml(pct){
  if(pct==null||isNaN(Number(pct))) return '<span class="chg">—</span>';
  const p=Number(pct);
  const up=p>=0;
  return '<span class="chg '+(up?'up':'down')+'">'+(up?'▲':'▼')+' '+Math.abs(p).toFixed(1)+'%</span>';
}
function initShell(){
  const side=document.querySelector('.side');
  const bak=document.querySelector('.side-backdrop');
  const btn=document.querySelector('.burger');
  if(!side||!btn) return;
  const close=function(){ side.classList.remove('open'); if(bak) bak.classList.remove('show'); document.body.style.overflow=''; };
  const open=function(){ side.classList.add('open'); if(bak) bak.classList.add('show'); document.body.style.overflow='hidden'; };
  btn.addEventListener('click', function(){ side.classList.contains('open')?close():open(); });
  if(bak) bak.addEventListener('click', close);
  side.querySelectorAll('a').forEach(function(a){ a.addEventListener('click', close); });
}
document.addEventListener('DOMContentLoaded', initShell);

document.addEventListener('DOMContentLoaded', function(){
  document.querySelectorAll('table').forEach(function(tb){
    if (tb.parentElement && tb.parentElement.classList.contains('table-wrap')) return;
    var w=document.createElement('div'); w.className='table-wrap';
    tb.parentNode.insertBefore(w, tb); w.appendChild(tb);
  });
});

document.addEventListener('DOMContentLoaded', function(){
  try{ enhanceSideNavIcons(); }catch(e){}
  try{ installBottomNav(); }catch(e){}
});
