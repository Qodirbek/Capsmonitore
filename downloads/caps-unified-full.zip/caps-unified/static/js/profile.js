
function bar(pct, color){
  const p=Math.max(0,Math.min(100,Number(pct)||0));
  return `<div class="bar" style="margin-top:6px"><i style="width:${p}%;background:${color||'linear-gradient(90deg,#f5c542,#22d3ee)'}"></i></div>
    <div class="muted" style="font-size:11px;margin-top:4px">${p.toFixed(1)}%</div>`;
}
async function boot(){
  const [data,st]=await Promise.all([api('/api/accounts/'+window.ACCOUNT_ID), api('/api/statistics')]);
  setPrices(st);
  if(data.error){document.getElementById('profileRoot').innerHTML='<div class="empty">Topilmadi</div>';return;}
  const a=data.account;
  document.getElementById('ph').textContent=a.username;
  document.getElementById('pUser').textContent=a.username;
  document.getElementById('pMeta').textContent=`${a.folder} · ${a.currency} · ${a.email||''} · ${a.bot_script||''}`;
  document.getElementById('pStatus').innerHTML=tag(a.status)+(a.balance_sticky?' <span class="muted">· sticky</span>':'');
  document.getElementById('pBal').textContent=fmtBal(a.balance)+' '+(a.currency||'');
  const u=usd(a.currency,a.balance), px=PRICES[a.currency];
  document.getElementById('pUsd').textContent=(u!=null?fmtUsd(u):'—')+(px?` · 1 ${a.currency}=$${Number(px).toFixed(6)}`:'');
  document.getElementById('pNext').textContent=a.next_claim||'—';
  document.getElementById('pClaims').textContent=a.claims_today??'—';

  // progress section
  const left=a.claims_left;
  const stPct=a.stamina_pct;
  const wPct=a.wager_pct;
  let prog=`<div class="grid g3" style="margin-top:12px">`;
  if(left!=null){
    const leftPct=Math.min(100,(Number(left)/24)*100);
    prog+=`<div class="card"><div class="lab">Claims left</div><div class="num" style="font-size:22px">${left}</div>${bar(leftPct, left<=24?'#f87171':'#34d399')}</div>`;
  } else {
    prog+=`<div class="card"><div class="lab">Claims left</div><div class="num" style="font-size:18px">—</div></div>`;
  }
  if(stPct!=null){
    prog+=`<div class="card"><div class="lab">Stamina</div><div class="num" style="font-size:22px">${Number(stPct).toFixed(0)}%</div>${bar(stPct,'#22d3ee')}</div>`;
  } else {
    prog+=`<div class="card"><div class="lab">Stamina</div><div class="num" style="font-size:18px">${esc(a.stamina||'—')}</div></div>`;
  }
  if(wPct!=null){
    prog+=`<div class="card"><div class="lab">Wager</div><div class="num" style="font-size:22px">${Number(wPct).toFixed(0)}%</div>${bar(wPct,'#f5c542')}</div>`;
  } else {
    prog+=`<div class="card"><div class="lab">Wager</div><div class="num" style="font-size:18px">—</div></div>`;
  }
  prog+=`</div>`;
  const progEl=document.getElementById('pProg');
  if(progEl) progEl.innerHTML=prog;

  document.getElementById('pWal').textContent=a.wallet||'—';
  document.getElementById('pAuth').textContent=`Cookie: ${a.has_cookie?'yes':'no'} · Email: ${a.email||'—'} · Pass: ${a.has_password?'yes':'no'}`;
  document.getElementById('pFiles').innerHTML=`Path: <code>${esc(a.path||'')}</code><br/>Live: ${a.has_live_status?'✓':'—'} · Sticky bal: ${a.balance_sticky?'yes':'no'}`;

  const hist=data.history||a.claims_log||[];
  document.getElementById('pHist').innerHTML=hist.length?hist.slice().reverse().map(h=>`
    <li><span class="dot" style="background:${(h.status||'').toLowerCase().includes('fail')||(h.status||'').toLowerCase().includes('invalid')?'#f87171':'#34d399'}"></span>
    <div>
      <div><b>${esc(h.captcha||h.type||'Claim')}</b>
        <span style="color:var(--grn);font-weight:700">${esc(h.amount||h.value||'')}</span>
        <span class="tag tag-${(h.status||'OK').toUpperCase().slice(0,6)}" style="margin-left:6px">${esc(h.status||'accepted')}</span>
      </div>
      <div class="muted">${esc(h.time||h.date||'')} ${h.msg?('· '+esc(h.msg)):''}</div>
    </div></li>`).join(''):'<li class="empty">Hali claim log yo\'q — bot claims_log.json yozsa chiqadi</li>';
}
boot().catch(console.error);
