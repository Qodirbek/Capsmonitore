
async function boot(){
  let st={}, acc={accounts:[]}, sec={counts:{}}, prices={};
  try {
    const res = await Promise.all([
      api('/api/statistics').catch(()=>({})),
      api('/api/accounts').catch(()=>({accounts:[]})),
      api('/api/security').catch(()=>({counts:{}}))
    ]);
    st = res[0] || {};
    acc = res[1] || {accounts:[]};
    sec = res[2] || {counts:{}};
  } catch(e) { console.error(e); }
  try { setPrices(st); } catch(e) {}
  prices = (st.prices_usd||acc.prices_usd||{});
  const live = document.getElementById('liveText');
  if (live) live.textContent = `${st.online||0}/${st.total|| (acc.accounts||[]).length} LIVE`;
  const sub = document.getElementById('subRoot');
  if (sub) sub.textContent = st.caps_root ? ('Root: '+st.caps_root) : 'CAPS unified';
  const order=['DOGE','LTC','SUI','TON','TRX','SOL'];
  const coinEl = document.getElementById('coinCards');
  if (coinEl) {
    const totals = st.totals || {};
    coinEl.innerHTML = order.map(c=>{
      const v=totals[c]; const u=v!=null?usd(c,v):null; const px=prices[c];
      const pct=(st.pct_by_coin&&st.pct_by_coin[c]!=null)?st.pct_by_coin[c]:null;
      let pctHtml='';
      if(pct!=null){
        const up=pct>=0;
        pctHtml=`<span style="color:${up?'#34d399':'#f87171'};font-size:11px;font-weight:700">${up?'▲':'▼'} ${Math.abs(pct).toFixed(1)}%</span>`;
      }
      return `<div class="card coin-card"><div class="row"><div class="coin-ico ${c.toLowerCase()}">${(typeof ICO!=='undefined'&&ICO[c])||c}</div>
        <span class="muted">${c}</span></div>
        <div class="val">${v!=null?Number(v).toLocaleString('en-US',{maximumFractionDigits:4}):'—'}</div>
        <div class="chg">${u!=null?fmtUsd(u):(px?('$'+Number(px).toFixed(4)):'—')} ${pctHtml}</div></div>`;
    }).join('');
  }
  const pt=st.pct_total||0;
  const ptC=pt>=0?'#34d399':'#f87171';
  const statEl = document.getElementById('statCards');
  if (statEl) {
    statEl.innerHTML=`
    <div class="card stat"><div class="stat-row"><div><div class="lab">Accounts</div><div class="num">${st.total||(acc.accounts||[]).length||0}</div></div></div></div>
    <div class="card stat"><div class="stat-row"><div><div class="lab">Claims today</div><div class="num">${st.claims_today||0}</div></div></div></div>
    <div class="card stat"><div class="stat-row"><div><div class="lab">Waiting</div><div class="num">${st.waiting||0}</div></div></div></div>
    <div class="card stat"><div class="stat-row"><div><div class="lab">≈ USD</div><div class="num">$${(st.usd_total||0).toFixed(2)}</div>
      <div style="color:${ptC};font-size:12px;font-weight:700">${pt>=0?'▲':'▼'} ${Math.abs(pt).toFixed(1)}%</div></div></div></div>`;
  }
  const port = document.getElementById('portSum');
  if (port) port.textContent=`$${(st.usd_total||0).toFixed(2)}`;
  try {
    const h=st.history||{labels:[],values:[]};
    const canvas = document.getElementById('portChart');
    if (canvas && window.Chart) {
      if(window._pc) window._pc.destroy();
      window._pc=new Chart(canvas,{type:'line',data:{labels:h.labels||[],datasets:[{data:h.values||[],fill:true,borderColor:'#22d3ee',backgroundColor:'rgba(34,211,238,.15)',tension:.35,pointRadius:2}]},
        options:{plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#8b9bb8'},grid:{color:'#1e2d48'}},y:{ticks:{color:'#8b9bb8'},grid:{color:'#1e2d48'}}},maintainAspectRatio:false}});
    }
  } catch(e) {}
  const body = document.getElementById('previewBody');
  if (body) {
    const rows = (acc.accounts||[]);
    body.innerHTML = rows.slice(0,16).map((a,i)=>{
      const usdV = a.usd!=null ? money4(a.usd) : (typeof fmtUsdBal==='function' ? fmtUsdBal(a.coin||a.currency,a.balance,prices) : '');
      const name = esc(a.username||a.label||a.folder||'—');
      return `<tr class="acc-row" onclick="location.href='/profile/${a.id}'"><td class="c-num">${i+1}</td><td class="c-user"><span class="u-ico">${typeof coinSvg==='function'?coinSvg(a.coin||a.currency):''}</span><span class="u-meta"><span class="u-name">${name}</span><span class="u-coin">${esc((a.coin||a.currency||'').toUpperCase())}</span></span></td><td class="c-bal"><span class="b-main">${fmtBal(a.balance)}</span><span class="b-usd">${usdV||''}</span></td><td class="c-st">${typeof tag==='function'?tag(a.status):esc(a.status||'')}</td></tr>`;
    }).join('') || '<tr><td colspan="4" class="empty">Hisob yo\'q</td></tr>';
  }
  const secEl = document.getElementById('secSnap');
  if (secEl) {
    const c=sec.counts||{};
    secEl.innerHTML=`High: <b class="sev-high">${c.high||0}</b> · Medium: <b class="sev-medium">${c.medium||0}</b> · Low: ${c.low||0}`;
  }
}
boot().catch(e=>{console.error(e); const el=document.getElementById('liveText'); if(el) el.textContent='error'; const b=document.getElementById('previewBody'); if(b && b.textContent.includes('Loading')) b.innerHTML='<tr><td colspan="4" class="empty">Yuklash xato — qayta...</td></tr>';});
setInterval(()=>boot().catch(()=>{}), 8000);
