
async function boot(){
  const [cur,st]=await Promise.all([api('/api/currencies'), api('/api/statistics')]);
  setPrices(st);
  document.getElementById('liveText').textContent=`$${(st.usd_total||0).toFixed(2)}`;
  const order=['DOGE','LTC','SUI','TON','TRX'];
  document.getElementById('coinCards').innerHTML=order.map(c=>{
    const v=st.totals[c]; const u=v!=null?usd(c,v):null;
    return `<div class="card coin-card"><div class="row"><div class="coin-ico ${c.toLowerCase()}">${ICO[c]}</div><span class="muted">${c}</span></div>
      <div class="val">${v!=null?Number(v).toLocaleString('en-US',{maximumFractionDigits:4}):'—'}</div>
      <div class="chg">${u!=null?fmtUsd(u):'—'}</div></div>`;
  }).join('');
  const labels=order.filter(c=>st.totals[c]!=null);
  const data=labels.map(c=>st.usd_by_coin&&st.usd_by_coin[c]!=null?st.usd_by_coin[c]:0);
  if(window._d) window._d.destroy();
  window._d=new Chart(document.getElementById('donut'),{type:'doughnut',data:{labels,datasets:[{data,backgroundColor:['#f5c542','#94a3b8','#38bdf8','#60a5fa','#ff6b6b']}]},
    options:{plugins:{legend:{position:'right',labels:{color:'#eef3ff'}}},maintainAspectRatio:false}});
  const h=st.history||{labels:[],values:[]};
  if(window._e) window._e.destroy();
  window._e=new Chart(document.getElementById('earnChart'),{type:'line',data:{labels:h.labels||[],datasets:[{data:h.values||[],borderColor:'#34d399',backgroundColor:'rgba(52,211,153,.12)',fill:true,tension:.4,pointRadius:2}]},
    options:{plugins:{legend:{display:false}},scales:{x:{ticks:{color:'#8b9bb8'},grid:{color:'#1e2d48'}},y:{ticks:{color:'#8b9bb8'},grid:{color:'#1e2d48'}}},maintainAspectRatio:false}});
  document.getElementById('curBody').innerHTML=(cur.currencies||[]).map(c=>`
    <tr><td>${ICO[c.currency]||''} <b>${c.currency}</b></td><td>${c.accounts}</td><td>${c.balance}</td>
    <td>${fmtUsd(usd(c.currency,c.balance))}</td>
    <td>${PRICES[c.currency]!=null?('$'+Number(PRICES[c.currency]).toFixed(6)):'—'}</td>
    <td>${c.avg_balance??'—'}</td><td>${c.claims}</td></tr>`).join('')||'<tr><td colspan="7" class="empty">—</td></tr>';
}
boot().catch(console.error);
