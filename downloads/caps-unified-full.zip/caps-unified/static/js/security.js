
async function boot(){
  const sec=await api('/api/security');
  const c=sec.counts||{};
  document.getElementById('liveText').textContent=`${sec.accounts_scanned||0} scanned`;
  document.getElementById('sevCards').innerHTML=`
    <div class="card stat"><div class="lab">High</div><div class="num sev-high">${c.high||0}</div></div>
    <div class="card stat"><div class="lab">Medium</div><div class="num sev-medium">${c.medium||0}</div></div>
    <div class="card stat"><div class="lab">Low</div><div class="num">${c.low||0}</div></div>`;
  document.getElementById('secBody').innerHTML=(sec.issues||[]).map(i=>`
    <tr><td class="sev-${i.severity}">${i.severity}</td><td>${esc(i.type)}</td><td>${esc(i.msg)}</td></tr>`).join('')
    ||'<tr><td colspan="3" class="empty">Muammo topilmadi</td></tr>';
}
boot().catch(console.error);
