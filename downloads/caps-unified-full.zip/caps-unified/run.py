#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import os
import argparse, csv, io, json, os, re, sys, threading, time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

def _portfolio_history(usd_total: float):
    import json, time
    p = ROOT / "data" / "portfolio_history.json"
    try:
        h = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
    except Exception:
        h = {}
    labels = list(h.get("labels") or [])
    values = list(h.get("values") or [])
    last = values[-1] if values else None
    if last is not None and last > 0 and abs(usd_total - last) / last < 0.005:
        return {"labels": labels, "values": values}
    label = time.strftime("%H:%M")
    if labels and labels[-1] == label:
        values[-1] = usd_total
    else:
        labels.append(label)
        values.append(usd_total)
    labels, values = labels[-48:], values[-48:]
    hist = {"labels": labels, "values": values}
    try:
        p.parent.mkdir(exist_ok=True)
        p.write_text(json.dumps(hist), encoding="utf-8")
    except Exception:
        pass
    return hist


def _price_changes() -> dict:
    """CoinGecko 24h change % if available from cache."""
    import json
    p = ROOT / "data" / "prices_cache.json"
    try:
        j = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}
        ch = j.get("change_24h") or {}
        if isinstance(ch, dict) and ch:
            return ch
    except Exception:
        pass
    return {}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=5051)
    ap.add_argument("--web-only", action="store_true")
    ap.add_argument("--worker-only", action="store_true")
    ap.add_argument("--import", dest="import_path", default="")
    ap.add_argument("--no-bots", action="store_true")
    args = ap.parse_args()

    from app.db import init_db
    init_db()
    # AVTO-IMPORT O'CHIRILGAN: hisoblar faqat DB dan.
    # Papkalardan qo'shish: Settings → Import folders yoki: python run.py --scan-folders
    print("DB OK:", ROOT / "data" / "caps.db")
    try:
        from app.db import list_accounts as _la0
        print(f"[db] {_la0().__len__() if False else len(_la0())} hisob (faqat DB)")
    except Exception:
        pass

    if args.import_path:
        from app.manager import import_legacy_caps
        n = import_legacy_caps(Path(args.import_path))
        print(f"Import: {n} accounts from {args.import_path}")

    def worker():
        from app.manager import (
            start_all_enabled, sync_status_from_files, soft_restart_exited, ensure_all_running, smart_schedule,
            health_scan, make_backup, load_checkpoint_on_boot, refresh_snapshot, ensure_unique_uas,
        )
        print("[worker] ready")
        try:
            load_checkpoint_on_boot()
        except Exception as e:
            print("[checkpoint boot]", e)
        if not args.no_bots and not args.web_only:
            try:
                # enabled=1 bo'lganlarni start; o'chirilganlarni majburan yoqmaymiz
                start_all_enabled(stagger=(1.5, 3.0))
                soft_restart_exited()
            except Exception as e:
                print("[worker] start:", e)
        try:
            refresh_snapshot()
        except Exception:
            pass
        tick = 0
        while True:
            try:
                # force=True worker uchun — throttle ichida ham ishlaydi
                sync_status_from_files(force=True)
                soft_restart_exited()
                ensure_all_running()
                try:
                    smart_schedule(max_start=4)
                except Exception:
                    pass
                try:
                    M.bootstrap_empty_accounts(2)
                except Exception:
                    pass
                tick += 1
                if tick % 20 == 0:
                    health_scan()
                    try:
                        n = ensure_unique_uas()
                        if n: print("[ua] fixed", n)
                    except Exception as e:
                        print("[ua]", e)
                if tick % 1200 == 0:
                    try:
                        make_backup()
                    except Exception as e:
                        print("[backup]", e)
            except Exception as e:
                print("[worker]", e)
            time.sleep(0.5)

    if not args.web_only:
        threading.Thread(target=worker, daemon=True).start()

    if args.worker_only:
        while True:
            time.sleep(3600)

    from flask import Flask, render_template, jsonify, request, Response
    from app import db as D
    from app import manager as M
    try:
        import database as prices
    except Exception:
        prices = None

    app = Flask(__name__, template_folder=str(ROOT / "templates"), static_folder=str(ROOT / "static"))

    @app.after_request
    def no_cache(resp):
        resp.headers["Cache-Control"] = "no-store"
        return resp

    @app.get("/")
    def index():
        return render_template("unified_index.html", page="dashboard")

    @app.get("/accounts")
    def accounts_p():
        return render_template("unified_accounts.html", page="accounts")

    @app.get("/add")
    def add_p():
        return render_template("unified_add.html", page="add", platforms=D.PLATFORMS)

    @app.get("/register")
    def register_p():
        try:
            return render_template("unified_register.html", page="register", platforms=getattr(D, "PLATFORMS", {}))
        except Exception as e:
            return f"<h3>Register template error</h3><pre>{e}</pre>", 500

    @app.get("/profile/<int:aid>")
    def profile_p(aid):
        return render_template("unified_profile.html", page="profile", account_id=aid)

    @app.get("/settings")
    def settings_p():
        return render_template("unified_settings.html", page="settings")

    @app.get("/currencies")
    def currencies_p():
        return render_template("unified_currencies.html", page="currencies")

    @app.get("/analytics")
    def analytics_p():
        return render_template("unified_analytics.html", page="analytics")

    @app.get("/alerts")
    def alerts_p():
        return render_template("unified_alerts.html", page="alerts")

    @app.get("/api/accounts")
    def api_accs():
        """DB = haqiqat; snapshot faqat boyitadi. Loading qolmasin."""
        prices, change, ts = {}, {}, None
        try:
            snap = M.get_snapshot(max_age=8.0) or {}
            prices = snap.get("prices_usd") or {}
            change = snap.get("price_change") or {}
            ts = snap.get("ts")
            snap_map = {int(r.get("id") or 0): r for r in (snap.get("accounts") or []) if r.get("id") is not None}
        except Exception as e:
            print("[api/accounts snap]", e)
            snap_map = {}
        accs = []
        try:
            for a in D.list_accounts():
                d = dict(a)
                d["username"] = d.get("label") or d.get("folder") or ""
                d.pop("password", None)
                has_c = bool((d.get("cookie") or "").strip())
                d["has_cookie"] = has_c
                d["cookie"] = has_c
                sid = int(d.get("id") or 0)
                r = snap_map.get(sid)
                if r:
                    for k in ("status", "last_msg", "claims_today", "claims_left", "stamina_pct",
                              "wager_pct", "level", "health", "next_ts", "wait_sec", "usd"):
                        if r.get(k) is not None and r.get(k) != "":
                            d[k] = r[k]
                    # balance: sticky — snapshot 0/kichik bilan o'chirmas
                    try:
                        d["balance"] = M.sticky_balance(d.get("balance"), r.get("balance"))
                    except Exception:
                        if r.get("balance") is not None:
                            d["balance"] = r.get("balance")
                # coin alias
                d["currency"] = d.get("coin") or d.get("currency")
                accs.append(d)
        except Exception as e:
            print("[api/accounts db]", e)
            accs = list(snap_map.values()) if snap_map else []
        try:
            if not prices:
                prices = (M.get_prices() or {})
        except Exception:
            pass
        return jsonify({
            "accounts": accs or [],
            "count": len(accs or []),
            "prices_usd": prices or {},
            "price_change": change or {},
            "ts": ts or int(__import__("time").time()),
            "cached": True,
        })


    @app.get("/api/accounts/<int:aid>")
    def api_one(aid):
        try:
            snap = M.get_snapshot()
        except Exception:
            snap = {}
        db_a = D.get_account(aid)
        if not db_a:
            return jsonify({"error": "not found", "account": None}), 404
        a = dict(db_a)
        # merge live snapshot row
        for row in (snap.get("accounts") or []):
            if int(row.get("id") or 0) == int(aid):
                for k, v in row.items():
                    if v is None or v == "" or v == "—":
                        continue
                    if k in ("password", "cookie") and a.get(k):
                        continue
                    a[k] = v
                break
        # disk enrich: panel_status + config_*.json + cookie
        try:
            import json as _json
            folder_name = (a.get("folder") or "").strip()
            folder = M.ACCOUNTS / folder_name if folder_name else None
            if folder and folder.is_dir():
                ps = folder / "panel_status.json"
                if ps.is_file():
                    try:
                        pdata = _json.loads(ps.read_text(encoding="utf-8"))
                    except Exception:
                        pdata = {}
                    if pdata.get("user") and (not a.get("label") or a.get("label") == a.get("folder") or a.get("label") in ("—", "-")):
                        a["label"] = str(pdata["user"])[:64]
                    if pdata.get("balance") is not None and (a.get("balance") is None or a.get("balance") == "" or float(a.get("balance") or 0) == 0):
                        try:
                            a["balance"] = float(pdata["balance"])
                        except Exception:
                            pass
                    elif pdata.get("balance") is not None and a.get("balance") is None:
                        try:
                            a["balance"] = float(pdata["balance"])
                        except Exception:
                            pass
                    for k in ("level", "wager_pct", "claims_left", "claims_today", "stamina_pct", "status", "last", "deposit_address"):
                        if pdata.get(k) is not None and pdata.get(k) != "":
                            if k == "last":
                                if not a.get("last_msg"):
                                    a["last_msg"] = pdata.get("last")
                            elif k == "status":
                                if a.get("status") in (None, "", "IDLE", "STOP", "—"):
                                    a["status"] = pdata.get("status")
                            else:
                                if a.get(k) in (None, "", "—", "-"):
                                    a[k] = pdata.get(k)
                # config backfill email/ua
                for cfile in list(folder.glob("config_*.json"))[:3]:
                    try:
                        cfg = _json.loads(cfile.read_text(encoding="utf-8"))
                    except Exception:
                        continue
                    if not a.get("email") and cfg.get("email"):
                        a["email"] = cfg.get("email")
                    if not a.get("user_agent") and cfg.get("user_agent"):
                        a["user_agent"] = cfg.get("user_agent")
                    if (not a.get("cookie")) and cfg.get("cookie"):
                        a["cookie"] = cfg.get("cookie")
                    if not a.get("deposit_address") and cfg.get("deposit_address"):
                        a["deposit_address"] = cfg.get("deposit_address")
                # cookie file
                if not (a.get("cookie") or "").strip():
                    for cname in ("cookie_tron.txt", "cookie_ton.txt", "cookie.txt", "cookie_sui.txt", "cookie_doge.txt", "cookie_ltc.txt", "cookie_sol.txt"):
                        cf = folder / cname
                        if cf.is_file():
                            try:
                                ck = cf.read_text(encoding="utf-8").strip().splitlines()[0].strip()
                                if ck:
                                    a["cookie"] = ck
                                    break
                            except Exception:
                                pass
        except Exception as e:
            print("[api_one enrich]", e)
        a["username"] = a.get("label") or a.get("folder") or ("#" + str(aid))
        if not a.get("label"):
            a["label"] = a["username"]
        a.pop("password", None)
        a["has_cookie"] = bool((db_a.get("cookie") or a.get("cookie") or "").strip())
        # front uchun cookie maxfiy
        a["cookie"] = a["has_cookie"]
        # 2FA secret — panelda ko'rsatish (faqat lokal boshqaruv)
        ts = (db_a.get("totp_secret") or "").strip()
        if not ts:
            try:
                folder = Path(M.ACCOUNTS) / (db_a.get("folder") or "")
                for cfile in list(folder.glob("config_*.json"))[:2]:
                    cfg = __import__("json").loads(cfile.read_text(encoding="utf-8"))
                    if cfg.get("totp_secret"):
                        ts = str(cfg.get("totp_secret")).strip()
                        break
            except Exception:
                pass
        a["has_totp"] = bool(ts)
        a["totp_secret"] = ts
        hist = D.claim_logs(aid, limit=60)
        return jsonify({
            "ok": True,
            "account": a,
            "history": hist,
            "prices_usd": (snap.get("prices_usd") or snap.get("prices") or {}),
        })


    @app.post("/api/accounts")
    def api_add():
        body = request.get_json(silent=True) or {}
        platform = (body.get("platform") or "").strip().lower()
        if platform not in D.PLATFORMS:
            return jsonify({"error": "platform: " + ", ".join(D.PLATFORMS)}), 400
        email = (body.get("email") or "").strip().lower()
        cookie = (body.get("cookie") or "").strip()
        password = (body.get("password") or "").strip()
        if not email and not cookie:
            return jsonify({"error": "email+password yoki cookie kerak"}), 400
        # Bir xil platform + email qayta qo'shilmasin
        if email:
            for a in D.list_accounts():
                if (a.get("platform") or "").lower() == platform and (a.get("email") or "").strip().lower() == email:
                    return jsonify({
                        "error": f"Bu email allaqachon {platform} da bor (#{a['id']} · {a.get('label') or a.get('folder')}). Qayta qo'shib bo'lmaydi."
                    }), 400
        try:
            aid = M.create_account(
                platform=platform,
                label=(body.get("label") or "").strip(),
                email=email,
                password=password,
                cookie=cookie,
                wallet=(body.get("wallet") or "").strip(),
                user_agent=(body.get("user_agent") or "").strip(),
                totp_secret=(body.get("totp_secret") or body.get("twofa_secret") or "").replace(" ", "").strip(),
            )
            def _boot(aid=aid):
                try:
                    M.refresh_account_live(aid)
                except Exception as e:
                    print("[add refresh]", e)
                try:
                    M.start_account(aid)
                except Exception as e:
                    print("[add start]", e)
                try:
                    M.refresh_snapshot()
                except Exception:
                    pass
            if body.get("start", True) in (True, "1", "true", "on", None):
                threading.Thread(target=_boot, daemon=True).start()
            else:
                threading.Thread(target=lambda: M.refresh_account_live(aid), daemon=True).start()
            try:
                M.refresh_snapshot()
            except Exception:
                pass
            return jsonify({"ok": True, "id": aid, "account": D.get_account(aid)})
        except Exception as e:
            return jsonify({"error": str(e)}), 400


    @app.post("/api/accounts/<int:aid>/password")
    def api_change_password(aid):
        """Panel parolini yangilash (+ ixtiyoriy sayt change)."""
        body = request.get_json(silent=True) or {}
        new_p = (body.get("password") or body.get("new_password") or "").strip()
        old_p = (body.get("old_password") or "").strip()
        if len(new_p) < 6:
            return jsonify({"ok": False, "error": "Yangi parol kamida 6 belgi"}), 400
        a = D.get_account(aid)
        if not a:
            return jsonify({"ok": False, "error": "not found"}), 404
        try:
            D.update_account(aid, password=new_p)
            a2 = D.get_account(aid)
            M.write_account_files(a2)
            site = None
            if body.get("also_site") in (1, True, "1", "true"):
                try:
                    site = M.change_password_on_site(aid, old_p or (a.get("password") or ""), new_p)
                except Exception as e:
                    site = {"ok": False, "error": str(e)}
            return jsonify({"ok": True, "panel": True, "site": site})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 400


    @app.post("/api/accounts/<int:aid>/enable-2fa")
    def api_enable_2fa(aid):
        """Saytda 2FA yoqish + secret panelga."""
        try:
            res = M.enable_2fa_on_site(aid)
            code = 200 if res.get("ok") or res.get("saved") else 400
            return jsonify(res), code
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 400

    @app.post("/api/accounts/<int:aid>/totp")
    def api_set_totp(aid):
        """2FA secret saqlash / o'chirish."""
        body = request.get_json(silent=True) or {}
        sec = (body.get("totp_secret") or body.get("secret") or "").strip().replace(" ", "")
        if sec.lower().startswith("otpauth://"):
            m = re.search(r"[?&]secret=([A-Za-z2-7]+)", sec, re.I)
            sec = m.group(1) if m else ""
        a = D.get_account(aid)
        if not a:
            return jsonify({"ok": False, "error": "not found"}), 404
        try:
            D.update_account(aid, totp_secret=sec)
            a2 = D.get_account(aid)
            M.write_account_files(a2)
            # test code
            code = ""
            if sec:
                try:
                    code = M.totp_now(sec)
                except Exception:
                    code = ""
            return jsonify({"ok": True, "has_totp": bool(sec), "totp_secret": sec, "test_code": code})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 400

    @app.get("/api/accounts/<int:aid>/totp")
    def api_get_totp(aid):
        a = D.get_account(aid)
        if not a:
            return jsonify({"ok": False, "error": "not found"}), 404
        sec = (a.get("totp_secret") or "").strip()
        code = M.totp_now(sec) if sec else ""
        return jsonify({"ok": True, "has_totp": bool(sec), "totp_secret": sec, "code": code})


    @app.post("/api/accounts/<int:aid>/start")
    def api_start(aid):
        return jsonify({"ok": M.start_account(aid)})

    @app.post("/api/accounts/<int:aid>/stop")
    def api_stop(aid):
        M.stop_account(aid)
        return jsonify({"ok": True})

    @app.delete("/api/accounts/<int:aid>")
    def api_del(aid):
        """Stop + DB + papka + blacklist."""
        try:
            return jsonify(M.remove_account_completely(int(aid)))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500


    
    @app.post("/api/purge-orphans")
    def api_purge_orphans():
        """Faqat o'chirilgan (blacklist) papkalar — live himoyalangan."""
        try:
            return jsonify(M.purge_orphan_account_files())
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/clear-deleted-blacklist")
    def api_clear_blacklist():
        try:
            return jsonify(M.clear_deleted_blacklist())
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    
    @app.get("/api/currencies")
    def api_currencies():
        """Coins + balances + prices — currencies page."""
        try:
            snap = M.get_snapshot(max_age=30.0) or {}
        except Exception:
            snap = {}
        prices = dict(snap.get("prices_usd") or snap.get("prices") or {})
        # fallback static approx if empty
        if not prices:
            prices = {"TRX": 0.31, "TON": 5.5, "SUI": 3.5, "SOL": 180.0, "DOGE": 0.35, "LTC": 90.0}
        agg = {}
        try:
            for a in D.list_accounts():
                c = (a.get("coin") or "TRX").upper()
                if not c:
                    c = "TRX"
                if c not in agg:
                    agg[c] = {"symbol": c, "name": c, "balance": 0.0, "usd": 0.0, "accounts": 0,
                              "price": float(prices.get(c) or prices.get(c.lower()) or 0) or 0}
                try:
                    b = float(a.get("balance") or 0)
                except Exception:
                    b = 0.0
                agg[c]["balance"] += b
                agg[c]["accounts"] += 1
                px = float(agg[c]["price"] or 0)
                try:
                    u = float(a.get("usd") or 0)
                except Exception:
                    u = 0.0
                agg[c]["usd"] += u if u > 0 else b * px
        except Exception as e:
            print("[api/currencies]", e)
        coins = list(agg.values())
        return jsonify({
            "ok": True,
            "currencies": coins,
            "coins": coins,
            "prices_usd": prices,
            "prices": prices,
            "total_usd": sum(x.get("usd") or 0 for x in coins),
        })


    @app.get("/api/statistics")
    def api_stats():
        snap = M.get_snapshot()
        st = dict(snap.get("stats") or {})
        usd = float(st.get("usd_total") or 0)
        try:
            hist = _portfolio_history(round(usd, 4))
        except Exception:
            hist = {"labels": [], "values": []}
        st.update({
            "history": hist,
            "alerts_unseen": D.alerts_count_unseen(),
            "caps_root": str(ROOT / "accounts"),
            "data_source": "checkpoint",
            "ts": snap.get("ts"),
            "cached": True,
            "prices_usd": st.get("prices_usd") or snap.get("prices_usd") or {},
            "price_change": st.get("price_change") or snap.get("price_change") or {},
        })
        return jsonify(st)

    @app.get("/api/snapshot")
    def api_snapshot():
        if request.args.get("force") in ("1", "true", "yes"):
            try:
                M.sync_status_from_files(force=True)
            except Exception:
                pass
            snap = M.refresh_snapshot()
        else:
            snap = M.get_snapshot()
        usd = float((snap.get("stats") or {}).get("usd_total") or 0)
        try:
            hist = _portfolio_history(round(usd, 4))
        except Exception:
            hist = {"labels": [], "values": []}
        return jsonify({
            "ts": snap.get("ts"),
            "accounts": snap.get("accounts") or [],
            "count": snap.get("count"),
            "prices_usd": snap.get("prices_usd") or {},
            "price_change": snap.get("price_change") or {},
            "stats": snap.get("stats") or {},
            "history": hist,
            "cached": True,
        })

    @app.get("/api/analytics")
    def api_analytics():
        return jsonify({
            "captcha_rates": D.captcha_success_rates(7),
            "claims_daily": D.claims_per_day(14),
            "accounts": [
                {
                    "id": a["id"], "label": a.get("label") or a["folder"],
                    "coin": a.get("coin"), "health": a.get("health"),
                    "fail_streak": a.get("fail_streak") or 0,
                    "claims_today": a.get("claims_today") or 0,
                    "last_claim_ts": a.get("last_claim_ts"),
                    "cookie_updated_ts": a.get("cookie_updated_ts"),
                }
                for a in D.list_accounts()
            ],
        })

    @app.get("/api/alerts")
    def api_alerts():
        return jsonify({"alerts": D.list_alerts(50), "unseen": D.alerts_count_unseen()})

    @app.post("/api/alerts/seen")
    def api_alerts_seen():
        D.mark_alerts_seen()
        return jsonify({"ok": True})


    @app.get("/api/accounts/<int:aid>/withdraw")
    def api_wd_info(aid):
        try:
            return jsonify(M.withdraw_info(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/withdraw")
    def api_wd_do(aid):
        body = request.get_json(silent=True) or {}
        try:
            amount = float(body.get("amount") or 0)
        except Exception:
            return jsonify({"ok": False, "error": "amount"}), 400
        address = (body.get("address") or body.get("wallet") or "").strip()
        tag = (body.get("tag") or "").strip()
        if amount <= 0:
            return jsonify({"ok": False, "error": "amount <= 0"}), 400
        try:
            return jsonify(M.withdraw_do(aid, amount, address, tag))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    

    @app.post("/api/accounts/<int:aid>/wallet")
    def api_save_wallet(aid):
        body = request.get_json(silent=True) or {}
        addr = (body.get("address") or body.get("wallet") or "").strip()
        kind = (body.get("kind") or body.get("type") or "withdraw").strip().lower()
        if len(addr) < 20:
            return jsonify({"ok": False, "error": "address qisqa"}), 400
        try:
            if kind in ("deposit", "dep"):
                D.update_account(aid, deposit_address=addr)
                return jsonify({"ok": True, "deposit_address": addr})
            # default: withdraw (tashqi yechish manzili)
            D.update_account(aid, withdraw_wallet=addr)
            try:
                M.write_account_files(D.get_account(aid))
            except Exception:
                pass
            return jsonify({"ok": True, "withdraw_wallet": addr, "address": addr})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/accounts/<int:aid>/deposit")
    def api_deposit(aid):
        try:
            return jsonify(M.deposit_info(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/refresh")
    def api_acc_refresh(aid):
        try:
            out = M.refresh_account_live(aid)
            try:
                # jarayon yo'q bo'lsa — uyg'otish (slot bo'lsa)
                if not M.is_running(aid):
                    M.start_account(aid)
            except Exception:
                pass
            try:
                M.refresh_snapshot()
            except Exception:
                pass
            # yangilangan DB qator
            a = D.get_account(aid) or {}
            out["account"] = {k: a.get(k) for k in a if k != "password"}
            return jsonify(out)
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/accounts/<int:aid>/affiliate")
    def api_aff_info(aid):
        try:
            return jsonify(M.affiliate_info(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/affiliate/claim")
    def api_aff_claim(aid):
        try:
            return jsonify(M.affiliate_claim(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/accounts/<int:aid>/level")
    def api_level(aid):
        try:
            d = M.deposit_info(aid)
            return jsonify({k: d.get(k) for k in ("ok","level","level_index","wager","levels","next","error")})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500




    @app.get("/api/accounts/<int:aid>/email-status")
    def api_email_status(aid):
        try:
            return jsonify(M.email_verify_status(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/verify-email")
    def api_verify_email(aid):
        try:
            return jsonify(M.verify_email_send(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/confirm")
    def api_confirm(aid):
        body = request.get_json(silent=True) or {}
        url = (body.get("url") or body.get("link") or "").strip()
        if not url:
            return jsonify({"ok": False, "error": "url kerak"}), 400
        try:
            return jsonify(M.confirm_site_link(aid, url))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/accounts/<int:aid>/dice/status")
    def api_dice_st(aid):
        try:
            return jsonify(M.dice_status(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/dice/start")
    def api_dice_start(aid):
        body = request.get_json(silent=True) or {}
        try:
            return jsonify(M.dice_start(aid, body))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/dice/stop")
    def api_dice_stop(aid):
        try:
            return jsonify(M.dice_stop(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500


    
    @app.route("/browse/<int:aid>/", defaults={"path": "faucet.php"}, methods=["GET", "POST"])
    @app.route("/browse/<int:aid>/<path:path>", methods=["GET", "POST"])
    def browse_proxy(aid, path="faucet.php"):
        """Bot cookie/UA bilan saytni panel ichida ochish."""
        from flask import Response, request as req
        acc = D.get_account(aid)
        if not acc:
            return "Account not found", 404
        # path tozalash
        path = (path or "faucet.php").lstrip("/")
        if path.startswith("browse/"):
            parts = path.split("/", 2)
            path = parts[2] if len(parts) > 2 else "faucet.php"
        host = M._host_for(acc)
        # POST: form yuborish
        if req.method == "POST":
            try:
                M.sync_cookie_from_disk(acc)
                acc = D.get_account(aid) or acc
                s = M._acc_session(acc)
                url = host + path.lstrip("/")
                data = req.form.to_dict(flat=True)
                files = None
                rr = s.post(url, data=data, timeout=35, allow_redirects=True,
                            headers={"Referer": host + path, "Origin": host.rstrip("/")})
                try:
                    cur = M._session_cookie_string(s)
                    if cur:
                        M._persist_cookie(D.get_account(aid) or acc, cur)
                except Exception:
                    pass
                html = M.rewrite_browse_html(rr.text or "", aid, host)
                return Response(html, status=rr.status_code, content_type="text/html; charset=utf-8")
            except Exception as e:
                return f"<pre>POST error: {e}</pre>", 500
        out = M.browse_as_account(aid, path)
        if not out.get("ok"):
            return f"<pre>Open error: {out.get('error')}</pre>", 502
        html = M.rewrite_browse_html(out.get("html") or "", aid, out.get("host") or host)
        return Response(html, status=int(out.get("status") or 200), content_type="text/html; charset=utf-8")

    @app.get("/api/accounts/<int:aid>/open-url")
    def api_open_url(aid):
        return jsonify({"ok": True, "url": f"/browse/{aid}/faucet.php", "dice": f"/browse/{aid}/dice.php"})


    @app.post("/api/accounts/<int:aid>/roulette37/start")
    def api_r37_start(aid):
        body = request.get_json(silent=True) or {}
        max_spins = int(body.get("max_spins") or 200)
        try:
            return jsonify(M.roulette37_start(aid, max_spins=max_spins))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/<int:aid>/roulette37/stop")
    def api_r37_stop(aid):
        try:
            return jsonify(M.roulette37_stop(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/accounts/<int:aid>/roulette37/status")
    def api_r37_status(aid):
        try:
            return jsonify(M.roulette37_status(aid))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/register/meta")
    def api_reg_meta():
        platform = request.args.get("platform") or "tonpick"
        try:
            return jsonify(M.register_meta(platform))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/register")
    def api_register():
        body = request.get_json(silent=True) or {}
        try:
            return jsonify(M.register_on_site(
                platform=body.get("platform") or "tonpick",
                username=(body.get("username") or "").strip(),
                email=(body.get("email") or "").strip(),
                password=body.get("password") or "",
                referrer=(body.get("referrer") or "").strip(),
                add_local=bool(body.get("add_local", True)),
            ))
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500



    @app.get("/api/platforms")
    def api_plat():
        return jsonify({"platforms": D.PLATFORMS})

    @app.get("/api/settings")
    def api_gs():
        def g(k, default=""):
            v = D.get_setting(k, default)
            if v is None:
                return default
            return str(v)

        def clean_keys(v: str) -> str:
            """[] yoki JSON list → oddiy qatorlar."""
            v = (v or "").strip()
            if not v or v in ("[]", "{}", "null", "None"):
                return ""
            if v.startswith("["):
                try:
                    arr = json.loads(v)
                    if isinstance(arr, list):
                        return "\n".join(str(x).strip() for x in arr if str(x).strip())
                except Exception:
                    v = v.strip("[]").replace('"', "").replace("'", "")
            # vergul bilan
            if "," in v and "\n" not in v:
                parts = [p.strip() for p in v.split(",") if p.strip()]
                if len(parts) > 1:
                    return "\n".join(parts)
            return v

        data = {
            "gemini_keys": clean_keys(g("gemini_keys") or g("gemini", "")),
            "openrouter_keys": clean_keys(g("openrouter_keys") or g("openrouter", "")),
            "xevil_apikey": g("xevil_apikey") or g("xevil_key", ""),
            "xevil_key": g("xevil_apikey") or g("xevil_key", ""),
            "xevil_hosts": g("xevil_hosts", "https://sctg.xyz,https://api.sctg.xyz"),
            "tg_bot_token": g("tg_bot_token") or g("tg_token", ""),
            "tg_token": g("tg_bot_token") or g("tg_token", ""),
            "tg_chat_id": g("tg_chat_id") or g("tg_chat", ""),
            "tg_chat": g("tg_chat_id") or g("tg_chat", ""),
            "tg_on": g("tg_on", "1"),
            "dice_enabled": g("dice_enabled", "1"),
            "dice_daily_cap": g("dice_daily_cap", "0"),
            "dice_payout": g("dice_payout", "1.01"),
            "dice_min_balance": g("dice_min_balance", "0.005"),
            "sync_sec": g("sync_sec", "1"),
            "price_sec": g("price_sec", "3600"),
            "auto_withdraw": g("auto_withdraw", "0"),
            "auto_withdraw_min": g("auto_withdraw_min", "8"),
        }
        # backup file dan to'ldirish (db bo'sh bo'lsa)
        try:
            bp = ROOT / "data" / "settings_backup.json"
            if bp.is_file():
                bak = json.loads(bp.read_text(encoding="utf-8"))
                for k, v in (bak or {}).items():
                    if k in data and not (data.get(k) or "").strip() and v:
                        data[k] = clean_keys(str(v)) if "keys" in k else str(v)
        except Exception:
            pass
        return jsonify({"ok": True, "settings": data, **data})

    @app.post("/api/settings")
    def api_ss():
        body = request.get_json(silent=True) or {}
        alias = {
            "gemini": "gemini_keys",
            "openrouter": "openrouter_keys",
            "xevil_key": "xevil_apikey",
            "xevil": "xevil_apikey",
            "tg_token": "tg_bot_token",
            "tg_chat": "tg_chat_id",
        }
        allowed = {
            "gemini_keys", "openrouter_keys", "xevil_apikey", "xevil_hosts",
            "tg_bot_token", "tg_chat_id", "tg_on", "sync_sec", "price_sec",
            "dice_enabled", "dice_daily_cap", "dice_payout", "dice_min_balance",
            "auto_withdraw", "auto_withdraw_min",
        }

        def norm_keys(v) -> str:
            if v is None:
                return ""
            if isinstance(v, list):
                return "\n".join(str(x).strip() for x in v if str(x).strip())
            s = str(v).strip()
            if s in ("[]", "{}", "null", "None"):
                return ""
            if s.startswith("["):
                try:
                    arr = json.loads(s)
                    if isinstance(arr, list):
                        return "\n".join(str(x).strip() for x in arr if str(x).strip())
                except Exception:
                    s = s.strip("[]").replace('"', "").replace("'", "")
            # bitta qator vergul bilan → qatorlarga
            if "," in s and "\n" not in s and "http" not in s.lower():
                parts = [p.strip() for p in s.split(",") if p.strip()]
                if len(parts) > 1 and all(len(p) > 8 for p in parts):
                    return "\n".join(parts)
            return s

        saved = []
        store = {}
        for k, v in list(body.items()):
            key = alias.get(k, k)
            if key not in allowed:
                continue
            if key in ("gemini_keys", "openrouter_keys"):
                v = norm_keys(v)
            elif isinstance(v, bool):
                v = "1" if v else "0"
            elif isinstance(v, (int, float)):
                v = str(v)
            else:
                v = str(v if v is not None else "").strip()
            D.set_setting(key, v)
            store[key] = v
            saved.append(key)
        if "xevil_apikey" in saved:
            D.set_setting("xevil_key", store.get("xevil_apikey", ""))
        if "tg_bot_token" in saved:
            D.set_setting("tg_token", store.get("tg_bot_token", ""))
        if "tg_chat_id" in saved:
            D.set_setting("tg_chat", store.get("tg_chat_id", ""))
        # backup JSON — yangilanish/db muammosida yo'qolmasin
        try:
            bp = ROOT / "data" / "settings_backup.json"
            bp.parent.mkdir(parents=True, exist_ok=True)
            prev = {}
            if bp.is_file():
                try:
                    prev = json.loads(bp.read_text(encoding="utf-8")) or {}
                except Exception:
                    prev = {}
            prev.update(store)
            bp.write_text(json.dumps(prev, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            print("[settings backup]", e)
        # config larni yangilash (xato bo'lsa ham settings saqlangan)
        try:
            for a in D.list_accounts():
                try:
                    M.write_account_files(a)
                except Exception:
                    pass
        except Exception as e:
            print("[settings rewrite cfg]", e)
        return jsonify({"ok": True, "saved": saved, "store": {k: ("***" if "key" in k or "token" in k else v) for k,v in store.items()}})

    @app.post("/api/accounts/save")
    def api_accounts_save():
        """Faqat DB dagi hisoblarni diskka saqlash (import yo'q)."""
        try:
            return jsonify(M.save_accounts_to_db())
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/restore")
    def api_accounts_restore():
        try:
            return jsonify(M.restore_accounts_from_disk())
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/accounts/import-folders")
    def api_accounts_import_folders():
        """Qo'lda: accounts/ papkalarini DB ga."""
        try:
            n = M.import_existing_folders()
            try:
                M.refresh_snapshot(force=True)
            except Exception:
                M.refresh_snapshot()
            return jsonify({"ok": True, "imported": n})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/backup")
    def api_backup():
        try:
            p = M.make_backup()
            return jsonify({"ok": True, "file": str(p.name)})
        except Exception as e:
            return jsonify({"error": str(e)}), 500

    @app.get("/api/export.csv")
    def api_export():
        accs = D.list_accounts()
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["id","folder","platform","coin","label","email","balance","status","claims_today","claims_left","stamina_pct","wager_pct","health"])
        for a in accs:
            w.writerow([a.get(k) for k in ("id","folder","platform","coin","label","email","balance","status","claims_today","claims_left","stamina_pct","wager_pct","health")])
        return Response(buf.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=caps_accounts.csv"})

    @app.post("/api/bots/stop-all")
    def api_stop_all():
        try:
            n = M.stop_all_bots() if hasattr(M, "stop_all_bots") else 0
            return jsonify({"ok": True, "stopped": n})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.post("/api/bots/import-folders")
    def api_import_folders():
        try:
            n = M.import_existing_folders()
            return jsonify({"ok": True, "imported": n, "total": len(M.list_accounts())})
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.get("/api/security")
    def api_sec():
        issues = []
        ua = {}
        for a in D.list_accounts():
            u = (a.get("user_agent") or "").strip()
            if not u:
                continue
            key = f"{a.get('coin')}|{u}"
            ua.setdefault(key, []).append(a["folder"])
        for k, folders in ua.items():
            if len(folders) > 1:
                issues.append({"severity": "high", "msg": f"Bir xil UA: {', '.join(folders)}", "folders": folders})
        return jsonify({"issues": issues, "counts": {"high": len(issues), "medium": 0, "low": 0, "total": len(issues)}})

    import socket
    port = int(args.port)
    for _ in range(20):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            s.bind(("0.0.0.0", port))
            s.close()
            break
        except OSError:
            s.close()
            print(f"[port] {port} band → {port + 1}")
            port += 1
    args.port = port
    print(f"CAPS UNIFIED PRO  http://0.0.0.0:{args.port}")
    print("[tip] OOM/signal9: CAPS_MAX_BOTS=10 python run.py")

    try:
        app.run(host="0.0.0.0", port=args.port, debug=False, threaded=True, use_reloader=False)
    except OSError as e:
        print("PORT XATO:", e)
        print("Yechim: pkill -f 'python.*run.py'  yoki  python run.py --port 5052")
        raise


    @app.post("/api/accounts/<int:aid>/auto_withdraw")
    def api_auto_wd(aid):
        body = request.get_json(silent=True) or {}
        en = body.get("enabled", body.get("auto_withdraw", 0))
        en = "1" if str(en) in ("1", "true", "True", "yes", "on") else "0"
        try:
            mn = float(body.get("min") or body.get("auto_withdraw_min") or 8)
        except Exception:
            mn = 8.0
        D.update_account(aid, auto_withdraw=en, auto_withdraw_min=mn)
        try:
            a = D.get_account(aid)
            if a:
                M.write_account_files(a)
        except Exception:
            pass
        return jsonify({"ok": True, "auto_withdraw": en, "min": mn})


if __name__ == "__main__":
    main()
