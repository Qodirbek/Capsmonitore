#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, sqlite3, time
from pathlib import Path
from typing import Any, Optional

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(exist_ok=True)
DB_PATH = DATA / "caps.db"

PLATFORMS = {
    "tonpick":  {"coin": "TON",  "bot": "tonpick_bot.py",  "config": "config_tonpick.json",  "cookie": "cookie_ton.txt",  "host": "https://tonpick.game/"},
    "tronpick": {"coin": "TRX",  "bot": "tronpick_bot.py", "config": "config_tronpick.json", "cookie": "cookie_tron.txt", "host": "https://tronpick.io/"},
    "suipick":  {"coin": "SUI",  "bot": "suipick_bot.py",  "config": "config_suipick.json",  "cookie": "cookie_sui.txt",  "host": "https://suipick.io/"},
    "dogepick": {"coin": "DOGE", "bot": "dogepick_bot.py", "config": "config_dogepick.json", "cookie": "cookie_doge.txt", "host": "https://dogepick.io/"},
    "litepick": {"coin": "LTC",  "bot": "litepick_bot.py", "config": "config_litepick.json", "cookie": "cookie_ltc.txt",  "host": "https://litepick.io/"},
    "solpick":  {"coin": "SOL",  "bot": "solpick_bot.py",  "config": "config_solpick.json",  "cookie": "cookie_sol.txt",  "host": "https://solpick.io/"},
}


def _try_connect(path: Path):
    c = sqlite3.connect(str(path), timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA busy_timeout=15000")
    # integrity
    row = c.execute("PRAGMA integrity_check").fetchone()
    ok = row and str(row[0]).lower() == "ok"
    if not ok:
        c.close()
        raise sqlite3.DatabaseError("integrity: " + str(row[0] if row else "?"))
    try:
        c.execute("PRAGMA journal_mode=WAL")
    except Exception:
        pass
    return c


def _backup_corrupt_db():
    import shutil, time as _t
    ts = _t.strftime("%Y%m%d_%H%M%S")
    for name in ("caps.db", "caps.db-wal", "caps.db-shm"):
        p = DATA / name
        if p.is_file():
            dest = DATA / f"corrupt_{ts}_{name}"
            try:
                shutil.move(str(p), str(dest))
                print(f"[db] moved broken → {dest.name}")
            except Exception as e:
                print(f"[db] move {name}: {e}")
                try:
                    p.unlink()
                except Exception:
                    pass


def _recover_from_dump() -> bool:
    """sqlite dump or .recover style: copy readable tables if possible."""
    import shutil
    broken = DATA / "caps.db"
    # already moved; look for latest corrupt_*.db
    cands = sorted(DATA.glob("corrupt_*_caps.db"), key=lambda p: p.stat().st_mtime, reverse=True)
    if not cands:
        return False
    src = cands[0]
    try:
        # try dump
        con = sqlite3.connect(str(src))
        dump = "\n".join(con.iterdump())
        con.close()
        if "CREATE TABLE" not in dump:
            return False
        # filter bad lines
        lines = []
        for line in dump.splitlines():
            if line.startswith("ROLLBACK"):
                continue
            lines.append(line)
        new = sqlite3.connect(str(DB_PATH))
        new.executescript("\n".join(lines))
        new.close()
        print("[db] recovered from dump:", src.name)
        return True
    except Exception as e:
        print("[db] dump recover fail:", e)
        try:
            DB_PATH.unlink(missing_ok=True)
        except Exception:
            pass
        return False



def _migrate(c):
    for col, typ in (
        ("next_ts", "INTEGER"),
        ("level", "TEXT"),
        ("wager_pct", "REAL"),
        ("stamina_pct", "REAL"),
        ("claims_left", "INTEGER"),
        ("claims_today", "INTEGER"),
        ("withdraw_wallet", "TEXT"),
        ("deposit_address", "TEXT"),
    ):
        try:
            c.execute(f"ALTER TABLE accounts ADD COLUMN {col} {typ}")
        except Exception:
            pass

def _conn():
    DATA.mkdir(parents=True, exist_ok=True)
    try:
        return _try_connect(DB_PATH)
    except Exception as e:
        print("[db] open fail:", e)
        _backup_corrupt_db()
        if _recover_from_dump():
            try:
                return _try_connect(DB_PATH)
            except Exception as e2:
                print("[db] recover still bad:", e2)
                _backup_corrupt_db()
        # fresh empty
        c = sqlite3.connect(str(DB_PATH), timeout=30)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA busy_timeout=15000")
        print("[db] new empty database created")
        return c


def init_db():
    with _conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder TEXT UNIQUE NOT NULL,
            platform TEXT NOT NULL,
            coin TEXT NOT NULL,
            label TEXT,
            email TEXT,
            password TEXT,
            totp_secret TEXT,
            cookie TEXT,
            wallet TEXT,
            user_agent TEXT,
            balance REAL,
            status TEXT DEFAULT 'IDLE',
            last_msg TEXT,
            claims_today INTEGER DEFAULT 0,
            claims_left INTEGER,
            stamina_pct REAL,
            wager_pct REAL,
            enabled INTEGER DEFAULT 1,
            last_claim_ts INTEGER,
            last_seen_ts INTEGER,
            cookie_updated_ts INTEGER,
            health TEXT DEFAULT 'unknown',
            fail_streak INTEGER DEFAULT 0,
            created_at INTEGER,
            updated_at INTEGER
        );
        CREATE TABLE IF NOT EXISTS claim_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER,
            ts INTEGER,
            captcha TEXT,
            amount TEXT,
            status TEXT,
            msg TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_claim_log_aid ON claim_log(account_id, id DESC);
        CREATE TABLE IF NOT EXISTS captcha_stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            account_id INTEGER,
            ts INTEGER,
            captcha TEXT,
            ok INTEGER,
            source TEXT
        );
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts INTEGER,
            level TEXT,
            account_id INTEGER,
            title TEXT,
            body TEXT,
            seen INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        """)
        _migrate(c)
        # migrations
        cols = {r[1] for r in c.execute("PRAGMA table_info(accounts)").fetchall()}
        for col, typ in [
            ("last_claim_ts", "INTEGER"),
            ("last_seen_ts", "INTEGER"),
            ("cookie_updated_ts", "INTEGER"),
            ("totp_secret", "TEXT"),
            ("auto_withdraw", "TEXT DEFAULT '0'"),
            ("auto_withdraw_min", "REAL DEFAULT 8"),
            ("withdraw_wallet", "TEXT"),
            ("health", "TEXT DEFAULT 'unknown'"),
            ("fail_streak", "INTEGER DEFAULT 0"),
        ]:
            if col not in cols:
                try:
                    c.execute(f"ALTER TABLE accounts ADD COLUMN {col} {typ}")
                except Exception:
                    pass

def get_setting(key: str, default: str = "") -> str:
    with _conn() as c:
        r = c.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return r["value"] if r else default

def set_setting(key: str, value: str):
    with _conn() as c:
        c.execute(
            "INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value) if value is not None else ""),
        )
        try:
            c.commit()
        except Exception:
            pass

def add_account(**kw) -> int:
    now = int(time.time())
    with _conn() as c:
        cur = c.execute(
            """INSERT INTO accounts(folder,platform,coin,label,email,password,totp_secret,cookie,wallet,user_agent,enabled,created_at,updated_at,cookie_updated_ts,last_seen_ts)
               VALUES(?,?,?,?,?,?,?,?,?,?,1,?,?,?,?)""",
            (
                kw["folder"], kw["platform"], kw["coin"], kw.get("label") or kw["folder"],
                kw.get("email") or "", kw.get("password") or "", kw.get("totp_secret") or "",
                kw.get("cookie") or "",
                kw.get("wallet") or "", kw.get("user_agent") or "",
                now, now, now if kw.get("cookie") else None, now,
            ),
        )
        return int(cur.lastrowid)

def update_account(aid: int, **kw):
    if not kw:
        return
    kw["updated_at"] = int(time.time())
    if "cookie" in kw and kw["cookie"]:
        kw["cookie_updated_ts"] = int(time.time())
    cols = ", ".join(f"{k}=?" for k in kw)
    with _conn() as c:
        c.execute(f"UPDATE accounts SET {cols} WHERE id=?", (*kw.values(), aid))

def get_account(aid: int) -> Optional[dict]:
    with _conn() as c:
        r = c.execute("SELECT * FROM accounts WHERE id=?", (aid,)).fetchone()
        return dict(r) if r else None

def get_account_by_folder(folder: str) -> Optional[dict]:
    with _conn() as c:
        r = c.execute("SELECT * FROM accounts WHERE folder=?", (folder,)).fetchone()
        return dict(r) if r else None

def list_accounts() -> list:
    with _conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM accounts ORDER BY id").fetchall()]

def delete_account(aid: int):
    with _conn() as c:
        for tbl in (
            "claim_log",
            "captcha_stats",
            "alerts",
            "wager_log",
            "deposit_log",
            "withdraw_log",
            "history",
            "account_meta",
        ):
            try:
                c.execute(f"DELETE FROM {tbl} WHERE account_id=?", (aid,))
            except Exception:
                pass
        try:
            c.execute("DELETE FROM alerts WHERE account_id=?", (aid,))
        except Exception:
            pass
        c.execute("DELETE FROM accounts WHERE id=?", (aid,))

def add_claim_log(aid: int, captcha: str, amount: str, status: str, msg: str = "") -> int:
    """Hourly claim history — darhol commit."""
    now = int(time.time())
    with _conn() as c:
        cur = c.execute(
            "INSERT INTO claim_log(account_id,ts,captcha,amount,status,msg) VALUES(?,?,?,?,?,?)",
            (aid, now, (captcha or "Hourly")[:40], (amount or "")[:80], status or "accepted", (msg or "")[:200]),
        )
        c.execute("UPDATE accounts SET last_claim_ts=?, fail_streak=0, updated_at=? WHERE id=?", (now, now, aid))
        try:
            c.commit()
        except Exception:
            pass
        return int(cur.lastrowid or 0)

def claim_logs(aid: int, limit: int = 50) -> list:
    with _conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM claim_log WHERE account_id=? ORDER BY id DESC LIMIT ?", (aid, limit)
        ).fetchall()]

def add_captcha_stat(aid: int, captcha: str, ok: bool, source: str = ""):
    with _conn() as c:
        c.execute(
            "INSERT INTO captcha_stats(account_id,ts,captcha,ok,source) VALUES(?,?,?,?,?)",
            (aid, int(time.time()), captcha, 1 if ok else 0, source[:40]),
        )
        if not ok:
            c.execute("UPDATE accounts SET fail_streak=COALESCE(fail_streak,0)+1 WHERE id=?", (aid,))

def captcha_success_rates(days: int = 7) -> dict:
    since = int(time.time()) - days * 86400
    with _conn() as c:
        rows = c.execute(
            "SELECT captcha, SUM(ok) as ok, COUNT(*) as n FROM captcha_stats WHERE ts>=? GROUP BY captcha",
            (since,),
        ).fetchall()
    out = {}
    for r in rows:
        n = int(r["n"] or 0)
        ok = int(r["ok"] or 0)
        out[r["captcha"] or "?"] = {"ok": ok, "total": n, "rate": round(100 * ok / n, 1) if n else 0}
    return out

def claims_per_day(days: int = 14) -> dict:
    since = int(time.time()) - days * 86400
    with _conn() as c:
        rows = c.execute(
            "SELECT date(ts,'unixepoch','localtime') as d, COUNT(*) as n FROM claim_log WHERE ts>=? AND status LIKE '%accept%' GROUP BY d ORDER BY d",
            (since,),
        ).fetchall()
    return {"labels": [r["d"] for r in rows], "values": [int(r["n"]) for r in rows]}

def add_alert(level: str, title: str, body: str = "", account_id: int | None = None):
    with _conn() as c:
        # dedupe same title last 10 min
        recent = c.execute(
            "SELECT id FROM alerts WHERE title=? AND ts>? LIMIT 1",
            (title, int(time.time()) - 600),
        ).fetchone()
        if recent:
            return
        c.execute(
            "INSERT INTO alerts(ts,level,account_id,title,body,seen) VALUES(?,?,?,?,?,0)",
            (int(time.time()), level, account_id, title[:80], body[:300]),
        )

def list_alerts(limit: int = 40, unseen_only: bool = False) -> list:
    q = "SELECT * FROM alerts"
    if unseen_only:
        q += " WHERE seen=0"
    q += " ORDER BY id DESC LIMIT ?"
    with _conn() as c:
        return [dict(r) for r in c.execute(q, (limit,)).fetchall()]

def mark_alerts_seen():
    with _conn() as c:
        c.execute("UPDATE alerts SET seen=1 WHERE seen=0")

def alerts_count_unseen() -> int:
    with _conn() as c:
        r = c.execute("SELECT COUNT(*) as n FROM alerts WHERE seen=0").fetchone()
        return int(r["n"] if r else 0)
