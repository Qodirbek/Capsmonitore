#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CAPS Manager v2 — professional process control

• create_account → darhol start (auto_start=True)
• enabled akk EXIT/IDLE da qolmaydi — soft_restart
• har akk alohida subprocess + bot_live.log
• panel_status.json + log parse (balance, claim, stamina)
• UA conflict / cookie age / silent bot health
"""
from __future__ import annotations

import json
import os
import random
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

from app.db import (
    PLATFORMS,
    add_account,
    add_alert,
    add_captcha_stat,
    add_claim_log,
    get_account,
    get_account_by_folder,
    get_setting,
    init_db,
    list_accounts,
    update_account,
)

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
DATA.mkdir(parents=True, exist_ok=True)
BOTS = ROOT / "bots"
ACCOUNTS = ROOT / "accounts"
ACCOUNTS.mkdir(parents=True, exist_ok=True)
DELETED_FOLDERS_PATH = DATA / "deleted_folders.json"


def _load_deleted_folders() -> set:
    try:
        if DELETED_FOLDERS_PATH.is_file():
            j = json.loads(DELETED_FOLDERS_PATH.read_text(encoding="utf-8"))
            if isinstance(j, list):
                return set(str(x) for x in j)
            if isinstance(j, dict):
                return set(str(x) for x in (j.get("folders") or []))
    except Exception:
        pass
    return set()

def _save_deleted_folders(s: set) -> None:
    try:
        DATA.mkdir(parents=True, exist_ok=True)
        DELETED_FOLDERS_PATH.write_text(
            json.dumps({"folders": sorted(s), "ts": int(time.time())}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    except Exception:
        pass

def mark_folder_deleted(folder: str) -> None:
    if not folder:
        return
    s = _load_deleted_folders()
    s.add(str(folder))
    _save_deleted_folders(s)

def unmark_folder_deleted(folder: str) -> None:
    s = _load_deleted_folders()
    s.discard(str(folder))
    _save_deleted_folders(s)

DATA.mkdir(parents=True, exist_ok=True)

UA_POOL = [
    "Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; Pixel 6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Linux; Android 11; Redmi Note 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
]

_procs: dict[int, subprocess.Popen] = {}

_log_pos: dict[int, int] = {}
_SNAPSHOT: dict = {"ts": 0, "accounts": [], "prices_usd": {}, "price_change": {}, "stats": {}}
_SNAP_LOCK = __import__("threading").Lock()
_LAST_SYNC = 0.0
_SYNC_MIN_INTERVAL = 0.35  # sec — tez panel yangilash
CHECKPOINT_PATH = ROOT / "data" / "checkpoint.json"

_last_start: dict[int, float] = {}
_exit_streak: dict[int, int] = {}
_log_handles: dict[int, object] = {}

RE_BAL = re.compile(r"\[Balance\s*\]\s*([0-9]+(?:\.[0-9]+)?)", re.I)
RE_USER = re.compile(r"\[User\s*\]\s*(.+)$", re.I)
RE_CLAIM = re.compile(r"You got\s+([0-9.]+)\s*([A-Za-z]+)?", re.I)
RE_CD = re.compile(r"(?:Countdown|Next|Kutish)\s*[:\]]\s*([0-9]+)s", re.I)
RE_CD2 = re.compile(r"Next:\s*(\d{1,2}):(\d{2}):(\d{2})", re.I)
RE_IC = re.compile(r"IconCaptcha\s+(OK|yechildi|completed)|IC local", re.I)
RE_CAP_FAIL = re.compile(r"Invalid captcha|Failed captcha|captcha fail", re.I)
RE_LOGIN_OK = re.compile(r"Login OK|Login ·|✔ Login|\[✓\].*Login", re.I)


def _safe_folder(name: str) -> str:
    s = "".join(c if c.isalnum() or c in "-_" else "_" for c in (name or "").strip())[:40]
    return s or f"acc_{int(time.time())}"


def _parse_keys(raw: str) -> list:
    raw = (raw or "").strip()
    if not raw or raw in ("[]", "{}", "null", "None"):
        return []
    try:
        j = json.loads(raw)
        if isinstance(j, list):
            return [str(x).strip() for x in j if str(x).strip()]
        if isinstance(j, str) and j.strip():
            raw = j.strip()
    except Exception:
        pass
    # yangi qator / vergul / nuqta-vergul
    parts = []
    for line in raw.replace(";", "\n").splitlines():
        line = line.strip()
        if not line:
            continue
        if "," in line and not line.startswith("http") and "AIza" not in line[:8]:
            for p in line.split(","):
                p = p.strip()
                if p:
                    parts.append(p)
        else:
            parts.append(line)
    # unique order-preserving
    seen, out = set(), []
    for p in parts:
        if p not in seen:
            seen.add(p)
            out.append(p)
    return out


def build_cfg(acc: dict) -> dict:
    aw = str(acc.get("auto_withdraw") if acc.get("auto_withdraw") is not None else get_setting("auto_withdraw", "0") or "0")
    if aw.lower() in ("1", "true", "yes", "on"):
        aw = "1"
    else:
        aw = "0"
    try:
        aw_min = float(acc.get("auto_withdraw_min") or get_setting("auto_withdraw_min", "8") or 8)
    except Exception:
        aw_min = 8.0
    w = (acc.get("withdraw_wallet") or acc.get("wallet") or "").strip()
    return {
        "email": acc.get("email") or "",
        "password": acc.get("password") or "",
        "totp_secret": (acc.get("totp_secret") or "").replace(" ", "").strip(),
        "cookie": acc.get("cookie") or "",
        "user_agent": (acc.get("user_agent") or pick_unique_ua(acc.get("platform") or "", "")),
        "wallet": w,
        "withdraw_wallet": w,
        "auto_withdraw": aw,
        "auto_withdraw_min": aw_min,
        "min_withdraw": float(acc.get("min_withdraw") or 0.1),
        "gemini_api_keys": _parse_keys(get_setting("gemini_keys", "") or get_setting("gemini", "")),
        "openrouter_api_keys": _parse_keys(get_setting("openrouter_keys", "") or get_setting("openrouter", "")),
        "xevil_apikey": get_setting("xevil_apikey", "") or get_setting("xevil_key", "") or "",
        "tg_bot_token": get_setting("tg_bot_token", "") or get_setting("tg_token", "") or "",
        "tg_chat_id": get_setting("tg_chat_id", "") or get_setting("tg_chat", "") or "",
        "tz": "Asia/Tashkent",
        "no_proxy": True,
        "proxy": "",
        "ic_db": str(DATA / "ic_shared.db"),
        "prefer_iconcaptcha": True,
        "captcha_priority": ["IconCaptcha", "pCaptcha", "hCaptcha", "reCAPTCHA"],
        "dice_min_bet": 0.0001,
        "dice_min_balance": 0.005,
        "dice_payout": 1.01,
        "dice_session_bets": 15,
        "dice_daily_cap": 0,
    }


def write_account_files(acc: dict) -> Path:
    plat = PLATFORMS.get(acc["platform"])
    if not plat:
        raise ValueError(f"platform: {acc['platform']}")
    folder = ACCOUNTS / acc["folder"]
    folder.mkdir(parents=True, exist_ok=True)

    src = BOTS / plat["bot"]
    if src.is_file():
        dst = folder / plat["bot"]
        try:
            if (not dst.is_file()) or (src.stat().st_mtime > dst.stat().st_mtime + 0.5):
                shutil.copy2(src, dst)
        except Exception:
            try:
                shutil.copy2(src, dst)
            except Exception:
                pass

    (folder / plat["config"]).write_text(
        json.dumps(build_cfg(acc), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    cookie_val = (acc.get("cookie") or "").strip()
    cpath = folder / plat["cookie"]
    if cookie_val:
        cpath.write_text(cookie_val + "\n", encoding="utf-8")
    elif cpath.is_file() and not cpath.read_text(encoding="utf-8", errors="ignore").strip():
        try:
            cpath.unlink()
        except Exception:
            pass

    ps = folder / "panel_status.json"
    if not ps.is_file():
        ps.write_text(
            json.dumps(
                {
                    "user": acc.get("label") or acc.get("folder"),
                    "balance": acc.get("balance"),
                    "coin": acc.get("coin"),
                    "status": "IDLE",
                    "last": "created",
                    "source": "manager",
                    "updated": int(time.time()),
                },
                ensure_ascii=False,
            ),
            encoding="utf-8",
        )
    return folder




def _session_from_account(a: dict):
    """Cookie string → unique jar (csrf_cookie_name takrorlanmasin)."""
    import requests
    plat = PLATFORMS.get(a.get("platform") or "") or {}
    host = (plat.get("host") or "https://tronpick.io/").rstrip("/") + "/"
    folder = ACCOUNTS / (a.get("folder") or "")
    s = requests.Session()
    ua = a.get("user_agent") or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    s.headers.update({
        "User-Agent": ua,
        "Accept-Language": "en-US,en;q=0.9",
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
    })
    ck = (a.get("cookie") or "").strip()
    if not ck:
        for cname in (plat.get("cookie"), "cookie.txt", "cookie_tron.txt", "cookie_ton.txt",
                      "cookie_sui.txt", "cookie_doge.txt", "cookie_ltc.txt", "cookie_sol.txt"):
            if not cname:
                continue
            p = folder / cname
            if p.is_file():
                try:
                    ck = p.read_text(encoding="utf-8", errors="ignore").strip().splitlines()[0].strip()
                except Exception:
                    ck = ""
                if ck:
                    break
    # last value wins — takroriy nomlar yo'qoladi
    jar = {}
    for part in (ck or "").split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        k, v = part.split("=", 1)
        k, v = k.strip(), v.strip()
        if k:
            jar[k] = v
    s.cookies.clear()
    try:
        from http.cookiejar import Cookie
        from urllib.parse import urlparse
        domain = urlparse(host).hostname or "tronpick.io"
        for k, v in jar.items():
            try:
                s.cookies.set(k, v, domain=domain, path="/")
            except Exception:
                try:
                    s.cookies.set(k, v)
                except Exception:
                    pass
    except Exception:
        for k, v in jar.items():
            try:
                s.cookies.set(k, v)
            except Exception:
                pass

    def safe_csrf(body: str = "") -> str:
        csrf = jar.get("csrf_cookie_name") or ""
        # requests CookieConflictError oldini olish — dict dan
        try:
            # yagona qiymat
            items = [c for c in s.cookies if c.name == "csrf_cookie_name"]
            if len(items) == 1:
                csrf = items[0].value or csrf
            elif len(items) > 1:
                csrf = items[-1].value or csrf
                # tozalab qayta yoz
                for c in list(s.cookies):
                    if c.name == "csrf_cookie_name":
                        try:
                            s.cookies.clear(c.domain, c.path, c.name)
                        except Exception:
                            pass
                try:
                    s.cookies.set("csrf_cookie_name", csrf, domain=domain, path="/")
                except Exception:
                    s.cookies.set("csrf_cookie_name", csrf)
        except Exception:
            pass
        m = re.search(r"csrf_test_name[^>]{0,40}value=\"([^\"]+)\"", body or "") or re.search(r"csrf_test_name[^>]{0,40}value=\'([^\']+)\'", body or "")
        if m:
            csrf = m.group(1)
        return csrf or jar.get("csrf_cookie_name") or ""

    return s, host, jar, safe_csrf, bool(ck)


def totp_now(secret: str) -> str:
    secret = (secret or "").strip().replace(" ", "").upper()
    if not secret:
        return ""
    if secret.lower().startswith("otpauth://"):
        m = re.search(r"[?&]secret=([A-Z2-7]+)", secret, re.I)
        secret = (m.group(1) if m else "").upper()
    try:
        import pyotp
        return pyotp.TOTP(secret).now()
    except Exception:
        pass
    try:
        import hmac, hashlib, struct, base64, time as _t
        b = secret + "=" * ((8 - len(secret) % 8) % 8)
        key = base64.b32decode(b, casefold=True)
        counter = int(_t.time()) // 30
        h = hmac.new(key, struct.pack(">Q", counter), hashlib.sha1).digest()
        o = h[-1] & 0x0F
        code = (struct.unpack(">I", h[o:o + 4])[0] & 0x7FFFFFFF) % 1000000
        return f"{code:06d}"
    except Exception:
        return ""






def change_password_on_site(aid: int, old_password: str, new_password: str) -> dict:
    """
    Saytda parol almashtirish — JS: action=change_password2
    + captcha (hCaptcha / Icon) + ixtiyoriy ver_code.
    """
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "not found"}
    new_password = (new_password or "").strip()
    if len(new_password) < 6:
        return {"ok": False, "error": "yangi parol kamida 6 belgi"}
    old_password = (old_password or acc.get("password") or "").strip()

    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    plat = (acc.get("platform") or "").lower()
    sitekeys = {
        "tronpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "tonpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "suipick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "dogepick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "litepick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "solpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
    }
    hkey = sitekeys.get(plat, "6ef421cc-2fbc-493a-96ec-550c43f8ecd2")

    try:
        s = _acc_session(acc)
        r = s.get(host + "settings.php", timeout=35, allow_redirects=True)
        if "login.php" in (r.url or "").lower():
            try:
                ok_login = _login_session_for_deposit(acc, s, host)
            except Exception as e:
                return {"ok": False, "error": f"login: {e}"}
            if not ok_login:
                return {"ok": False, "error": "login fail — cookie/email tekshiring"}
            r = s.get(host + "settings.php", timeout=35, allow_redirects=True)
        html = r.text or ""
        if "login.php" in (r.url or "").lower():
            return {"ok": False, "error": "settings ochilmadi — sessiya yo'q"}

        csrf = _parse_csrf(html, s)
        mk = re.search(r'data-sitekey=["\']([^"\']+)["\']', html, re.I)
        if mk:
            hkey = mk.group(1)

        # captcha
        htok = ""
        try:
            htok = _solve_hcaptcha_xevil(host + "settings.php", hkey) or ""
        except Exception:
            htok = ""
        ic = None
        if not htok:
            try:
                if re.search(r"iconcaptcha|_iconcaptcha-token", html, re.I):
                    ic = _solve_icon_http(s, host, html, host + "settings.php")
            except Exception:
                ic = None
        if not htok and not ic:
            # panel parolini baribir yangilaymiz (sayt emas)
            return {
                "ok": False,
                "error": "Sayt captcha talab qiladi. Settings → xevil_apikey yoki brauzerdan parolni almashtiring. Panel paroli alohida saqlanadi.",
                "need_captcha": True,
            }

        data = {
            "action": "change_password2",
            "new_password": new_password,
            "confirm_password": new_password,
            "ver_code": "",
            "old_password": old_password,
            "csrf_test_name": csrf or "",
            "captcha_type": "2" if htok else "0",
            "h-captcha-response": htok or "",
            "g-recaptcha-response": "",
            "c_captcha_response": "",
            "pcaptcha_token": "",
        }
        if ic:
            data.update({
                "captcha_type": "0",
                "_iconcaptcha-token": ic.get("_iconcaptcha-token", ""),
                "ic-rq": ic.get("ic-rq", "1"),
                "ic-wid": ic.get("ic-wid", ""),
                "ic-cid": ic.get("ic-cid", ""),
                "ic-hp": ic.get("ic-hp", ""),
            })

        resp = s.post(
            host + "process.php",
            data=data,
            headers={
                "X-Requested-With": "XMLHttpRequest",
                "Referer": host + "settings.php",
                "Origin": host.rstrip("/"),
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
            timeout=50,
        )
        text = (resp.text or "").strip()
        try:
            obj = resp.json() if text[:1] == "{" else {}
        except Exception:
            obj = {}
        mes = str((obj.get("mes") if isinstance(obj, dict) else None) or text[:200])
        ok = isinstance(obj, dict) and obj.get("ret") in (1, "1", True)
        try:
            _persist_cookie(acc, _merge_cookie_strings(acc.get("cookie") or "", _session_cookie_string(s)))
        except Exception:
            pass
        if ok:
            # panel parolini ham yangilash
            try:
                update_account(aid, password=new_password)
                write_account_files(get_account(aid))
            except Exception:
                pass
            return {"ok": True, "mes": mes or "Password changed", "action": "change_password2"}
        return {"ok": False, "error": mes or "fail", "mes": mes}
    except Exception as e:
        err = str(e)
        if "multiple cookies" in err.lower():
            err = "cookie konflikti — Refresh qilib qayta urining"
        return {"ok": False, "error": err}


def enable_2fa_on_site(aid: int) -> dict:
    """
    2FA yoqish: settings/enable sahifadan secret → TOTP → enable (+ captcha).
    Secret har doim panelga yoziladi.
    """
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "not found"}
    existing = (acc.get("totp_secret") or "").strip()
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    plat = (acc.get("platform") or "").lower()
    hkey = "6ef421cc-2fbc-493a-96ec-550c43f8ecd2"

    def _parse_secret(body: str) -> str:
        if not body:
            return ""
        for pat in (
            r'value=["\']([A-Z2-7]{10,32})["\']',
            r'secret[^A-Z2-7]{0,40}([A-Z2-7]{10,32})',
            r'otpauth://totp/[^?]+\?secret=([A-Z2-7]+)',
            r'data-secret=["\']([A-Z2-7]+)["\']',
        ):
            for m in re.finditer(pat, body, re.I):
                sec = m.group(1).upper().replace(" ", "")
                if 10 <= len(sec) <= 64 and re.fullmatch(r"[A-Z2-7]+", sec):
                    return sec
        return ""

    try:
        s = _acc_session(acc)
        html = ""
        secret = ""
        for path in ("settings.php", "enable_2fa.php", "account.php"):
            try:
                r = s.get(host + path, timeout=35, allow_redirects=True)
            except Exception:
                continue
            if "login.php" in (r.url or "").lower() and path != "settings.php":
                continue
            if "login.php" in (r.url or "").lower():
                try:
                    if not _login_session_for_deposit(acc, s, host):
                        return {"ok": False, "error": "login fail"}
                    r = s.get(host + path, timeout=35, allow_redirects=True)
                except Exception as e:
                    return {"ok": False, "error": f"login: {e}"}
            html = r.text or ""
            if existing and re.search(r"USER_ENABLE_2FA\s*=\s*1|2fa is enabled|Disable 2FA", html, re.I):
                return {"ok": True, "already": True, "totp_secret": existing, "mes": "2FA allaqachon yoqilgan"}
            secret = _parse_secret(html)
            if secret:
                break

        if not secret:
            return {"ok": False, "error": "Secret topilmadi — settings da Enable 2FA ochiqligini tekshiring / Refresh"}

        code = totp_now(secret)
        if not code:
            update_account(aid, totp_secret=secret)
            try:
                write_account_files(get_account(aid))
            except Exception:
                pass
            return {"ok": False, "error": "TOTP kod chiqmadi", "totp_secret": secret, "saved": True}

        csrf = _parse_csrf(html, s)
        mk = re.search(r'data-sitekey=["\']([^"\']+)["\']', html, re.I)
        if mk:
            hkey = mk.group(1)

        htok = ""
        try:
            htok = _solve_hcaptcha_xevil(host + "settings.php", hkey) or ""
        except Exception:
            htok = ""
        ic = None
        if not htok:
            try:
                if re.search(r"iconcaptcha|_iconcaptcha-token", html, re.I):
                    ic = _solve_icon_http(s, host, html, host + "settings.php")
            except Exception:
                ic = None

        last = {"ok": False, "error": "enable fail", "totp_secret": secret}
        for action in ("enable_2fa_code2", "enable_2fa", "enable_2fa_code", "confirm_2fa"):
            data = {
                "action": action,
                "code": code,
                "twofa": code,
                "twofa_code": code,
                "auth_code": code,
                "secret": secret,
                "secret_key": secret,
                "csrf_test_name": csrf or "",
                "captcha_type": "2" if htok else ("0" if ic else "2"),
                "h-captcha-response": htok or "",
                "g-recaptcha-response": "",
                "c_captcha_response": "",
                "pcaptcha_token": "",
            }
            if ic:
                data.update({
                    "captcha_type": "0",
                    "_iconcaptcha-token": ic.get("_iconcaptcha-token", ""),
                    "ic-rq": ic.get("ic-rq", "1"),
                    "ic-wid": ic.get("ic-wid", ""),
                    "ic-cid": ic.get("ic-cid", ""),
                    "ic-hp": ic.get("ic-hp", ""),
                })
            try:
                resp = s.post(
                    host + "process.php",
                    data=data,
                    headers={
                        "X-Requested-With": "XMLHttpRequest",
                        "Referer": host + "settings.php",
                        "Origin": host.rstrip("/"),
                        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    },
                    timeout=50,
                )
            except Exception as e:
                last = {"ok": False, "error": str(e), "totp_secret": secret}
                continue
            text = (resp.text or "").strip()
            try:
                obj = resp.json() if text[:1] == "{" else {}
            except Exception:
                obj = {}
            mes = str((obj.get("mes") if isinstance(obj, dict) else None) or text[:200])
            if isinstance(obj, dict) and obj.get("ret") in (1, "1", True):
                last = {"ok": True, "mes": mes, "action": action, "totp_secret": secret, "code": code}
                break
            if re.search(r"captcha", mes, re.I) and not htok and not ic:
                last = {
                    "ok": False,
                    "error": "Captcha kerak — Settings da xevil_apikey qo'ying. Secret saqlanadi.",
                    "totp_secret": secret,
                    "need_captcha": True,
                }
                break
            last = {"ok": False, "error": mes[:180], "totp_secret": secret, "action": action}

        # secret doim saqlansin
        update_account(aid, totp_secret=secret)
        try:
            write_account_files(get_account(aid))
        except Exception:
            pass
        last["totp_secret"] = secret
        last["saved"] = True
        try:
            _persist_cookie(acc, _merge_cookie_strings(acc.get("cookie") or "", _session_cookie_string(s)))
        except Exception:
            pass
        return last
    except Exception as e:
        err = str(e)
        if "multiple cookies" in err.lower():
            err = "cookie konflikti — Refresh qilib qayta urining"
        return {"ok": False, "error": err}


def create_account(
    platform,
    label="",
    email="",
    password="",
    cookie="",
    wallet="",
    user_agent="",
    totp_secret="",
    auto_start: bool = True,
) -> int:
    """Hisob yaratish + (default) darhol bot start."""
    init_db()
    if platform not in PLATFORMS:
        raise ValueError("platform not found")
    if not (email or cookie):
        raise ValueError("email+password yoki cookie kerak")

    plat = PLATFORMS[platform]
    base = label or (email.split("@")[0] if email else platform)
    folder = _safe_folder(f"{plat['coin'].lower()}_{base}")
    n, orig = 1, folder
    while (ACCOUNTS / folder).exists() or get_account_by_folder(folder):
        folder = f"{orig}_{n}"
        n += 1

    ua = user_agent or random.choice(UA_POOL)
    used = {
        a.get("user_agent")
        for a in list_accounts()
        if a.get("coin") == plat["coin"]
    }
    for _ in range(16):
        if ua not in used:
            break
        ua = random.choice(UA_POOL)

    aid = add_account(
        folder=folder,
        platform=platform,
        coin=plat["coin"],
        label=label or folder,
        email=email or "",
        password=password or "",
        totp_secret=(totp_secret or "").replace(" ", "").strip(),
        cookie=cookie or "",
        wallet=wallet or "",
        user_agent=ua,
    )
    unmark_folder_deleted((get_account(aid) or {}).get("folder") or "")
    write_account_files(get_account(aid))
    try:
        ensure_unique_uas()
    except Exception:
        pass
    add_alert("info", f"Account added: {folder}", platform, aid)

    if auto_start:
        time.sleep(0.2)
        start_account(aid)
    return aid


def _close_log(aid: int) -> None:
    h = _log_handles.pop(aid, None)
    if h is None:
        return
    try:
        h.flush()
    except Exception:
        pass
    try:
        h.close()
    except Exception:
        pass


def start_account(aid: int) -> bool:
    acc = get_account(aid)
    if not acc:
        return False
    en = acc.get("enabled")
    if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
        update_account(aid, status="STOP", last_msg="disabled", health="stopped")
        return False

    max_bots = max_bots_limit()
    if max_bots > 0:
        alive = alive_bot_count()
        # yangi / ma'lumotsiz hisobga +2 slot soft-limit (tez bootstrap)
        soft = max_bots
        try:
            if (acc.get("balance") is None or float(acc.get("balance") or 0) == 0) and not (acc.get("label") or "").strip():
                soft = max_bots + 2
            if (acc.get("last_msg") or "").lower() in ("created", "started", ""):
                soft = max(soft, max_bots + 1)
        except Exception:
            soft = max_bots
        if alive >= soft:
            if not (_procs.get(aid) and _procs[aid].poll() is None):
                update_account(aid, status="WAIT", last_msg=f"queue {alive}/{max_bots}", health="ok")
                return False

    # tirik process
    p = _procs.get(aid)
    if p is not None and p.poll() is None:
        update_account(
            aid,
            status="RUN",
            last_msg=acc.get("last_msg") or "running",
            health="ok",
            last_seen_ts=int(time.time()),
        )
        return True

    if p is not None:
        _procs.pop(aid, None)
        _close_log(aid)

    plat = PLATFORMS.get(acc["platform"])
    if not plat:
        update_account(aid, status="ERR", last_msg="bad platform", health="error")
        return False

    folder = write_account_files(acc)
    script = folder / plat["bot"]
    if not script.is_file():
        src = BOTS / plat["bot"]
        if src.is_file():
            try:
                shutil.copy2(src, script)
            except Exception as e:
                print("[bot copy]", e)
        if not script.is_file():
            update_account(aid, status="ERR", last_msg="bot yo'q", health="error")
            add_alert("error", f"Bot missing: {acc['folder']}", str(plat.get("bot")), aid)
            return False

    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["IC_DB"] = str(DATA / "ic_shared.db")

    log_path = folder / "bot_live.log"
    try:
        if log_path.is_file() and log_path.stat().st_size > 3_000_000:
            tail = log_path.read_text(encoding="utf-8", errors="ignore")[-250000:]
            log_path.write_text(tail, encoding="utf-8")
    except Exception:
        try:
            log_path.write_text("", encoding="utf-8")
        except Exception:
            pass

    try:
        logf = open(log_path, "a", encoding="utf-8", buffering=1)
        proc = subprocess.Popen(
            [sys.executable, "-u", str(script)],
            cwd=str(folder),
            stdout=logf,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            env=env,
            start_new_session=True,
        )
        _log_handles[aid] = logf
        _procs[aid] = proc
        try:
            _log_pos[aid] = log_path.stat().st_size
        except Exception:
            _log_pos[aid] = 0
        _last_start[aid] = time.time()
        _exit_streak[aid] = 0

        update_account(
            aid,
            status="RUN",
            last_msg="started",
            health="ok",
            last_seen_ts=int(time.time()),
        )
        try:
            (folder / "panel_status.json").write_text(
                json.dumps(
                    {
                        "user": acc.get("label") or acc.get("folder"),
                        "balance": acc.get("balance"),
                        "coin": acc.get("coin"),
                        "status": "RUN",
                        "last": "started",
                        "source": "manager",
                        "updated": int(time.time()),
                    },
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
        except Exception:
            pass
        return True
    except Exception as e:
        _close_log(aid)
        update_account(aid, status="ERR", last_msg=str(e)[:40], health="error")
        add_alert("error", f"Start fail: {acc['folder']}", str(e)[:120], aid)
        return False


def stop_account(aid: int, reason: str = "stopped") -> None:
    p = _procs.pop(aid, None)
    if p is not None and p.poll() is None:
        try:
            os.killpg(p.pid, signal.SIGINT)
        except Exception:
            try:
                p.send_signal(signal.SIGINT)
            except Exception:
                pass
        try:
            p.wait(timeout=3)
        except Exception:
            try:
                os.killpg(p.pid, signal.SIGKILL)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
    _close_log(aid)
    update_account(aid, status="STOP", last_msg=reason, health="stopped")


def is_running(aid: int) -> bool:
    p = _procs.get(aid)
    if p is None:
        return False
    if p.poll() is not None:
        _procs.pop(aid, None)
        _close_log(aid)
        return False
    return True


def _read_new_lines(aid: int, folder: Path) -> list[str]:
    """Faqat yangi log; juda katta o'sish bo'lsa oxirgi 48KB (timer spam)."""
    path = folder / "bot_live.log"
    if not path.is_file():
        return []
    try:
        size = path.stat().st_size
        pos = int(_log_pos.get(aid, 0) or 0)
        if size < pos:
            pos = 0
        if size == pos:
            return []
        # 200KB+ yangi ma'lumot = asosan countdown spinner — oxirini ol
        if size - pos > 200_000:
            pos = max(pos, size - 48_000)
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            f.seek(pos)
            data = f.read()
            _log_pos[aid] = f.tell()
        lines = []
        for ln in data.splitlines():
            s = ln.strip()
            if not s:
                continue
            # spinner qatorlarini tashla
            if "Next:" in s and len(s) < 40:
                continue
            lines.append(s)
        # juda ko'p qator bo'lsa oxirgi 80 tasi
        if len(lines) > 80:
            lines = lines[-80:]
        return lines
    except Exception:
        return []



def _ingest_claim_files(aid: int, folder: Path, acc: dict) -> dict:
    """claim_event.json + claims_history.jsonl → claim_log (tez, ishonchli)."""
    out = {}
    try:
        ev = folder / "claim_event.json"
        if ev.is_file():
            j = json.loads(ev.read_text(encoding="utf-8"))
            kind = str(j.get("claim_kind") or j.get("kind") or "hourly").lower()
            if kind in ("hourly", "faucet", ""):
                msg = str(j.get("claim_msg") or j.get("msg") or "")
                if not re.search(r"affiliat|commission|referral", msg, re.I):
                    amt = str(j.get("claim_amount") or j.get("amount") or msg)[:80]
                    capn = str(j.get("claim_captcha") or j.get("captcha") or "Hourly")[:40]
                    ts = int(j.get("ts") or j.get("updated") or time.time())
                    sig = f"e|{ts}|{capn}|{amt}"
                    if _last_claim_sig.get(aid) != sig:
                        _last_claim_sig[aid] = sig
                        add_claim_log(aid, capn, amt, "accepted", msg[:120])
                        out["last_msg"] = f"CLAIM {amt}"[:80]
                        out["status"] = "OK"
                        try:
                            ct = int(j.get("claims_today") or 0)
                            old_ct = int(acc.get("claims_today") or 0)
                            out["claims_today"] = max(ct, old_ct + (0 if ct else 1)) if ct or old_ct else old_ct + 1
                            if ct > 0:
                                out["claims_today"] = max(ct, old_ct)
                        except Exception:
                            pass
            try:
                ev.unlink(missing_ok=True)
            except Exception:
                try:
                    ev.write_text("{}", encoding="utf-8")
                except Exception:
                    pass
    except Exception:
        pass
    # jsonl tail (faqat yangi)
    try:
        jl = folder / "claims_history.jsonl"
        if jl.is_file():
            key = f"jl:{aid}"
            pos = int(_last_claim_sig.get(key) or 0)
            data = jl.read_bytes()
            if len(data) > pos:
                chunk = data[pos:].decode("utf-8", errors="ignore")
                for line in chunk.splitlines():
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        j = json.loads(line)
                    except Exception:
                        continue
                    if str(j.get("kind") or "hourly").lower() not in ("hourly", "faucet", ""):
                        continue
                    msg = str(j.get("msg") or "")
                    if re.search(r"affiliat|commission|referral", msg, re.I):
                        continue
                    amt = str(j.get("amount") or msg)[:80]
                    capn = str(j.get("captcha") or "Hourly")[:40]
                    ts = int(j.get("ts") or time.time())
                    sig = f"jl|{ts}|{capn}|{amt}"
                    if _last_claim_sig.get(aid) == sig:
                        continue
                    _last_claim_sig[aid] = sig
                    add_claim_log(aid, capn, amt, "accepted", msg[:120])
                    out["last_msg"] = f"CLAIM {amt}"[:80]
                    try:
                        ct = int(j.get("claims_today") or 0)
                        if ct > 0:
                            out["claims_today"] = max(ct, int(acc.get("claims_today") or 0))
                    except Exception:
                        pass
                _last_claim_sig[key] = len(data)
    except Exception:
        pass
    return out


def sync_status_from_files(force: bool = False) -> None:
    """Log/panel holatini DB ga yozadi. API yo'lida chaqirilmaydi — faqat worker."""
    global _LAST_SYNC
    now = time.time()
    if not force and (now - _LAST_SYNC) < _SYNC_MIN_INTERVAL:
        return
    _LAST_SYNC = now
    _sync_status_from_files_impl()
    refresh_snapshot()


def _sync_status_from_files_impl() -> None:
    """Tez sync: asosiy manba panel_status.json (mtime).
    Log faqat yangi qisqa qatorlar — countdown spinner o'tkazib yuboriladi.
    """
    now = time.time()
    for acc in list_accounts():
        aid = acc["id"]
        folder = ACCOUNTS / acc["folder"]

        # claim event / jsonl — panel dan oldin (tez saqlash)
        try:
            ing = _ingest_claim_files(aid, folder, acc)
            if ing:
                update_account(aid, **ing)
        except Exception:
            pass

        # process holati
        p = _procs.get(aid)
        if p is not None and p.poll() is not None:
            code = p.returncode
            _procs.pop(aid, None)
            _close_log(aid)
            # SLEEP (next_ts kelajak) — slot bo'sh, xato emas
            nts_sleep = 0
            sleep_ok = False
            try:
                ps = folder / "panel_status.json"
                if ps.is_file():
                    jj = json.loads(ps.read_text(encoding="utf-8"))
                    nts_sleep = int(jj.get("next_ts") or 0)
                    if jj.get("sleep") or str(jj.get("status") or "").upper() == "SLEEP":
                        sleep_ok = True
                    if nts_sleep > now + 30:
                        sleep_ok = True
            except Exception:
                pass
            if sleep_ok and nts_sleep > now:
                _exit_streak[aid] = 0
                update_account(
                    aid,
                    status="SLEEP",
                    last_msg=f"sleep until {time.strftime('%H:%M', time.localtime(nts_sleep))}",
                    health="ok",
                    next_ts=nts_sleep,
                )
            else:
                _exit_streak[aid] = int(_exit_streak.get(aid, 0)) + 1
                update_account(
                    aid, status="EXIT", last_msg=f"exit:{code}", health="down"
                )
                if _exit_streak[aid] >= 3:
                    add_alert(
                        "warn",
                        f"Process exit: {acc['folder']}",
                        f"code={code} streak={_exit_streak[aid]}",
                        aid,
                    )

        # ── 1) panel_status.json (eng ishonchli, tez) ──
        ps = folder / "panel_status.json"
        try:
            if ps.is_file():
                mtime = ps.stat().st_mtime
                # har doim o'qiymiz (kichik JSON) — lekin parse arzon
                j = json.loads(ps.read_text(encoding="utf-8"))
                if isinstance(j, dict) and j.get("source") == "bot":
                    kw = {"last_seen_ts": int(j.get("updated") or now)}
                    if j.get("user"):
                        u = str(j["user"]).strip()[:40]
                        if u.lower() not in ("ok", "session", "—", "-", ""):
                            kw["label"] = u
                    if j.get("balance") is not None:
                        try:
                            nb = sticky_balance(acc.get("balance"), j.get("balance"))
                            if nb is not None:
                                kw["balance"] = nb
                        except Exception:
                            pass
                    st = (j.get("status") or "").upper()
                    if st:
                        if st == "SLEEP":
                            kw["status"] = "SLEEP"
                        elif st == "WAIT":
                            kw["status"] = "WAIT"
                        elif st in ("OK", "CLAIM"):
                            kw["status"] = "OK"
                        elif st == "WARN":
                            kw["status"] = "RUN" if is_running(aid) else "WARN"
                        elif st == "RUN":
                            kw["status"] = "RUN" if is_running(aid) else "WAIT"
                        else:
                            kw["status"] = st
                    try:
                        nts_chk = int(j.get("next_ts") or acc.get("next_ts") or 0)
                        if nts_chk > now + 90 and not is_running(aid):
                            kw["status"] = "SLEEP"
                    except Exception:
                        pass

                    if j.get("last"):
                        last = str(j["last"])[:48]
                        # "started" ni bot ma'lumoti bilan almashtirish
                        if last and last.lower() not in ("started", "created"):
                            kw["last_msg"] = last
                        elif (acc.get("last_msg") or "").lower() in ("started", "created", ""):
                            if st == "WAIT":
                                kw["last_msg"] = "countdown"
                            elif st:
                                kw["last_msg"] = st.lower()
                    for k, cast in (
                        ("claims_left", int),
                        ("stamina_pct", float),
                        ("wager_pct", float),
                    ):
                        if j.get(k) is not None:
                            try:
                                kw[k] = cast(j[k])
                            except Exception:
                                pass
                    if j.get("claims_today") is not None:
                        try:
                            ct = int(j.get("claims_today") or 0)
                            old_ct = int(acc.get("claims_today") or 0)
                            if ct > 0:
                                kw["claims_today"] = max(ct, old_ct)
                            elif old_ct == 0:
                                kw["claims_today"] = 0
                        except Exception:
                            pass
                    
                    # Faqat hourly faucet claim (affiliate/bonus emas)
                    if j.get("claim_ok") and str(j.get("claim_kind") or "hourly").lower() in ("hourly", "faucet", "1", "true", ""):
                        try:
                            kind = str(j.get("claim_kind") or "hourly").lower()
                            msg0 = str(j.get("claim_msg") or j.get("last") or "")
                            if re.search(r'affiliat|commission|bonus faucet|referral', msg0, re.I):
                                pass  # affiliate — history ga yo'q
                            else:
                                amt = str(j.get("claim_amount") or msg0 or "")[:80]
                                capn = str(j.get("claim_captcha") or "Hourly")[:40]
                                upd = int(j.get("updated") or 0)
                                sig = f"h|{upd}|{capn}|{amt}"
                                if _last_claim_sig.get(aid) != sig and (amt or msg0):
                                    _last_claim_sig[aid] = sig
                                    add_claim_log(aid, capn, amt or msg0[:40], "accepted", msg0[:120])
                                    kw["last_msg"] = f"CLAIM {amt}"[:80]
                                    kw["status"] = "OK"
                                    try:
                                        ct = int(j.get("claims_today") or 0)
                                        old_ct = int(acc.get("claims_today") or 0)
                                        if ct > old_ct:
                                            kw["claims_today"] = ct
                                        elif ct > 0:
                                            kw["claims_today"] = max(ct, old_ct)
                                        else:
                                            kw["claims_today"] = old_ct + 1
                                    except Exception:
                                        pass
                        except Exception:
                            pass
                    if j.get("next_ts"):


                        try:
                            nts = int(j.get("next_ts") or 0)
                            if nts > 0:
                                kw["next_ts"] = nts
                                kw["wait_sec"] = max(0, nts - int(now))
                        except Exception:
                            pass
                    if j.get("level"):
                        try:
                            lv = str(j.get("level") or "").strip()
                            if lv and lv not in ("—", "-", "None"):
                                kw["level"] = lv[:80]
                        except Exception:
                            pass

                    # panel next_ts yo'q — DB dagi next_ts dan wait_sec yangila
                    if "next_ts" not in kw and acc.get("next_ts"):
                        try:
                            nts0 = int(acc.get("next_ts") or 0)
                            if nts0 > 0:
                                kw["wait_sec"] = max(0, nts0 - int(now))
                                if kw["wait_sec"] > 0 and (acc.get("status") or "").upper() not in ("OK",):
                                    kw["status"] = "WAIT"
                        except Exception:
                            pass

                    if is_running(aid):
                        kw["health"] = "ok"
                    if len(kw) > 1:
                        update_account(aid, **kw)
        except Exception:
            pass

        # ── 2) log — faqat foydali qatorlar, spinner emas ──
        try:
            for line in _read_new_lines(aid, folder):
                line = re.sub(r"\033\[[0-9;]*m", "", line).strip()
                if not line:
                    continue
                # countdown spinner: "Next: 00:39:59" yoki toza spin — o'tkaz
                if re.match(r"^[─/|\\]\s*Next:", line) or re.match(r"^Next:\s*\d{2}:", line):
                    continue
                if len(line) < 3:
                    continue
                update_account(aid, last_seen_ts=int(time.time()), health="ok")

                m = RE_BAL.search(line)
                if m:
                    try:
                        update_account(aid, balance=float(m.group(1)))
                    except Exception:
                        pass

                m = RE_USER.search(line)
                if m:
                    u = m.group(1).strip()[:40]
                    if u.lower() not in ("ok", "session", "—", "-", ""):
                        update_account(aid, label=u)

                if RE_LOGIN_OK.search(line):
                    update_account(aid, status="RUN", last_msg="login ok", health="ok")

                m = RE_CLAIM.search(line)
                if m and not re.search(r'affiliat|commission|referral', line, re.I):
                    amt = m.group(1)
                    coin = (m.group(2) or acc.get("coin") or "").upper().replace("GRAM", "TON")
                    add_claim_log(aid, "Claim", f"+{amt} {coin}", "accepted", (line or "")[:120])
                    try:
                        cur = get_account(aid) or acc
                        ct = int(cur.get("claims_today") or 0) + 1
                        update_account(
                            aid,
                            status="OK",
                            last_msg=f"CLAIM +{amt}",
                            claims_today=ct,
                            health="ok",
                        )
                    except Exception:
                        update_account(aid, status="OK", last_msg=f"CLAIM +{amt}")

                if re.search(r"invalid captcha|captcha fail|Captcha yechilmadi", line, re.I):
                    # Jarayon tirik bo'lsa WARN ga qotirib qo'ymaymiz — faqat xabar
                    if is_running(aid):
                        update_account(aid, status="RUN", last_msg="captcha retry", health="warn")
                    else:
                        update_account(aid, status="WARN", last_msg="captcha fail", health="warn")

                m = RE_CD.search(line)
                if m:
                    try:
                        sec = int(m.group(1))
                        if sec > 5:
                            update_account(aid, status="WAIT", last_msg=f"{sec}s")
                    except Exception:
                        pass

                m = re.search(r"Next:\s*(\d{2}):(\d{2}):(\d{2})", line)
                if m:
                    try:
                        h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3))
                        update_account(aid, status="WAIT", last_msg=f"{h:02d}:{mi:02d}:{s:02d}")
                    except Exception:
                        pass

                m = re.search(r"\[StaminaPct\s*\]\s*([0-9.]+)", line, re.I)
                if m:
                    try:
                        update_account(aid, stamina_pct=float(m.group(1)))
                    except Exception:
                        pass
                m = re.search(r"\[ClaimsLeft\s*\]\s*(\d+)", line, re.I)
                if m:
                    try:
                        update_account(aid, claims_left=int(m.group(1)))
                    except Exception:
                        pass
                m = re.search(r"\[WagerPct\s*\]\s*([0-9.]+)", line, re.I)
                if m:
                    try:
                        update_account(aid, wager_pct=float(m.group(1)))
                    except Exception:
                        pass
        except Exception:
            pass



def health_scan() -> None:
    now = int(time.time())
    ua_map: dict[str, list] = {}
    for a in list_accounts():
        aid = a["id"]
        cu = a.get("cookie_updated_ts")
        if a.get("cookie") and cu and now - int(cu) > 7 * 86400:
            add_alert(
                "warn",
                f"Cookie eski: {a.get('label') or a['folder']}",
                "7+ kun — yangilang",
                aid,
            )
            update_account(aid, health="cookie_old")

        ls = a.get("last_seen_ts")
        if a.get("enabled") and ls and now - int(ls) > 7200 and is_running(aid):
            add_alert(
                "warn",
                f"Silent bot: {a.get('label') or a['folder']}",
                "2 soat log yo'q",
                aid,
            )

        ua = (a.get("user_agent") or "").strip()
        if ua:
            key = f"{a.get('coin')}|{ua}"
            ua_map.setdefault(key, []).append(a)

    for key, group in ua_map.items():
        if len(group) > 1:
            names = ", ".join(x["folder"] for x in group)
            add_alert("high", "Bir xil UA", names, group[0]["id"])






def sticky_balance(old, new) -> float | None:
    """Balansni 0 yoki noto'g'ri kichik qiymat bilan o'chirmaslik.
    Yangi qiymat ishonchli bo'lsa qabul; aks holda eski saqlanadi.
    """
    try:
        o = float(old) if old is not None else None
    except Exception:
        o = None
    try:
        n = float(new) if new is not None else None
    except Exception:
        n = None
    if n is None:
        return o
    if n < 0:
        return o
    # 0 keldi, eski > 0 — saqlab qol (parse fail)
    if n == 0 and o is not None and o > 0:
        return o
    # yangi 50x kichik (masalan 1.45 → 0.03 claim sum) — rad et
    if o is not None and o > 0.001 and n > 0 and n < o * 0.05 and (o - n) > 0.01:
        return o
    return n


def max_bots_limit() -> int:
    """Default 10 — 50–70 akk uchun sleep slotni bo'shatadi. CAPS_MAX_BOTS env."""
    try:
        _mb = os.environ.get("CAPS_MAX_BOTS")
        if _mb is not None and str(_mb).strip() != "":
            return max(1, min(30, int(_mb)))
    except Exception:
        pass
    return 10



def alive_bot_count() -> int:
    return sum(1 for pr in list(_procs.values()) if pr is not None and pr.poll() is None)


def _account_priority(acc: dict) -> tuple:
    """Past qiymat = yuqori ustuvorlik (tez claim kerak)."""
    now = int(time.time())
    try:
        nts = int(acc.get("next_ts") or 0)
    except Exception:
        nts = 0
    if nts <= 0:
        # hech qachon claim qilmagan / noma'lum — o'rtacha
        due = 0
    else:
        due = max(0, nts - now)
    st = (acc.get("status") or "").upper()
    # EXIT/ERR tezroq qayta start
    urgent = 0 if st in ("EXIT", "ERR", "DOWN") else 1
    return (urgent, due, int(acc.get("id") or 0))



def recycle_idle_slots(keep_due_minutes: int = 25) -> int:
    """Uzoq kutayotgan (next_ts uzoq) tirik botlarni to'xtatib slot bo'shatadi.
    Claim vaqti yaqin/o'tgan hisoblar o'rniga joy ochiladi."""
    now = int(time.time())
    limit = max_bots_limit()
    alive = alive_bot_count()
    if alive < limit:
        return 0
    # due: next_ts o'tgan yoki 3 min ichida
    due = []
    far = []
    for a in list_accounts():
        en = a.get("enabled")
        if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
            continue
        aid = a["id"]
        try:
            nts = int(a.get("next_ts") or 0)
        except Exception:
            nts = 0
        running = is_running(aid)
        if not running:
            if nts <= 0 or nts <= now + 180:
                due.append(aid)
            continue
        # running
        if nts > 0 and nts > now + keep_due_minutes * 60:
            far.append((nts, aid))
        elif nts <= 0:
            # next_ts noma'lum — uzoq deb hisoblama
            pass
    if not due or not far:
        return 0
    far.sort(reverse=True)  # eng uzoq birinchi
    stopped = 0
    need = min(len(due), len(far), max(1, alive - limit + len(due)))
    for _, aid in far[:need]:
        try:
            stop_account(aid)
            update_account(aid, status="WAIT", last_msg="slot free — next claim kutadi", health="ok")
            stopped += 1
            print(f"[recycle] stop id={aid} (next uzoq)")
        except Exception as e:
            print("[recycle]", aid, e)
    return stopped


def smart_schedule(max_start: int = 3) -> int:
    """Bo'sh slotlarga navbatdagi hisoblarni smart tartibda start qiladi.
    Priority: EXIT/ERR → next_ts yaqin → qolganlar.
    """
    try:
        recycle_idle_slots(25)
    except Exception as e:
        print("[smart recycle]", e)
    limit = max_bots_limit()
    alive = alive_bot_count()
    free = max(0, limit - alive)
    if free <= 0:
        # due hisoblar bor — yana bir marta qattiqroq recycle
        try:
            if recycle_idle_slots(15) > 0:
                alive = alive_bot_count()
                free = max(0, limit - alive)
        except Exception:
            pass
    if free <= 0:
        return 0
    to_start = min(free, max(1, max_start))
    cands = []
    for a in list_accounts():
        en = a.get("enabled")
        if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
            continue
        if not ((a.get("cookie") or "").strip() or (a.get("email") or "").strip()):
            continue
        aid = a["id"]
        if is_running(aid):
            continue
        # juda tez qayta start qilmasin
        if time.time() - float(_last_start.get(aid) or 0) < 20:
            continue
        cands.append(a)
    cands.sort(key=_account_priority)
    n = 0
    for a in cands[:to_start]:
        try:
            if start_account(a["id"]):
                n += 1
                time.sleep(0.6)
            else:
                # queue yoki real fail — keyingi tick
                pass
        except Exception as e:
            print(f"[smart] start {a.get('id')}: {e}")
    return n


def soft_restart_exited() -> int:
    """SLEEP/EXIT/queue — next_ts due bo'lsa birinchi start. Slot max_bots."""
    n = 0
    now = time.time()
    rows = []
    for acc in list_accounts():
        en = acc.get("enabled")
        if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
            continue
        aid = acc["id"]
        if is_running(aid):
            continue
        if now - float(_last_start.get(aid) or 0) < 20:
            continue
        st = (acc.get("status") or "").upper()
        msg = (acc.get("last_msg") or "").lower()
        try:
            nts = int(acc.get("next_ts") or 0)
        except Exception:
            nts = 0
        if not nts:
            try:
                ps = (ACCOUNTS / acc["folder"]) / "panel_status.json"
                if ps.is_file():
                    jj = json.loads(ps.read_text(encoding="utf-8"))
                    nts = int(jj.get("next_ts") or 0)
            except Exception:
                pass
        need = (
            st in ("EXIT", "DOWN", "ERR", "WAIT", "IDLE", "SLEEP", "")
            or st.startswith("EXIT")
            or msg.startswith("queue")
            or msg.startswith("sleep")
            or (nts > 0 and nts <= now + 20)
        )
        if not need:
            continue
        # 15 daqiqa oldin uyg'onish (slot band, claimga tayyor)
        WAKE_EARLY = 900
        if nts > now + WAKE_EARLY:
            continue
        # due/yaqin = 0, exit=1, else=2
        if nts and nts <= now + WAKE_EARLY:
            pri = 0
        elif st in ("EXIT", "DOWN", "ERR"):
            pri = 1
        else:
            pri = 2
        rows.append((pri, nts or 0, acc))
    rows.sort(key=lambda x: (x[0], x[1]))
    for pri, nts, acc in rows:
        aid = acc["id"]
        if alive_bot_count() >= max_bots_limit():
            break
        try:
            if start_account(aid):
                n += 1
                time.sleep(0.5)
        except Exception:
            pass
    n += smart_schedule(max_start=2)
    return n



def bootstrap_empty_accounts(limit: int = 3) -> int:
    """Balans/label yo'q hisoblarni saytdan to'ldirish + start."""
    n = 0
    for a in list_accounts():
        en = a.get("enabled")
        if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
            continue
        try:
            bal_f = float(a.get("balance") or 0)
        except Exception:
            bal_f = 0.0
        if bal_f > 0 and (a.get("label") or "").strip():
            continue
        if not ((a.get("cookie") or "").strip() or (a.get("email") or "").strip()):
            continue
        aid = a["id"]
        try:
            refresh_account_live(aid)
            n += 1
        except Exception as e:
            print("[bootstrap]", aid, e)
        try:
            if not is_running(aid):
                start_account(aid)
        except Exception:
            pass
        if n >= limit:
            break
    return n


def ensure_all_running() -> None:
    """Smart bot manager: slot recycle + EXIT qayta start + due hisoblarni uyg'otish."""
    try:
        recycle_idle_slots(25)
    except Exception as e:
        print("[ensure recycle]", e)
    try:
        soft_restart_exited()
    except Exception as e:
        print("[ensure]", e)
    try:
        smart_schedule(max_start=4)
    except Exception as e:
        print("[smart]", e)
    # due (next_ts o'tgan) lekin ishlamayotgan — majburiy start urinish
    try:
        now = int(time.time())
        limit = max_bots_limit()
        alive = alive_bot_count()
        if alive < limit:
            for a in sorted(list_accounts(), key=_account_priority):
                if alive >= limit:
                    break
                en = a.get("enabled")
                if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
                    continue
                aid = a["id"]
                if is_running(aid):
                    continue
                try:
                    nts = int(a.get("next_ts") or 0)
                except Exception:
                    nts = 0
                # due yoki noma'lum
                if nts > 0 and nts > now + 120:
                    continue
                if not ((a.get("cookie") or "").strip() or (a.get("email") or "").strip()):
                    continue
                if start_account(aid):
                    alive += 1
                    time.sleep(0.4)
    except Exception as e:
        print("[ensure due]", e)


def start_all_enabled(stagger=(1.2, 2.2)) -> None:
    """Birinchi to'lqin: max_bots ta eng muhim hisob. Qolganlari queue (fail emas)."""
    ids_acc = []
    for a in list_accounts():
        en = a.get("enabled")
        if en is None or en == 0 or en is False or str(en).strip() in ("0", "false", "False", ""):
            if (a.get("cookie") or "").strip() or (a.get("email") or "").strip():
                update_account(a["id"], enabled=1)
                ids_acc.append(a)
            continue
        ids_acc.append(a)
    ids_acc.sort(key=_account_priority)
    limit = max_bots_limit()
    print(f"[start_all] {len(ids_acc)} hisob · parallel max {limit}")
    started = 0
    queued = 0
    failed = 0
    for i, a in enumerate(ids_acc):
        aid = a["id"]
        if started >= limit:
            update_account(aid, status="WAIT", last_msg=f"queue {started}/{limit}", health="ok")
            queued += 1
            continue
        ok = start_account(aid)
        if ok:
            started += 1
        else:
            st = (get_account(aid) or {}).get("last_msg") or ""
            if str(st).startswith("queue"):
                queued += 1
            else:
                failed += 1
                print(f"[start_all] fail id={aid} ({st})")
        if i < len(ids_acc) - 1 and started < limit:
            time.sleep(random.uniform(*stagger))
    print(f"[start_all] started={started} queue={queued} fail={failed}")




def remove_account_completely(aid: int) -> dict:
    """Faqat SHU hisob: stop + DB + o'z papkasi. Boshqa hisoblarga TEGMAYDI."""
    from app.db import delete_account as _del
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "not found"}
    folder_name = (acc.get("folder") or "").strip()

    # 1) faqat shu bot
    try:
        stop_account(aid)
    except Exception as e:
        print("[delete stop]", e)

    # 2) faqat shu joblar
    try:
        st = DICE_JOBS.pop(aid, None)
        if st is not None:
            st["stop"] = True
            st["running"] = False
    except Exception:
        pass
    try:
        _dice_threads.pop(aid, None)
    except Exception:
        pass
    try:
        r37 = globals().get("R37_JOBS")
        if isinstance(r37, dict):
            st = r37.pop(aid, None)
            if st is not None:
                st["stop"] = True
                st["running"] = False
    except Exception:
        pass

    # 3) FAQAT shu papka
    removed_path = False
    try:
        if folder_name:
            import shutil
            fp = ACCOUNTS / folder_name
            # path traversal himoya
            try:
                fp.resolve().relative_to(ACCOUNTS.resolve())
            except Exception:
                return {"ok": False, "error": "bad folder path"}
            if fp.is_dir():
                shutil.rmtree(fp, ignore_errors=True)
            removed_path = not fp.exists()
            mark_folder_deleted(folder_name)
    except Exception as e:
        print("[delete folder]", e)

    # 4) DB faqat shu id
    try:
        _del(aid)
    except Exception as e:
        return {"ok": False, "error": str(e), "folder": folder_name}

    try:
        refresh_snapshot(force=True)
    except Exception:
        try:
            refresh_snapshot()
        except Exception:
            pass

    return {"ok": True, "folder": folder_name, "folder_removed": removed_path}


def purge_orphan_account_files(extra_folders=None) -> dict:
    """Faqat blacklist dagi papkalar. Live hisoblarga HECH QACHON tegmaydi."""
    import shutil
    removed = []
    extra_folders = [str(x) for x in (extra_folders or []) if x]
    for x in extra_folders:
        mark_folder_deleted(x)
    deleted = set(_load_deleted_folders())

    # live folderlar himoya
    live = set()
    try:
        for a in list_accounts():
            f = (a.get("folder") or "").strip()
            if f:
                live.add(f)
    except Exception:
        pass

    # blacklist dan live larni olib tashla (xato blacklist)
    for f in list(deleted):
        if f in live:
            deleted.discard(f)
            try:
                unmark_folder_deleted(f)
            except Exception:
                pass

    if not ACCOUNTS.is_dir():
        return {"ok": True, "removed": [], "protected_live": sorted(live)}

    for name in list(deleted):
        if name in live:
            continue
        fp = ACCOUNTS / name
        try:
            fp.resolve().relative_to(ACCOUNTS.resolve())
        except Exception:
            continue
        if fp.is_dir():
            try:
                shutil.rmtree(fp, ignore_errors=True)
                if not fp.exists():
                    removed.append(name)
            except Exception as e:
                print("[purge]", name, e)

    return {"ok": True, "removed": sorted(set(removed)), "protected_live": sorted(live)}


def clear_deleted_blacklist() -> dict:
    """Blacklist ni tozalash — papkalar o'chirilmaydi, faqat qayta import ruxsati."""
    try:
        _save_deleted_folders(set())
        return {"ok": True, "cleared": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def save_accounts_to_db() -> dict:
    """Settings Save accounts: faqat HOZIRGI DB hisoblarni diskka yozish (import YO'Q)."""
    init_db()
    n = 0
    for acc in list_accounts():
        try:
            write_account_files(acc)
            n += 1
        except Exception as e:
            print("[save acc]", acc.get("id"), e)
    try:
        refresh_snapshot(force=True)
    except Exception:
        try:
            refresh_snapshot()
        except Exception:
            pass
    try:
        # force checkpoint
        get_snapshot(max_age=0)
    except Exception:
        pass
    return {"ok": True, "saved": n, "deleted_blacklist": len(_load_deleted_folders())}

def import_existing_folders() -> int:
    """accounts/ → DB (blacklist diskda bor papkalarni bloklamaydi)."""
    r = restore_accounts_from_disk()
    return int(r.get("restored") or 0)



def import_legacy_caps(caps_root: Path) -> int:
    init_db()
    n = 0
    if not caps_root.is_dir():
        return 0
    for d in sorted(caps_root.iterdir()):
        if not d.is_dir() or d.name.startswith("."):
            continue
        platform = None
        for p, meta in PLATFORMS.items():
            if (d / meta["bot"]).is_file() or (d / meta["config"]).is_file():
                platform = p
                break
        if not platform:
            fl = d.name.lower()
            if "tron" in fl:
                platform = "tronpick"
            elif "sui" in fl:
                platform = "suipick"
            elif "doge" in fl:
                platform = "dogepick"
            elif "ltc" in fl or "lite" in fl:
                platform = "litepick"
            else:
                platform = "tonpick"
        if get_account_by_folder(d.name):
            continue
        plat = PLATFORMS[platform]
        cfg: dict = {}
        cp = d / plat["config"]
        if cp.is_file():
            try:
                cfg = json.loads(cp.read_text(encoding="utf-8"))
            except Exception:
                pass
        cookie = ""
        cfile = d / plat["cookie"]
        if cfile.is_file():
            cookie = cfile.read_text(encoding="utf-8").strip().splitlines()[0].strip()
        elif cfg.get("cookie"):
            cookie = str(cfg["cookie"]).strip()
        dest = ACCOUNTS / d.name
        if not dest.exists():
            shutil.copytree(
                d,
                dest,
                ignore=shutil.ignore_patterns(
                    "bot_live.log", "__pycache__", "*.pyc"
                ),
            )
        src_bot = BOTS / plat["bot"]
        if src_bot.is_file():
            shutil.copy2(src_bot, dest / plat["bot"])
        aid = add_account(
            folder=d.name,
            platform=platform,
            coin=plat["coin"],
            label=d.name,
            email=cfg.get("email") or "",
            password=cfg.get("password") or "",
            cookie=cookie,
            wallet=cfg.get("wallet") or "",
            user_agent=cfg.get("user_agent") or random.choice(UA_POOL),
        )
        write_account_files(get_account(aid))
        n += 1
    return n


def make_backup() -> Path:
    import zipfile
    from datetime import datetime

    bak_dir = DATA / "backups"
    bak_dir.mkdir(exist_ok=True)
    name = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
    path = bak_dir / name
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        if (DATA / "caps.db").is_file():
            z.write(DATA / "caps.db", "caps.db")
        if (DATA / "ic_shared.db").is_file():
            z.write(DATA / "ic_shared.db", "ic_shared.db")
        for f in ACCOUNTS.rglob("*"):
            if f.is_file() and f.suffix not in (".pyc",) and "bot_live.log" not in f.name:
                z.write(f, f"accounts/{f.relative_to(ACCOUNTS)}")
    baks = sorted(
        bak_dir.glob("backup_*.zip"),
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    for old in baks[10:]:
        try:
            old.unlink()
        except Exception:
            pass
    add_alert("info", "Backup created", name)
    return path



UA_POOL_BIG = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:120.0) Gecko/20100101 Firefox/120.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-S918B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 12; SM-G991B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; M2101K7AG) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36 Edg/121.0.0.0",
    "Mozilla/5.0 (Windows NT 11.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
]

def pick_unique_ua(platform: str, preferred: str = "") -> str:
    """Bir xil valyutada bir xil UA takrorlanmasin."""
    used = set()
    for a in list_accounts():
        if (a.get("platform") or "") == platform:
            u = (a.get("user_agent") or "").strip()
            if u:
                used.add(u)
    if preferred and preferred not in used:
        return preferred
    for ua in UA_POOL_BIG:
        if ua not in used:
            return ua
    # generate unique
    import random
    base = random.choice(UA_POOL_BIG)
    return base + f" CAPS/{random.randint(1000,9999)}"


def ensure_unique_uas() -> int:
    """Worker: bir xil platformda takror UA ni almashtiradi."""
    fixed = 0
    by_plat = {}
    for a in list_accounts():
        plat = a.get("platform") or ""
        by_plat.setdefault(plat, []).append(a)
    for plat, rows in by_plat.items():
        seen = set()
        for a in rows:
            ua = (a.get("user_agent") or "").strip()
            if not ua or ua in seen:
                new_ua = pick_unique_ua(plat, "")
                # avoid collision with just assigned
                while new_ua in seen:
                    new_ua = pick_unique_ua(plat, "") + f"/{int(time.time())%9999}"
                update_account(a["id"], user_agent=new_ua)
                try:
                    write_account_files(get_account(a["id"]))
                except Exception:
                    pass
                seen.add(new_ua)
                fixed += 1
            else:
                seen.add(ua)
    return fixed


def get_prices(force: bool = False) -> dict:
    """Narxlar: cache (1 soat) + doimiy o'rtacha fallback. Hech qachon bo'sh qaytmasin."""
    import json
    FALLBACK = {
        "TON": 5.50,
        "TRX": 0.25,
        "SUI": 3.80,
        "DOGE": 0.35,
        "LTC": 95.0,
        "SOL": 180.0,
    }
    cache = ROOT / "data" / "prices_cache.json"
    now = time.time()
    cached_prices = {}
    cached_change = {}
    cache_age = 1e18
    try:
        if cache.is_file():
            j = json.loads(cache.read_text(encoding="utf-8"))
            cached_prices = dict(j.get("prices") or {})
            cached_change = dict(j.get("change_24h") or {})
            cache_age = now - float(j.get("ts") or 0)
            # 1 soat ichida — cache yetarli (force bo'lmasa)
            if not force and cache_age < 3600 and len(cached_prices) >= 3:
                out = dict(FALLBACK)
                out.update(cached_prices)
                return out
    except Exception:
        pass

    ids = {
        "TON": "the-open-network",
        "TRX": "tron",
        "SUI": "sui",
        "DOGE": "dogecoin",
        "LTC": "litecoin",
        "SOL": "solana",
    }
    prices = {}
    change = {}
    try:
        import requests
        q = ",".join(ids.values())
        r = requests.get(
            f"https://api.coingecko.com/api/v3/simple/price?ids={q}&vs_currencies=usd&include_24hr_change=true",
            timeout=2.5,
        )
        data = r.json() if r.ok else {}
        for coin, gid in ids.items():
            if gid in data and "usd" in data[gid]:
                prices[coin] = float(data[gid]["usd"])
            if gid in data and data[gid].get("usd_24h_change") is not None:
                try:
                    change[coin] = float(data[gid]["usd_24h_change"])
                except Exception:
                    pass
        if prices:
            cache.parent.mkdir(parents=True, exist_ok=True)
            # old change saqlansin agar yangi bo'sh
            if not change and cached_change:
                change = cached_change
            cache.write_text(
                json.dumps({"ts": now, "prices": prices, "change_24h": change}),
                encoding="utf-8",
            )
            cached_prices = prices
            cached_change = change
    except Exception as e:
        print("[prices]", e)

    out = dict(FALLBACK)
    out.update(cached_prices)
    return out




def refresh_snapshot() -> dict:
    """Tez API uchun xotira + disk checkpoint."""
    global _SNAPSHOT
    try:
        prices = {}
        change = {}
        try:
            prices = get_prices() or {}
        except Exception:
            prices = {}
        try:
            import json as _json
            if CHECKPOINT_PATH.parent.exists():
                pass
            pcache = ROOT / "data" / "prices_cache.json"
            if pcache.is_file():
                jj = _json.loads(pcache.read_text(encoding="utf-8"))
                if not prices:
                    prices = jj.get("prices") or {}
                change = jj.get("change_24h") or {}
        except Exception:
            pass

        rows = []
        totals = {}
        claims = 0
        online = 0
        wait = 0
        for a in list_accounts():
            d = dict(a)
            d["username"] = d.get("label") or d.get("folder") or ""
            d.pop("password", None)
            has_c = bool((d.get("cookie") or "").strip())
            d["has_cookie"] = has_c
            d["cookie"] = has_c
            coin = d.get("coin") or ""
            bal = d.get("balance")
            try:
                d["usd"] = float(bal) * float(prices.get(coin) or 0) if bal is not None else None
            except Exception:
                d["usd"] = None
            rows.append(d)
            if bal is not None:
                totals[coin] = totals.get(coin, 0.0) + float(bal or 0)
            claims += int(d.get("claims_today") or 0)
            st = (d.get("status") or "").upper()
            if st in ("RUN", "OK", "CAP", "WAIT", "WARN"):
                online += 1
            if "WAIT" in st:
                wait += 1

        usd_total = 0.0
        usd_by = {}
        for c, v in totals.items():
            if c in prices:
                u = float(v) * float(prices[c])
                usd_by[c] = round(u, 4)
                usd_total += u

        stats = {
            "total": len(rows),
            "total_accounts": len(rows),
            "online": online,
            "waiting": wait,
            "claims_today": claims,
            "totals": {k: round(v, 6) for k, v in totals.items()},
            "prices_usd": prices,
            "price_change": change,
            "usd_by_coin": usd_by,
            "usd_total": round(usd_total, 4),
        }
        snap = {
            "ts": int(time.time()),
            "accounts": rows,
            "prices_usd": prices,
            "price_change": change,
            "stats": stats,
            "count": len(rows),
        }
        with _SNAP_LOCK:
            _SNAPSHOT = snap
        try:
            CHECKPOINT_PATH.parent.mkdir(parents=True, exist_ok=True)
            # disk: faqat yengil meta (katta cookie yo'q)
            light = {
                "ts": snap["ts"],
                "stats": stats,
                "prices_usd": prices,
                "price_change": change,
                "accounts": [
                    {
                        "id": r["id"],
                        "folder": r.get("folder"),
                        "platform": r.get("platform"),
                        "coin": r.get("coin"),
                        "username": r.get("username"),
                        "label": r.get("label"),
                        "email": r.get("email"),
                        "balance": r.get("balance"),
                        "usd": r.get("usd"),
                        "status": r.get("status"),
                        "last_msg": r.get("last_msg"),
                        "claims_today": r.get("claims_today"),
                        "claims_left": r.get("claims_left"),
                        "stamina_pct": r.get("stamina_pct"),
                        "wager_pct": r.get("wager_pct"),
                        "level": r.get("level"),
                        "health": r.get("health"),
                        "has_cookie": r.get("has_cookie"),
                        "wallet": r.get("wallet"),
                        "last_seen_ts": r.get("last_seen_ts"),
                        "next_ts": r.get("next_ts"),
                        "wait_sec": r.get("wait_sec"),
                        "level": r.get("level"),
                    }
                    for r in rows
                ],
                "count": len(rows),
            }
            _cp = __import__("json").dumps(light, ensure_ascii=False)
            _tmp = CHECKPOINT_PATH.with_suffix(".tmp")
            _tmp.write_text(_cp, encoding="utf-8")
            _tmp.replace(CHECKPOINT_PATH)
        except Exception:
            pass
        return snap
    except Exception as e:
        print("[snapshot]", e)
        with _SNAP_LOCK:
            return dict(_SNAPSHOT)


def get_snapshot(max_age: float = 3.0) -> dict:
    """Xotira / checkpoint / DB — tarmoq kutmaydi."""
    with _SNAP_LOCK:
        snap = dict(_SNAPSHOT) if _SNAPSHOT else {}
    age = time.time() - float(snap.get("ts") or 0)
    if snap.get("accounts") is not None and age <= max_age and snap.get("ts"):
        return snap
    try:
        if CHECKPOINT_PATH.is_file():
            import json as _json
            j = _json.loads(CHECKPOINT_PATH.read_text(encoding="utf-8"))
            if isinstance(j, dict) and j.get("accounts") is not None:
                cp_age = time.time() - float(j.get("ts") or 0)
                with _SNAP_LOCK:
                    if not _SNAPSHOT.get("ts") or float(j.get("ts") or 0) >= float(_SNAPSHOT.get("ts") or 0):
                        _SNAPSHOT.update(j)
                        snap = dict(_SNAPSHOT)
                    else:
                        snap = dict(j)
                if cp_age <= max(max_age, 90) and snap.get("accounts") is not None:
                    return snap
    except Exception:
        pass
    return refresh_snapshot()


def restore_accounts_from_disk(force: bool = False) -> dict:
    """accounts/ papkalaridan DB ni tiklash.
    Blacklist faqat papka YO'Q bo'lsa ishlaydi — diskda bor papka qayta import qilinadi.
    """
    init_db()
    restored = 0
    skipped = 0
    unblocked = []
    deleted = set(_load_deleted_folders())

    # diskda hali bor papkalarni blacklist dan olib tashlash (xato o'chirish)
    if ACCOUNTS.is_dir():
        for name in list(deleted):
            if (ACCOUNTS / name).is_dir():
                deleted.discard(name)
                try:
                    unmark_folder_deleted(name)
                    unblocked.append(name)
                except Exception:
                    pass
        if unblocked:
            print("[restore] blacklist dan ochildi:", len(unblocked), "papka")

    if not ACCOUNTS.is_dir():
        return {"ok": True, "restored": 0, "skipped": 0, "unblocked": unblocked}

    for d in sorted(ACCOUNTS.iterdir()):
        if not d.is_dir() or d.name.startswith("."):
            continue
        name = d.name
        # faqat haqiqatan o'chirilgan (papka yo'q) — skip
        if name in deleted and not d.exists():
            skipped += 1
            continue
        try:
            existing = get_account_by_folder(name)
            # config / cookie o'qish
            cfg = {}
            for fn in ("config.json", "config_tonpick.json", "config_tronpick.json", "account.json"):
                fp = d / fn
                if fp.is_file():
                    try:
                        import json as _json
                        cfg = _json.loads(fp.read_text(encoding="utf-8"))
                        if isinstance(cfg, dict):
                            break
                    except Exception:
                        cfg = {}
            # nested accounts[0]
            if isinstance(cfg.get("accounts"), list) and cfg["accounts"]:
                cfg0 = cfg["accounts"][0] if isinstance(cfg["accounts"][0], dict) else {}
            else:
                cfg0 = cfg if isinstance(cfg, dict) else {}

            cookie = (cfg0.get("cookie") or cfg.get("cookie") or "").strip()
            # cookie_*.txt
            if not cookie:
                for cf in d.glob("cookie*.txt"):
                    try:
                        cookie = cf.read_text(encoding="utf-8").strip()
                        if cookie:
                            break
                    except Exception:
                        pass
            email = (cfg0.get("email") or cfg.get("email") or "").strip()
            password = (cfg0.get("password") or cfg.get("password") or "").strip()
            label = (cfg0.get("label") or cfg0.get("username") or cfg.get("label") or name)
            ua = (cfg0.get("user_agent") or cfg.get("user_agent") or "").strip()
            wallet = (cfg0.get("wallet") or cfg.get("wallet") or "").strip()

            # platform/coin from folder prefix
            low = name.lower()
            if low.startswith("trx") or "tron" in low:
                platform, coin = "tronpick", "TRX"
            elif low.startswith("ton") or "ton" in low:
                platform, coin = "tonpick", "TON"
            elif low.startswith("sui"):
                platform, coin = "suipick", "SUI"
            elif low.startswith("doge"):
                platform, coin = "dogepick", "DOGE"
            elif low.startswith("ltc") or "lite" in low:
                platform, coin = "litepick", "LTC"
            elif low.startswith("sol"):
                platform, coin = "solpick", "SOL"
            else:
                platform = (cfg0.get("platform") or cfg.get("platform") or "tronpick")
                coin = (cfg0.get("coin") or cfg.get("coin") or "TRX")

            if existing:
                # yangilash — cookie/email yo'qolgan bo'lsa to'ldirish
                patch = {"enabled": 1}
                if cookie and not (existing.get("cookie") or "").strip():
                    patch["cookie"] = cookie
                elif cookie and len(cookie) > len(existing.get("cookie") or ""):
                    patch["cookie"] = cookie
                if email and not (existing.get("email") or "").strip():
                    patch["email"] = email
                if password and not (existing.get("password") or "").strip():
                    patch["password"] = password
                if ua and not (existing.get("user_agent") or "").strip():
                    patch["user_agent"] = ua
                if wallet and not (existing.get("wallet") or "").strip():
                    patch["wallet"] = wallet
                if label and (not existing.get("label") or existing.get("label") == existing.get("folder")):
                    patch["label"] = label
                try:
                    update_account(existing["id"], **patch)
                    restored += 1
                except Exception as e:
                    print("[restore update]", name, e)
            else:
                try:
                    add_account(
                        folder=name,
                        platform=platform,
                        coin=coin,
                        label=label,
                        email=email,
                        password=password,
                        cookie=cookie,
                        wallet=wallet,
                        user_agent=ua or "Mozilla/5.0",
                    )
                    restored += 1
                    print("[restore] +", name, platform, coin)
                except Exception as e:
                    print("[restore add]", name, e)
                    skipped += 1
        except Exception as e:
            print("[restore]", name, e)
            skipped += 1

    try:
        refresh_snapshot(force=True)
    except Exception:
        try:
            refresh_snapshot()
        except Exception:
            pass
    n = len(list_accounts())
    print(f"[restore] DB={n} restored/updated={restored} skipped={skipped}")
    return {"ok": True, "restored": restored, "skipped": skipped, "db_total": n, "unblocked": unblocked}


def load_checkpoint_on_boot() -> None:
    # 1) checkpoint xotiraga
    try:
        if CHECKPOINT_PATH.is_file():
            import json as _json
            j = _json.loads(CHECKPOINT_PATH.read_text(encoding="utf-8"))
            if isinstance(j, dict):
                with _SNAP_LOCK:
                    _SNAPSHOT.update(j)
                print("[checkpoint] loaded", j.get("count"), "acc · ts", j.get("ts"))
    except Exception as e:
        print("[checkpoint]", e)
    # 2) DB bo'sh yoki kam — accounts/ dan tiklash
    try:
        n = len(list_accounts())
        disk_n = 0
        if ACCOUNTS.is_dir():
            disk_n = sum(1 for d in ACCOUNTS.iterdir() if d.is_dir() and not d.name.startswith("."))
        if n == 0 or (disk_n > 0 and n < disk_n):
            print(f"[boot] DB={n} disk_folders={disk_n} → restore")
            restore_accounts_from_disk()
        else:
            print(f"[boot] DB={n} disk_folders={disk_n} OK")
    except Exception as e:
        print("[boot restore]", e)




def withdraw_info(aid: int) -> dict:
    """Saytdan min withdraw + balance (tez, bot CLI yo'q)."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    plat = PLATFORMS.get(acc["platform"]) or {}
    coin = (acc.get("coin") or plat.get("coin") or "").upper()
    wallet = (acc.get("withdraw_wallet") or acc.get("wallet") or "").strip()
    # wallet may be deposit — faqat withdraw_wallet ishlatiladi tavsiya uchun
    bal = float(acc.get("balance") or 0)
    # platform default mins (fallback)
    DEFAULT_MIN = {
        "TRX": 7.5, "TON": 0.1, "SUI": 0.1, "SOL": 0.01,
        "DOGE": 10, "LTC": 0.001, "POL": 1,
    }
    min_w = float(DEFAULT_MIN.get(coin, 0.1))
    try:
        s = _acc_session(acc)
        host = _host_for(acc)
        r = s.get(host + "withdraw.php", timeout=22, allow_redirects=True)
        html = r.text or ""
        if "login.php" in (r.url or ""):
            # try login if credentials
            email = (acc.get("email") or "").strip()
            password = (acc.get("password") or "").strip()
            if email and password:
                try:
                    login_account_session(acc)  # may not exist
                except Exception:
                    pass
                r = s.get(host + "withdraw.php", timeout=22)
                html = r.text or ""
        # min patterns
        for pat in (
            r"minimum_withdrawal\s*=\s*parseFloat\(\s*([0-9.]+)\s*\)",
            r"Minimum withdrawal amount:\s*<b>\s*([0-9.]+)",
            r"Minimum withdrawal[^0-9]{0,40}([0-9]+\.[0-9]+)",
            r"min(?:imum)?[_\s-]*withdraw[^0-9]{0,40}([0-9]+\.[0-9]+)",
            r"MIN_WITHDRAW[^0-9]*([0-9.]+)",
        ):
            mm = re.search(pat, html, re.I)
            if mm:
                try:
                    min_w = float(mm.group(1))
                    break
                except Exception:
                    pass
        # balance from page
        for pat in (
            r"user_balance\s*=\s*([0-9.]+)",
            r'id=["\']user_balance["\'][^>]*>([0-9.]+)',
            r"Your balance[^0-9]{0,20}([0-9]+\.[0-9]+)",
        ):
            mm = re.search(pat, html, re.I)
            if mm:
                try:
                    bal = float(mm.group(1))
                    break
                except Exception:
                    pass
        # saved wallet on page
        for pat in (
            r'id=["\']withdraw(?:al)?_address["\'][^>]*value=["\']([^"\']+)',
            r'name=["\']address["\'][^>]*value=["\']([^"\']+)',
        ):
            mm = re.search(pat, html, re.I)
            if mm and len(mm.group(1)) > 10:
                wallet = mm.group(1).strip()
                break
        try:
            update_account(aid, balance=bal)
        except Exception:
            pass
        return {
            "ok": True,
            "balance": bal,
            "min": min_w,
            "min_withdraw": min_w,
            "wallet": wallet,
            "address": wallet,
            "withdraw_wallet": wallet,
            "deposit_address": (acc.get("deposit_address") or "").strip(),
            "coin": coin or acc.get("coin"),
            "account_id": aid,
        }
    except Exception as e:
        return {
            "ok": True,
            "balance": bal,
            "min": min_w,
            "min_withdraw": min_w,
            "wallet": wallet,
            "coin": coin or acc.get("coin"),
            "account_id": aid,
            "error_hint": str(e)[:120],
        }



def withdraw_do(aid: int, amount: float, address: str = "", tag: str = "") -> dict:
    """Captcha + withdraw (bot CLI)."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    plat = PLATFORMS.get(acc["platform"])
    if not plat:
        return {"ok": False, "error": "platform"}
    address = (address or acc.get("wallet") or "").strip()
    if len(address) < 10:
        return {"ok": False, "error": "wallet/address kerak"}
    # save WITHDRAW address (depozit manzil emas)
    try:
        update_account(aid, withdraw_wallet=address)
        acc = get_account(aid)
    except Exception:
        pass
    folder = write_account_files(acc)
    script = folder / plat["bot"]
    if not script.is_file():
        src = BOTS / plat["bot"]
        if src.is_file():
            shutil.copy2(src, script)
    env = os.environ.copy()
    env["PYTHONUNBUFFERED"] = "1"
    env["IC_DB"] = str(DATA / "ic_shared.db")
    try:
        import subprocess
        r = subprocess.run(
            [
                sys.executable, "-u", str(script),
                "--withdraw", str(amount),
                "--address", address,
                "--tag", tag or "",
            ],
            cwd=str(folder),
            capture_output=True,
            text=True,
            timeout=180,
            env=env,
        )
        out = (r.stdout or "").strip().splitlines()
        for line in reversed(out):
            line = line.strip()
            if line.startswith("{") and ("ok" in line or "error" in line):
                try:
                    j = json.loads(line)
                    if j.get("ok"):
                        add_claim_log(aid, "Withdraw", f"-{amount}", "accepted", j.get("mes") or "")
                        add_alert("info", f"Withdraw {acc.get('label')}", f"{amount} {acc.get('coin')}", aid)
                    return j
                except Exception:
                    pass
        return {"ok": False, "error": (r.stderr or r.stdout or "no response")[-300:]}
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ═══════════════════════════════════════════════════════════
# Deposit / Level / Register / Roulette-37  (site integration)
# ═══════════════════════════════════════════════════════════

LEVELS_DEFAULT = [
    {"name": "Stone", "target": 0.1},
    {"name": "Iron", "target": 1},
    {"name": "Bronze", "target": 10},
    {"name": "Silver", "target": 100},
    {"name": "Gold", "target": 1000},
    {"name": "Platinum", "target": 10000},
    {"name": "Diamond", "target": 100000},
    {"name": "Master", "target": 1000000},
]

# nano-units (1 coin = 1e9) — sayt chip_type bilan mos
# chip index i → 100 * 10^i micro (balance*1e6). 0=0.0001 … 3=0.1 … 6=100 coin
ROULETTE_CHIPS_NANO = [100 * (10 ** i) for i in range(7)]

ROULETTE_JOBS: dict[int, dict] = {}  # aid -> status dict
_roulette_threads: dict[int, object] = {}
DICE_JOBS: dict[int, dict] = {}
_dice_threads: dict[int, object] = {}



def _disk_cookie_path(acc: dict) -> Path | None:
    try:
        plat = PLATFORMS.get(acc.get("platform") or "") or {}
        folder = ACCOUNTS / (acc.get("folder") or "")
        name = plat.get("cookie") or "cookie.txt"
        p = folder / name
        return p if p.is_file() else None
    except Exception:
        return None


def sync_cookie_from_disk(acc: dict) -> str:
    """Bot yozgan cookie_*.txt ni DB dan ustun qo'yish (yangi sessiya)."""
    if not acc:
        return (acc or {}).get("cookie") or ""
    disk = ""
    p = _disk_cookie_path(acc)
    try:
        if p and p.is_file():
            disk = (p.read_text(encoding="utf-8", errors="ignore") or "").strip()
            # faqat birinchi qator
            disk = disk.splitlines()[0].strip() if disk else ""
    except Exception:
        disk = ""
    db = (acc.get("cookie") or "").strip()
    # disk yaxshiroq bo'lsa (user_session/remember) — o'zlashtirish
    def score(c: str) -> int:
        if not c:
            return 0
        s = 0
        if "user_session=" in c:
            s += 5
        if "remember_token=" in c:
            s += 3
        if "adbit_session=" in c:
            s += 2
        if "csrf_cookie_name=" in c:
            s += 1
        s += min(len(c) // 40, 5)
        return s
    best = disk if score(disk) >= score(db) and score(disk) > 0 else db
    if disk and score(disk) > score(db):
        try:
            aid = acc.get("id")
            if aid:
                update_account(aid, cookie=disk)
                acc["cookie"] = disk
                try:
                    write_account_files(get_account(aid) or acc)
                except Exception:
                    pass
            else:
                acc["cookie"] = disk
        except Exception:
            acc["cookie"] = disk
        return disk
    # merge disk+db keys
    if disk and db and disk != db:
        merged = _merge_cookie_strings(db, disk)
        if score(merged) > score(db):
            try:
                aid = acc.get("id")
                if aid:
                    update_account(aid, cookie=merged)
                acc["cookie"] = merged
            except Exception:
                acc["cookie"] = merged
            return merged
    return best or db or disk


def _acc_session(acc: dict):
    """requests.Session — Cookie header + jar (path=/)."""
    import requests
    from urllib.parse import urlparse
    s = requests.Session()
    ua = acc.get("user_agent") or random.choice(UA_POOL)
    host = PLATFORMS.get(acc.get("platform") or "", {}).get("host", "") or ""
    domain = ""
    try:
        domain = urlparse(host).hostname or ""
    except Exception:
        domain = ""
    s.headers.update({
        "User-Agent": ua,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
        "Referer": host if host.endswith("/") else (host + "/" if host else ""),
    })
    cookie = (acc.get("cookie") or "").strip()
    if cookie:
        parts = []
        for part in cookie.split(";"):
            part = part.strip()
            if "=" not in part:
                continue
            k, v = part.split("=", 1)
            k, v = k.strip(), v.strip()
            if not k:
                continue
            parts.append("%s=%s" % (k, v))
            try:
                s.cookies.set(k, v, domain=domain or None, path="/")
            except Exception:
                try:
                    s.cookies.set(k, v, path="/")
                except Exception:
                    pass
        if parts:
            s.headers["Cookie"] = "; ".join(parts)
    return s



def _host_for(acc: dict) -> str:
    p = PLATFORMS.get(acc.get("platform") or "", {})
    return (p.get("host") or "https://tonpick.game/").rstrip("/") + "/"


def _parse_csrf(html: str, sess=None) -> str:
    html = html or ""
    m = re.search(r'name=["\']csrf_test_name["\'][^>]*value=["\']([^"\']+)', html)
    if not m:
        m = re.search(r"value=([a-f0-9]{20,})", html)
    if m:
        return m.group(1)
    if sess is not None:
        try:
            vals = [c.value for c in list(sess.cookies) if getattr(c, "name", None) == "csrf_cookie_name"]
            if vals:
                return vals[-1]
        except Exception:
            pass
    m = re.search(r"csrf_cookie_name=([a-zA-Z0-9]+)", html)
    return m.group(1) if m else ""


def _parse_deposit_address(html: str) -> str:
    """Deposit manzil — textarea + T/UQ/0x pattern (bo'sh joylarga chidamli)."""
    if not html:
        return ""
    for pat in (
        r'<textarea[^>]*id=["\']deposit_address["\'][^>]*>(.*?)</textarea>',
        r'<textarea[^>]*name=["\']deposit_address["\'][^>]*>(.*?)</textarea>',
        r'id=["\']deposit_address["\'][^>]*>([^<]{15,120})<',
        r'id=["\']deposit_address["\'][^>]*value=["\']([^"\']+)',
        r'name=["\']deposit_address["\'][^>]*value=["\']([^"\']+)',
        r'data-address=["\']([^"\']{20,})["\']',
        r'makeCode\(\s*["\']([^"\']{20,})["\']',
    ):
        mm = re.search(pat, html, re.I | re.S)
        if mm:
            val = re.sub(r"\s+", "", (mm.group(1) or "").strip())
            if len(val) >= 20 and "function" not in val.lower():
                return val
    mm = re.search(r"\b(T[1-9A-HJ-NP-Za-km-z]{33})\b", html)
    if mm:
        return mm.group(1)
    mm = re.search(r"\b((?:UQ|EQ)[A-Za-z0-9_\-]{46,48})\b", html)
    if mm:
        return mm.group(1)
    mm = re.search(r"\b(0x[a-fA-F0-9]{40})\b", html)
    if mm:
        return mm.group(1)
    return ""



def _login_session_for_deposit(acc: dict, s, host: str) -> bool:
    """Email+parol+IconCaptcha → login. Cookie to'liq saqlanadi. Yangi session ishlatiladi."""
    email = (acc.get("email") or "").strip()
    password = (acc.get("password") or "").strip()
    if not email or not password:
        return False
    import requests
    from urllib.parse import urlparse
    try:
        # eski cookie chalkashtirmasin — toza sessiya
        s2 = requests.Session()
        ua = acc.get("user_agent") or random.choice(UA_POOL)
        s2.headers.update({
            "User-Agent": ua,
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Referer": host + "login.php",
        })
        page = s2.get(host + "login.php", timeout=30)
        html = page.text or ""
        csrf = _parse_csrf(html, s2)
        ic = None
        for attempt in range(3):
            try:
                ic = _solve_icon_http(s2, host, html, host + "login.php")
            except Exception as e:
                print("[login IC]", e)
                ic = None
            if not ic:
                # yangi login sahifa
                try:
                    page = s2.get(host + "login.php", timeout=25)
                    html = page.text or ""
                    csrf = _parse_csrf(html, s2)
                except Exception:
                    pass
                continue
            data = {
                "action": "login",
                "email": email,
                "password": password,
                "captcha_type": "0",
                "g-recaptcha-response": "",
                "h-captcha-response": "",
                "c_captcha_response": "",
                "pcaptcha_token": "",
                "agree": "1",
                "_iconcaptcha-token": ic.get("_iconcaptcha-token", ""),
                "ic-rq": ic.get("ic-rq", "1"),
                "ic-wid": ic.get("ic-wid", ""),
                "ic-cid": ic.get("ic-cid", ""),
                "ic-hp": ic.get("ic-hp", ""),
            }
            if csrf:
                data["csrf_test_name"] = csrf
            r = s2.post(
                host + "process.php",
                data=data,
                timeout=45,
                headers={
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": host + "login.php",
                    "Origin": host.rstrip("/"),
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                },
            )
            txt = (r.text or "").strip()
            try:
                obj = r.json()
            except Exception:
                try:
                    obj = json.loads(txt)
                except Exception:
                    obj = {}
            ok = False
            if isinstance(obj, dict):
                try:
                    if int(obj.get("ret") or 0) == 1:
                        ok = True
                except Exception:
                    pass
                if obj.get("ret") in (1, "1", True):
                    ok = True
                mes = str(obj.get("mes") or obj.get("message") or "").lower()
                if "success" in mes or "logged" in mes:
                    ok = True
                if "invalid captcha" in mes or "captcha" in mes and "invalid" in mes:
                    ok = False
                    # yangi challenge
                    try:
                        page = s2.get(host + "login.php", timeout=20)
                        html = page.text or ""
                        csrf = _parse_csrf(html, s2)
                    except Exception:
                        pass
                    continue
                if "password" in mes or "incorrect" in mes or "wrong" in mes:
                    print("[login] bad credentials:", mes)
                    return False
            if not ok:
                continue
            # muvaffaqiyat — sahifalar + cookie
            for path in ("faucet.php", "deposit.php", "account.php"):
                try:
                    s2.get(host + path, timeout=22, allow_redirects=True)
                except Exception:
                    pass
            jar = {}
            for c in s2.cookies:
                jar[c.name] = c.value
            # Cookie header dan ham
            ch = s2.headers.get("Cookie") or ""
            for part in ch.split(";"):
                part = part.strip()
                if "=" in part:
                    k, v = part.split("=", 1)
                    jar.setdefault(k.strip(), v.strip())
            prefer = ["fp", "user_session", "adbit_session", "remember_token", "csrf_cookie_name", "cf_clearance", "g_state"]
            parts, seen = [], set()
            for k in prefer:
                if k in jar and jar[k]:
                    parts.append("%s=%s" % (k, jar[k]))
                    seen.add(k)
            for k, v in jar.items():
                if k not in seen and v:
                    parts.append("%s=%s" % (k, v))
            cookie = "; ".join(parts)
            if "user_session=" not in cookie and "remember_token=" not in cookie and "adbit_session=" not in cookie:
                # login ret=1 lekin cookie yo'q — yana faucet
                try:
                    s2.get(host + "faucet.php", timeout=20)
                    for c in s2.cookies:
                        jar[c.name] = c.value
                    parts = ["%s=%s" % (k, jar[k]) for k in jar]
                    cookie = "; ".join(parts)
                except Exception:
                    pass
            if cookie:
                try:
                    update_account(acc["id"], cookie=cookie)
                    a2 = get_account(acc["id"])
                    if a2:
                        write_account_files(a2)
                    acc["cookie"] = cookie
                except Exception:
                    pass
                # chaqiruvchi session ni yangilash
                try:
                    s.headers["Cookie"] = cookie
                    s.cookies.clear()
                    dom = urlparse(host).hostname or ""
                    for part in cookie.split(";"):
                        part = part.strip()
                        if "=" not in part:
                            continue
                        k, v = part.split("=", 1)
                        try:
                            s.cookies.set(k.strip(), v.strip(), domain=dom, path="/")
                        except Exception:
                            try:
                                s.cookies.set(k.strip(), v.strip(), path="/")
                            except Exception:
                                pass
                    # cookie jar s2 dan ko'chir
                    for c in s2.cookies:
                        try:
                            s.cookies.set(c.name, c.value, domain=c.domain, path=c.path or "/")
                        except Exception:
                            pass
                except Exception:
                    pass
                return True
        return False
    except Exception as e:
        print("[login]", e)
        return False



def _parse_level(html: str) -> dict:
    """Saytdan level + wager. Avvalo 'Your level is X'."""
    import html as H
    levels = list(LEVELS_DEFAULT)
    mlev = re.search(r'data-levels="([^"]+)"', html or "")
    if mlev:
        try:
            levels = json.loads(H.unescape(mlev.group(1)))
        except Exception:
            pass

    LEVEL_RE = r"(Stone|Iron|Wood|Copper|Bronze|Silver|Gold|Platinum|Diamond|Master|Newbie|Beginner)"
    name = None
    idx = None
    wager_amt = None
    target_amt = None
    pct = None

    mm = re.search(
        r"Your\s+level\s+is\s*(?:<[^>]+>\s*)*" + LEVEL_RE,
        html or "",
        re.I,
    )
    if mm:
        name = mm.group(1).title()

    if not name:
        mm = re.search(
            r"Wager\s*Progress[\s\S]{0,500}?" + LEVEL_RE + r"\s*[→\->]+\s*" + LEVEL_RE,
            html or "",
            re.I,
        )
        if mm:
            name = mm.group(1).title()

    if not name:
        arrows = list(re.finditer(LEVEL_RE + r"\s*[→\->]+\s*" + LEVEL_RE, html or "", re.I))
        if arrows:
            name = arrows[-1].group(1).title()

    if name:
        for i, lv in enumerate(levels):
            if str(lv.get("name", "")).lower() == name.lower():
                idx = i
                break
        if idx is None:
            order = ["Stone", "Iron", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Master"]
            for i, n in enumerate(order):
                if n.lower() == name.lower():
                    idx = i
                    break

    wctx = re.search(r"Wager\s*Progress[\s\S]{0,900}", html or "", re.I)
    block = wctx.group(0) if wctx else (html or "")
    wm = re.search(r"Wagered[^0-9]{0,40}([0-9]+(?:\.[0-9]+)?)", block, re.I)
    tm = re.search(r"Target[^0-9]{0,40}([0-9]+(?:\.[0-9]+)?)", block, re.I)
    if wm:
        try:
            wager_amt = float(wm.group(1))
        except Exception:
            pass
    if tm:
        try:
            target_amt = float(tm.group(1))
        except Exception:
            pass
    if wager_amt is not None and target_amt and target_amt > 0:
        pct = max(0.0, min(100.0, (wager_amt / target_amt) * 100.0))

    next_name = None
    if name:
        order = [str(x.get("name")) for x in levels] if levels else [
            "Stone", "Iron", "Bronze", "Silver", "Gold", "Platinum", "Diamond", "Master"
        ]
        try:
            i = next(i for i, n in enumerate(order) if str(n).lower() == name.lower())
            if i + 1 < len(order):
                next_name = order[i + 1]
        except StopIteration:
            pass
        if not next_name:
            mm = re.search(re.escape(name) + r"\s*[→\->]+\s*" + LEVEL_RE, html or "", re.I)
            if mm:
                next_name = mm.group(1).title()

    return {
        "level": name or "—",
        "level_index": idx,
        "wager": pct,
        "wager_amount": wager_amt,
        "target_amount": target_amt,
        "levels": levels,
        "next": next_name,
    }



def _session_cookie_string(sess) -> str:
    try:
        jar = {}
        for c in sess.cookies:
            jar[c.name] = c.value
        if not jar:
            return ""
        prefer = ["fp", "user_session", "adbit_session", "remember_token", "csrf_cookie_name", "cf_clearance", "g_state"]
        parts, seen = [], set()
        for k in prefer:
            if k in jar:
                parts.append("%s=%s" % (k, jar[k]))
                seen.add(k)
        for k, v in jar.items():
            if k not in seen:
                parts.append("%s=%s" % (k, v))
        return "; ".join(parts)
    except Exception:
        return ""


def _merge_cookie_strings(old: str, new: str) -> str:
    d = {}
    for src in (old or "", new or ""):
        for part in src.split(";"):
            part = part.strip()
            if "=" not in part:
                continue
            k, v = part.split("=", 1)
            k, v = k.strip(), v.strip()
            if k:
                d[k] = v
    if not d:
        return (new or old or "").strip()
    prefer = ["fp", "user_session", "adbit_session", "remember_token", "csrf_cookie_name", "cf_clearance", "g_state"]
    parts, seen = [], set()
    for k in prefer:
        if k in d:
            parts.append("%s=%s" % (k, d[k]))
            seen.add(k)
    for k, v in d.items():
        if k not in seen:
            parts.append("%s=%s" % (k, v))
    return "; ".join(parts)


def _persist_cookie(acc: dict, cookie: str) -> None:
    if not cookie or not acc:
        return
    try:
        aid = acc.get("id")
        if aid:
            update_account(aid, cookie=cookie)
            a2 = get_account(aid)
            if a2:
                write_account_files(a2)
        try:
            acc["cookie"] = cookie
        except Exception:
            pass
    except Exception as e:
        print("[persist cookie]", e)


def deposit_info(aid: int) -> dict:
    """Deposit manzil: to'g'ri host + cookie; login kerak bo'lsa email/parol."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    addr = (acc.get("wallet") or "").strip()
    bal = acc.get("balance")
    try:
        bal = float(bal) if bal is not None else 0.0
    except Exception:
        bal = 0.0
    lvl = {"level": "—", "level_index": None, "wager": None, "levels": LEVELS_DEFAULT, "next": None}
    err = ""
    platform = acc.get("platform") or ""

    def _bal_from(html: str):
        nonlocal bal
        for pat in (
            r'user_balance\s*=\s*([0-9.]+)',
            r'class=["\'][^"\']*user_balance[^"\']*["\'][^>]*>([0-9.]+)',
            r'user_balance[^<]{0,5}>([0-9.]+)',
        ):
            mm = re.search(pat, html or "", re.I)
            if mm:
                try:
                    bal = float(mm.group(1))
                    break
                except Exception:
                    pass

    def _lvl_from(html: str):
        nonlocal lvl
        try:
            lv = _parse_level(html or "")
            if lv.get("level") and lv["level"] != "—":
                lvl = lv
        except Exception:
            pass

    def _save_cookie_from(sess):
        try:
            cur = _session_cookie_string(sess)
            if not cur:
                return
            merged = _merge_cookie_strings(acc.get("cookie") or "", cur)
            if merged:
                _persist_cookie(acc, merged)
                sess.headers["Cookie"] = merged
        except Exception:
            pass

    def _fetch_deposit(sess):
        nonlocal addr, err
        last_html = ""
        for dep_path in ("deposit.php", "wallet.php", "account.php", "profile.php", "faucet.php"):
            try:
                r = sess.get(host + dep_path, timeout=30, allow_redirects=True)
                html = r.text or ""
                last_html = html
                if "login.php" in (r.url or "").lower():
                    return False, html
                # 404 sahifa — keyingi
                hl = html.lower()
                if "404 page not found" in hl or "the page you requested was not found" in hl:
                    continue
                a = _parse_deposit_address(html)
                if a and len(a) >= 20:
                    addr = a
                    _bal_from(html)
                    _lvl_from(html)
                    _save_cookie_from(sess)
                    return True, html
                # manzil yo'q lekin login OK — balans olish
                _bal_from(html)
                _lvl_from(html)
                _save_cookie_from(sess)
            except Exception as e:
                err = str(e)
                continue
        return bool(addr and len(addr) >= 20), last_html

    try:
        s = _acc_session(acc)
        ok_page, html = _fetch_deposit(s)

        # Brauzer kabi deposit tekshiruv (TX kredit)
        try:
            s.post(
                host + "load.php",
                data={"data": "deposit_transactions"},
                headers={
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": host + "deposit.php",
                    "Origin": host.rstrip("/"),
                },
                timeout=25,
            )
        except Exception:
            pass
        try:
            r2 = s.get(host + "faucet.php", timeout=25, allow_redirects=True)
            if "login.php" not in (r2.url or "").lower():
                _bal_from(r2.text or "")
                _lvl_from(r2.text or "")
                _save_cookie_from(s)
        except Exception:
            pass

        if not ok_page or not addr or len(addr) < 20:
            # faucet fallback (ba'zi saytlar)
            try:
                r = s.get(host + "faucet.php", timeout=25, allow_redirects=True)
                if "login.php" not in (r.url or "").lower():
                    a = _parse_deposit_address(r.text or "")
                    if a and len(a) >= 20:
                        addr = a
                    _bal_from(r.text or "")
                    _lvl_from(r.text or "")
                    _save_cookie_from(s)
                    ok_page = True
            except Exception:
                pass

        need_login = (not ok_page) or (not addr or len(addr) < 20)
        if need_login:
            # disk cookie qayta urinish
            try:
                sync_cookie_from_disk(acc)
                acc = get_account(aid) or acc
                s = _acc_session(acc)
                ok_page, html = _fetch_deposit(s)
                if addr and len(addr) >= 20:
                    need_login = False
            except Exception:
                pass
        if need_login and acc.get("email") and acc.get("password"):
            # login: toza sessiya (login funksiyasi o'zi toza session ochadi)
            if _login_session_for_deposit(acc, s, host):
                acc = get_account(aid) or acc
                s = _acc_session(acc)
                ok_page, html = _fetch_deposit(s)
            else:
                err = err or "Login muvaffaqiyatsiz (captcha/parol). Cookie yangilang."
        elif need_login and not (acc.get("email") and acc.get("password")):
            err = "Cookie eskirgan — email+parol yoki yangi cookie kerak"

        if addr and len(addr) >= 20:
            try:
                update_account(aid, deposit_address=addr)
                if bal is not None:
                    update_account(aid, balance=float(bal))
            except Exception:
                pass
            try:
                folder = ACCOUNTS / acc["folder"]
                folder.mkdir(parents=True, exist_ok=True)
                ps = folder / "panel_status.json"
                data = {}
                if ps.is_file():
                    try:
                        data = json.loads(ps.read_text(encoding="utf-8"))
                    except Exception:
                        data = {}
                data["wallet"] = addr
                data["balance"] = bal
                if lvl.get("level") and lvl["level"] != "—":
                    data["level"] = lvl["level"]
                data["updated"] = int(time.time())
                ps.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
            except Exception:
                pass
            return {
                "ok": True,
                "address": addr,
                "deposit_address": addr,
                "balance": bal,
                "level": lvl.get("level"),
                "level_index": lvl.get("level_index"),
                "wager": lvl.get("wager"),
                "wager_amount": lvl.get("wager_amount"),
                "target_amount": lvl.get("target_amount"),
                "levels": lvl.get("levels"),
                "next": lvl.get("next"),
                "coin": acc.get("coin"),
                "platform": platform,
                "host": host,
                "found": True,
                "error": "",
                "can_save": True,
            }

        return {
            "ok": True,
            "address": "",
            "balance": bal,
            "level": lvl.get("level"),
            "level_index": lvl.get("level_index"),
            "wager": lvl.get("wager"),
            "levels": lvl.get("levels"),
            "next": lvl.get("next"),
            "coin": acc.get("coin"),
            "platform": platform,
            "host": host,
            "found": False,
            "error": err or ("Manzil topilmadi — %s uchun cookie/login" % (platform or "site")),
            "can_save": True,
        }
    except Exception as e:
        return {
            "ok": False,
            "error": str(e),
            "address": addr or "",
            "balance": bal,
            "coin": acc.get("coin"),
            "platform": platform,
            "found": False,
            "can_save": True,
        }



def register_meta(platform: str) -> dict:
    """Saytdan referral / signup maydonlari haqida."""
    plat = PLATFORMS.get(platform)
    if not plat:
        return {"ok": False, "error": "bad platform"}
    host = plat["host"]
    fields = ["username", "email", "password", "rpassword", "referrer", "agree"]
    ref = ""
    try:
        import requests
        r = requests.get(host + "signup.php", timeout=20, headers={"User-Agent": random.choice(UA_POOL)})
        html = r.text or ""
        m = re.search(r'id=["\']referrer["\'][^>]*value=["\']([^"\']*)', html)
        if m:
            ref = m.group(1)
        m = re.search(r'[?&]ref=([A-Za-z0-9_]+)', html)
        if m and not ref:
            ref = m.group(1)
    except Exception as e:
        return {"ok": True, "fields": fields, "referrer_default": ref, "host": host, "note": str(e)}
    return {"ok": True, "fields": fields, "referrer_default": ref, "host": host, "coin": plat["coin"]}



def _ic_pick_index(img_b64: str):
    """Lokal least-count indekslar (PIL), aks holda 0..7."""
    idxs = list(range(8))
    try:
        import base64 as _b64
        from io import BytesIO
        from PIL import Image
        from collections import Counter
        raw = img_b64
        if "," in raw[:40]:
            raw = raw.split(",", 1)[1]
        im = Image.open(BytesIO(_b64.b64decode(raw))).convert("RGBA")
        w, h = im.size
        for n in (5, 6, 7, 8):
            tw = w // n
            if tw < 8:
                continue
            tiles = []
            for i in range(n):
                tile = im.crop((i * tw, 0, (i + 1) * tw, h))
                tiles.append(tuple(tile.resize((16, 16)).getdata()))
            c = Counter(tiles)
            return sorted(range(n), key=lambda i: (c[tiles[i]], i))
    except Exception:
        pass
    random.shuffle(idxs)
    return idxs


def _solve_icon_http(sess, host: str, html: str, referer: str):
    """IconCaptcha LOAD → SELECTION (challengeId + width variants)."""
    import base64 as _b64
    import uuid as _uuid
    mtok = re.search(r"_iconcaptcha-token['\"]?\s*value=['\"]([^'\"]+)", html, re.I)
    if not mtok:
        mtok = re.search(r'name=["\']_iconcaptcha-token["\'][^>]*value=["\']([^"\']+)', html, re.I)
    if not mtok:
        return None
    token = mtok.group(1)
    endpoint = host.rstrip("/") + "/iconcaptcha.php"
    for _round in range(1, 4):
        wid = str(_uuid.uuid4())
        ts = int(time.time() * 1000)
        payload = _b64.b64encode(
            json.dumps(
                {"widgetId": wid, "action": "LOAD", "theme": "light", "token": token,
                 "timestamp": ts, "initTimestamp": ts},
                separators=(",", ":"),
            ).encode()
        ).decode()
        try:
            r = sess.post(
                endpoint,
                data={"payload": payload},
                headers={
                    "X-IconCaptcha-Token": token,
                    "X-Requested-With": "XMLHttpRequest",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "Referer": referer,
                },
                timeout=40,
            )
            raw = (r.text or "").strip()
            try:
                data = json.loads(_b64.b64decode(raw))
            except Exception:
                data = json.loads(raw)
        except Exception as e:
            print("[reg IC LOAD]", e)
            time.sleep(0.8)
            continue
        img = data.get("challenge") or data.get("base64") or ""
        cid = data.get("identifier") or data.get("challengeId") or ""
        if not img or not cid:
            continue
        time.sleep(random.uniform(0.4, 0.9))
        order = _ic_pick_index(img if isinstance(img, str) else "")
        # n_icons from image width
        n_icons = max(5, min(8, len(order) if order else 6))
        try:
            from io import BytesIO
            from PIL import Image
            rawi = img
            if "," in rawi[:40]:
                rawi = rawi.split(",", 1)[1]
            im = Image.open(BytesIO(_b64.b64decode(rawi)))
            n_icons = max(5, min(8, im.size[0] // 40))
        except Exception:
            pass
        for idx in order[:5]:
            if idx < 0 or idx >= n_icons:
                continue
            for w in (320, 300, 280, 340, 360):
                x = int(round((idx + 0.5) * (w / float(n_icons))))
                y = random.randint(28, 52)
                ts = int(time.time() * 1000)
                sel = {
                    "widgetId": wid,
                    "challengeId": cid,
                    "action": "SELECTION",
                    "x": x,
                    "y": y,
                    "width": w,
                    "token": token,
                    "timestamp": ts,
                    "initTimestamp": ts,
                }
                payload = _b64.b64encode(json.dumps(sel, separators=(",", ":")).encode()).decode()
                try:
                    r = sess.post(
                        endpoint,
                        data={"payload": payload},
                        headers={
                            "X-IconCaptcha-Token": token,
                            "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "Referer": referer,
                        },
                        timeout=40,
                    )
                    raw = (r.text or "").strip()
                    try:
                        d = json.loads(_b64.b64decode(raw)) if raw else {}
                    except Exception:
                        try:
                            d = json.loads(raw or "{}")
                        except Exception:
                            d = {}
                except Exception:
                    d = {}
                if d.get("completed"):
                    return {
                        "_iconcaptcha-token": token,
                        "ic-rq": "1",
                        "ic-wid": wid,
                        "ic-cid": cid,
                        "ic-hp": "",
                    }
                time.sleep(0.08)
        time.sleep(0.5)
    return None



def register_on_site(
    platform: str,
    username: str,
    email: str,
    password: str,
    referrer: str = "",
    add_local: bool = True,
) -> dict:
    """process.php action=signup — IconCaptcha bilan (process_signup2)."""
    plat = PLATFORMS.get(platform)
    if not plat:
        return {"ok": False, "error": "platform"}
    if not username or not email or not password:
        return {"ok": False, "error": "username, email, password kerak"}
    username = username.strip()[:16]
    email = email.strip()
    host = plat["host"]
    if not host.endswith("/"):
        host = host + "/"

    try:
        import requests
        s = requests.Session()
        ua = random.choice(UA_POOL)
        s.headers.update({
            "User-Agent": ua,
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "Accept-Language": "en-US,en;q=0.9",
        })
        page = s.get(host + "signup.php", timeout=30)
        html = page.text or ""
        csrf = _parse_csrf(html, s) or ""
        ic = _solve_icon_http(s, host, html, host + "signup.php")
        if not ic:
            return {"ok": False, "error": "IconCaptcha yechilmadi — qayta urinib ko'ring"}

        data = {
            "action": "signup",
            "username": username,
            "email": email,
            "password": password,
            "rpassword": password,
            "referrer": referrer or "",
            "agree": "1",
            "captcha_type": "0",
            "g-recaptcha-response": "",
            "h-captcha-response": "",
            "c_captcha_response": "",
            "pcaptcha_token": "",
            "_iconcaptcha-token": ic.get("_iconcaptcha-token", ""),
            "ic-rq": ic.get("ic-rq", "1"),
            "ic-wid": ic.get("ic-wid", ""),
            "ic-cid": ic.get("ic-cid", ""),
            "ic-hp": ic.get("ic-hp", ""),
        }
        if csrf:
            data["csrf_test_name"] = csrf

        r = s.post(
            host + "process.php",
            data=data,
            timeout=45,
            headers={
                "X-Requested-With": "XMLHttpRequest",
                "Referer": host + "signup.php",
                "Origin": host.rstrip("/"),
                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            },
        )
        txt = (r.text or "").strip()
        try:
            obj = r.json()
        except Exception:
            try:
                obj = json.loads(txt)
            except Exception:
                # double JSON
                obj = {"ret": 0, "mes": txt[:300]}
        if not isinstance(obj, dict):
            obj = {"ret": 0, "mes": str(obj)[:200]}
        mes = str(obj.get("mes") or "")
        ret = int(obj.get("ret") or 0)
        if ret == 1 or "success" in mes.lower() or "registered" in mes.lower():
            # Sessiya mustahkamlash: faucet + login cookie to'liq
            try:
                s.get(host + "faucet.php", timeout=25)
            except Exception:
                pass
            try:
                s.get(host + "account.php", timeout=20)
            except Exception:
                pass
            # fp yo'q bo'lsa qo'shamiz
            # to'liq cookie jar (barcha nomlar)
            jar = {}
            for c in s.cookies:
                jar[c.name] = c.value
            if not jar.get("fp"):
                import secrets
                jar["fp"] = secrets.token_urlsafe(12)[:16]
                try:
                    from urllib.parse import urlparse
                    dom = urlparse(host).hostname or ""
                    s.cookies.set("fp", jar["fp"], domain=dom)
                except Exception:
                    pass
            # prefer stable order: session cookies first
            prefer = ["fp", "user_session", "adbit_session", "remember_token", "csrf_cookie_name", "cf_clearance"]
            parts = []
            for k in prefer:
                if k in jar:
                    parts.append(f"{k}={jar[k]}")
            for k, v in jar.items():
                if k not in prefer:
                    parts.append(f"{k}={v}")
            cookie = "; ".join(parts)
            # unique UA for platform
            try:
                ua = pick_unique_ua(platform, ua)
            except Exception:
                pass
            aid = None
            if add_local:
                aid = create_account(
                    platform=platform,
                    label=username,
                    email=email,
                    password=password,
                    cookie=cookie,
                    user_agent=ua,
                    auto_start=False,
                )
                try:
                    update_account(aid, label=username, status="RUN", last_msg="registered", health="ok")
                    write_account_files(get_account(aid))
                    # live ma'lumot
                    try:
                        refresh_account_live(aid)
                    except Exception as e:
                        print("[reg live]", e)
                    time.sleep(0.8)
                    start_account(aid)
                    update_account(aid, status="RUN", last_msg="registered+started", health="ok")
                    try:
                        ensure_unique_uas()
                    except Exception:
                        pass
                    try:
                        refresh_snapshot()
                    except Exception:
                        pass
                except Exception as e:
                    print("[reg start]", e)
                    try:
                        start_account(aid)
                    except Exception:
                        pass
            return {"ok": True, "account_id": aid, "mes": mes or "OK", "via": "http+ic", "cookie": bool(cookie), "cookie_len": len(cookie)}
        low = mes.lower()
        if "already" in low or "exist" in low or "taken" in low:
            return {"ok": False, "error": mes or "Email/username band", "raw": obj}
        return {"ok": False, "error": mes or "signup fail", "raw": obj}
    except Exception as e:
        return {"ok": False, "error": str(e)}



def _pick_chip_index(balance: float) -> int:
    """37 raqam × chip — balans yetadigan eng katta index (0..6)."""
    bal_micro = float(balance or 0) * 1_000_000.0
    best = 0
    for i in range(7):
        total = 100 * (10 ** i) * 37
        if total <= bal_micro * 0.999:
            best = i
    return best


def refresh_account_live(aid: int) -> dict:
    """Saytdan balans, level, wager, affiliates, stamina ni olib DB+checkpoint yangilash."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    out = {
        "ok": True,
        "balance": acc.get("balance"),
        "level": "—",
        "wager_pct": acc.get("wager_pct"),
        "affiliate_balance": None,
        "claims_left": acc.get("claims_left"),
        "stamina_pct": acc.get("stamina_pct"),
        "online": is_running(aid),
        "user": acc.get("label"),
    }
    try:
        s = _acc_session(acc)
        html = ""
        for path in ("faucet.php", "account.php", "affiliates.php", "referral.php", "deposit.php"):
            try:
                r = s.get(host + path, timeout=25, allow_redirects=True)
                if "login.php" in (r.url or ""):
                    continue
                html += "\n" + (r.text or "")
            except Exception:
                continue
        # login kerakmi?
        if (not html.strip() or "login.php" in html[:3000].lower()) and acc.get("email") and acc.get("password"):
            if _login_session_for_deposit(acc, s, host):
                acc = get_account(aid) or acc
                s = _acc_session(acc)
                html = ""
                for path in ("faucet.php", "deposit.php", "account.php"):
                    try:
                        r = s.get(host + path, timeout=25, allow_redirects=True)
                        if "login.php" not in (r.url or ""):
                            html += "\n" + (r.text or "")
                    except Exception:
                        pass
        # cookie yangilash (har refresh da)
        try:
            cur = _session_cookie_string(s)
            if cur and ("user_session=" in cur or "remember_token=" in cur or "adbit_session=" in cur):
                merged = _merge_cookie_strings(acc.get("cookie") or "", cur)
                if merged:
                    _persist_cookie(acc, merged)
        except Exception:
            pass
        lvl = _parse_level(html)
        # username / label
        try:
            um = re.search(r'Welcome back[,\s]*([A-Za-z0-9_\.\-]{2,40})', html, re.I)
            if not um:
                um = re.search(r'user_name\s*=\s*["\']([^"\']+)', html, re.I)
            if not um:
                um = re.search(r'id=["\']username["\'][^>]*>([^<]{2,40})', html, re.I)
            if um:
                uname = um.group(1).strip()
                if uname and uname.lower() not in ("user", "guest", "null"):
                    out["user"] = uname
                    try:
                        update_account(aid, label=uname)
                    except Exception:
                        pass
        except Exception:
            pass
        # deposit wallet try
        try:
            wa = _parse_deposit_address(html)
            if wa and len(wa) >= 20:
                out["wallet"] = wa
                try:
                    update_account(aid, wallet=wa)
                except Exception:
                    pass
        except Exception:
            pass
        # balance
        bal = out["balance"]
        cands = []
        for pat in [
            r'user_balance\s*=\s*([0-9.]+)',
            r'id=["\']user_balance["\'][^>]*>([0-9.]+)',
            r'balance["\']?\s*[:=]\s*["\']?([0-9.]+)',
        ]:
            for mm in re.finditer(pat, html, re.I):
                try:
                    v = float(mm.group(1))
                    if 0 <= v < 1e9:
                        cands.append(v)
                except Exception:
                    pass
        # user_balance odatda eng ishonchli — eng katta mantiqiy (claim sum emas)
        if cands:
            cands = sorted(set(cands))
            # TRX/TON: juda kichik yolg'iz claim qiymatini rad et
            if len(cands) == 1:
                bal = cands[0]
            else:
                # eng katta (real balance) — lekin outlier 1000x yo'q
                bal = cands[-1]
                if len(cands) >= 2 and cands[-1] > cands[-2] * 100 and cands[-2] > 0:
                    bal = cands[-2]

        # claims / stamina
        cl = None
        mm = re.search(r'claims_remaining["\']?\s*>\s*(\d+)', html, re.I) or re.search(r'Remaining claims:\s*(\d+)', html, re.I)
        if mm:
            cl = int(mm.group(1))
        sta = None
        mm = re.search(r'progress-percentage-stamina["\']?\s*>\s*([0-9.]+)', html, re.I)
        if mm:
            try:
                sta = float(mm.group(1))
            except Exception:
                pass
        # affiliate balance
        aff = None
        for pat in [
            r'affiliate[_\s-]*balance[^0-9]{0,30}([0-9.]+)',
            r'referral[_\s-]*balance[^0-9]{0,30}([0-9.]+)',
            r'id=["\']affiliate_balance["\'][^>]*>([0-9.]+)',
            r'id=["\']ref_balance["\'][^>]*>([0-9.]+)',
            r'aff_balance\s*=\s*([0-9.]+)',
        ]:
            mm = re.search(pat, html, re.I)
            if mm:
                try:
                    aff = float(mm.group(1))
                    break
                except Exception:
                    pass
        wager_pct = lvl.get("wager")
        if wager_pct is not None and wager_pct <= 1.5:
            # 0.1 => 10% ehtimoli
            if wager_pct <= 1.0:
                wager_pct = wager_pct * 100
        kw = {}
        if bal is not None:
            nb = sticky_balance(acc.get("balance"), bal)
            if nb is not None:
                kw["balance"] = float(nb)
                out["balance"] = float(nb)
            else:
                out["balance"] = acc.get("balance")
        if lvl.get("level") and lvl["level"] != "—":
            kw["level"] = str(lvl["level"])[:80]
            out["level"] = lvl["level"]
        if wager_pct is not None:
            kw["wager_pct"] = float(wager_pct)
            out["wager_pct"] = float(wager_pct)
        if cl is not None:
            kw["claims_left"] = cl
            out["claims_left"] = cl
        if sta is not None:
            kw["stamina_pct"] = sta
            out["stamina_pct"] = sta
        out["affiliate_balance"] = aff
        # panel fallback level
        try:
            folder = ACCOUNTS / acc["folder"]
            ps = folder / "panel_status.json"
            if ps.is_file():
                pdata = json.loads(ps.read_text(encoding="utf-8"))
                if (not out.get("level") or out["level"]=="—") and pdata.get("level"):
                    out["level"] = pdata.get("level")
                if out.get("wager_pct") is None and pdata.get("wager_pct") is not None:
                    out["wager_pct"] = pdata.get("wager_pct")
        except Exception:
            pass
        if out.get("level") and out["level"] not in ("—", "-", None, ""):
            kw["level"] = str(out["level"])[:80]
        out["level_index"] = lvl.get("level_index")
        out["next"] = lvl.get("next")
        # status online if running
        if is_running(aid):
            kw["status"] = "RUN"
            kw["health"] = "ok"
            out["online"] = True
        if kw:
            try:
                update_account(aid, **{k: v for k, v in kw.items() if k != "label"})
            except Exception:
                pass
        # panel_status + checkpoint
        try:
            folder = ACCOUNTS / acc["folder"]
            folder.mkdir(parents=True, exist_ok=True)
            ps = folder / "panel_status.json"
            data = {}
            if ps.is_file():
                try:
                    data = json.loads(ps.read_text(encoding="utf-8"))
                except Exception:
                    data = {}
            data.update({
                "user": acc.get("label") or data.get("user"),
                "balance": out["balance"],
                "coin": acc.get("coin"),
                "level": out.get("level") or data.get("level"),
                "wager_pct": out.get("wager_pct"),
                "claims_left": out.get("claims_left"),
                "stamina_pct": out.get("stamina_pct"),
                "affiliate_balance": aff,
                "status": "ONLINE" if is_running(aid) else (data.get("status") or "WAIT"),
                "last": "refresh",
                "source": "bot",
                "updated": int(time.time()),
            })
            ps.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        try:
            refresh_snapshot()
        except Exception:
            pass
        return out
    except Exception as e:
        out["ok"] = False
        out["error"] = str(e)
        return out


def affiliate_info(aid: int) -> dict:
    """Affiliates balans + claim mumkinligi."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "no account"}
    host = _host_for(acc)
    try:
        s = _acc_session(acc)
        html = ""
        for path in ("affiliates.php", "referral.php", "faucet.php", "account.php"):
            try:
                r = s.get(host + path, timeout=20, allow_redirects=True)
                if "login.php" not in (r.url or ""):
                    html += "\n" + (r.text or "")
            except Exception:
                pass
        aff = None
        for pat in [
            r'affiliate[_\s-]*balance[^0-9]{0,30}([0-9.]+)',
            r'referral[_\s-]*balance[^0-9]{0,30}([0-9.]+)',
            r'id=["\']affiliate_balance["\'][^>]*>([0-9.]+)',
            r'aff_balance\s*=\s*([0-9.]+)',
            r'available[_\s-]*commission[^0-9]{0,20}([0-9.]+)',
        ]:
            mm = re.search(pat, html, re.I)
            if mm:
                try:
                    aff = float(mm.group(1))
                    break
                except Exception:
                    pass
        return {"ok": True, "affiliate_balance": aff, "coin": acc.get("coin")}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def affiliate_claim(aid: int) -> dict:
    """Affiliates claim — process.php action variantlari."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "no account"}
    host = _host_for(acc)
    try:
        s = _acc_session(acc)
        html = ""
        try:
            r = s.get(host + "affiliates.php", timeout=20)
            html = r.text or ""
            if "login.php" in (r.url or ""):
                r = s.get(host + "faucet.php", timeout=20)
                html = r.text or ""
        except Exception:
            pass
        csrf = _parse_csrf(html, s)
        last = None
        for action in (
            "claim_affiliate",
            "affiliate_claim",
            "claim_referral",
            "referral_claim",
            "claim_ref",
            "get_affiliate_bonus",
        ):
            data = {"action": action}
            if csrf:
                data["csrf_test_name"] = csrf
            try:
                rr = s.post(
                    host + "process.php",
                    data=data,
                    timeout=30,
                    headers={
                        "X-Requested-With": "XMLHttpRequest",
                        "Referer": host + "affiliates.php",
                    },
                )
                txt = (rr.text or "").strip()
                try:
                    obj = rr.json()
                except Exception:
                    try:
                        obj = json.loads(txt)
                    except Exception:
                        obj = {"ret": 0, "mes": txt[:200]}
                last = obj
                mes = str(obj.get("mes") or "")
                if int(obj.get("ret") or 0) == 1 or "success" in mes.lower() or "claimed" in mes.lower():
                    # refresh balance
                    try:
                        refresh_account_live(aid)
                    except Exception:
                        pass
                    return {"ok": True, "mes": mes or "claimed", "action": action, "raw": obj}
            except Exception as e:
                last = {"error": str(e)}
        return {"ok": False, "error": (last or {}).get("mes") or (last or {}).get("error") or "claim fail", "raw": last}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def roulette37_status(aid: int) -> dict:
    st = ROULETTE_JOBS.get(aid) or {"running": False, "spins": 0, "wager": 0.0, "msg": "idle"}
    return st


def roulette37_stop(aid: int) -> dict:
    st = ROULETTE_JOBS.get(aid)
    if st:
        st["stop"] = True
        st["msg"] = "stopping…"
    return {"ok": True}



def roulette37_start(aid: int, max_spins: int = 200) -> dict:
    """process.php · 0..36 chip · cookie disk+DB."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    if aid in _roulette_threads:
        th = _roulette_threads[aid]
        if getattr(th, "is_alive", lambda: False)():
            return {"ok": False, "error": "allaqachon ishlayapti", "status": roulette37_status(aid)}

    ROULETTE_JOBS[aid] = {
        "running": True, "stop": False, "spins": 0, "wager": 0.0,
        "wins": 0, "losses": 0, "chip": 0,
        "balance": acc.get("balance") or 0, "msg": "starting", "last": "",
    }

    import threading
    from urllib.parse import urlencode

    def worker():
        st = ROULETTE_JOBS[aid]
        try:
            acc2 = get_account(aid) or acc
            s = _acc_session(acc2)
            host = _host_for(acc2)
            r = s.get(host + "roulette.php", timeout=25)
            html = r.text or ""
            if "login.php" in (r.url or ""):
                if acc2.get("email") and acc2.get("password"):
                    st["msg"] = "login..."
                    if _login_session_for_deposit(acc2, s, host):
                        acc2 = get_account(aid) or acc2
                        s = _acc_session(acc2)
                        r = s.get(host + "roulette.php", timeout=25)
                        html = r.text or ""
                if "login.php" in (r.url or ""):
                    st["msg"] = "session yo'q — cookie/login"
                    st["running"] = False
                    return
            csrf = _parse_csrf(html, s)
            bal = float(acc2.get("balance") or 0)
            mm = re.search(r'user_balance\s*=\s*([0-9.]+)', html)
            if mm:
                try: bal = float(mm.group(1))
                except Exception: pass
            st["balance"] = bal

            spins = 0
            while not st.get("stop") and spins < max_spins:
                idx_chip = _pick_chip_index(bal)
                per_micro = 100 * (10 ** idx_chip)
                total_micro = per_micro * 37
                chip_coin = per_micro / 1_000_000.0
                total_coin = total_micro / 1_000_000.0
                if total_micro > bal * 1_000_000.0 + 1:
                    if 37 * 100 > bal * 1_000_000.0:
                        st["msg"] = "balans < min×37"
                        break
                    idx_chip, per_micro, total_micro = 0, 100, 3700
                    chip_coin, total_coin = 0.0001, 0.0037

                st["chip"] = chip_coin
                chip_bet = [[n, idx_chip] for n in range(37)]
                body = urlencode({
                    "action": "bet_game_roulette",
                    "chip_bet": json.dumps(chip_bet, separators=(",", ":")),
                    "csrf_test_name": csrf or "",
                })
                try:
                    obj = {}
                    txt = ""
                    for ep in ("process.php", "api.php"):
                        resp = s.post(
                            host + ep,
                            data=body,
                            timeout=40,
                            headers={
                                "X-Requested-With": "XMLHttpRequest",
                                "Referer": host + "roulette.php",
                                "Origin": host.rstrip("/"),
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            },
                        )
                        txt = (resp.text or "").strip()
                        if txt.startswith("<"):
                            continue
                        try:
                            obj = json.loads(txt)
                            break
                        except Exception:
                            obj = {"ret": 0, "mes": txt[:180]}
                    try:
                        cur = _session_cookie_string(s)
                        if cur:
                            acc_live = get_account(aid) or acc2
                            merged = _merge_cookie_strings(acc_live.get("cookie") or "", cur)
                            if merged:
                                _persist_cookie(acc_live, merged)
                    except Exception:
                        pass

                    spins += 1
                    st["spins"] = spins
                    st["wager"] = round(float(st.get("wager") or 0) + total_coin, 9)

                    if int(obj.get("ret") or 0) == 1 or obj.get("num") is not None:
                        if obj.get("balance") is not None:
                            try:
                                bv = float(obj["balance"])
                                bal = bv / 1_000_000.0 if bv > 1000 else bv
                            except Exception:
                                pass
                        st["balance"] = bal
                        st["last"] = f"num={obj.get('num')} chip={chip_coin}"
                        st["msg"] = f"spin {spins} · abarot {st['wager']:.6g} · bal {bal:.6g}"
                        try:
                            update_account(aid, balance=bal, status="RUN", last_msg="roulette ONLINE")
                        except Exception:
                            pass
                        try:
                            folder = ACCOUNTS / (get_account(aid) or {}).get("folder", "")
                            if folder and Path(folder).is_dir():
                                ps = Path(folder) / "panel_status.json"
                                d = {}
                                if ps.is_file():
                                    try: d = json.loads(ps.read_text(encoding="utf-8"))
                                    except Exception: d = {}
                                d.update({"status":"ONLINE","last":st["msg"],"balance":bal,"updated":int(time.time()),"source":"bot"})
                                ps.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
                        except Exception:
                            pass
                        if spins % 12 == 0:
                            try: refresh_account_live(aid)
                            except Exception: pass
                    else:
                        mes = str(obj.get("mes") or obj)
                        st["last"] = mes[:120]
                        st["msg"] = f"fail: {mes[:80]}"
                        if "login" in mes.lower() or "session" in mes.lower():
                            break
                        try:
                            rr = s.get(host + "roulette.php", timeout=20)
                            csrf = _parse_csrf(rr.text or "", s)
                        except Exception:
                            pass
                        time.sleep(1.2)
                except Exception as e:
                    st["msg"] = f"err: {e}"
                    time.sleep(2)
                time.sleep(random.uniform(0.6, 1.4))

            st["running"] = False
            st["msg"] = st.get("msg") or "done"
            try: refresh_account_live(aid)
            except Exception: pass
        except Exception as e:
            st["running"] = False
            st["msg"] = f"crash: {e}"

    th = threading.Thread(target=worker, name=f"roulette37-{aid}", daemon=True)
    _roulette_threads[aid] = th
    th.start()
    return {"ok": True, "status": roulette37_status(aid)}



def stop_all_bots() -> int:
    n = 0
    for aid in list(_procs.keys()):
        try:
            stop_account(aid)
            n += 1
        except Exception:
            pass
    return n



# ── Confirm email / withdraw (hisob cookie + UA) ──────────────────





def _solve_hcaptcha_xevil(pageurl: str, sitekey: str = "") -> str:
    """Xevil/2captcha uslubida hCaptcha token."""
    key = ""
    try:
        key = (get_setting("xevil_apikey", "") or "").strip()
    except Exception:
        pass
    if not key:
        key = (os.environ.get("XEVIL_API_KEY") or os.environ.get("XEVIL_APIKEY") or "").strip()
    if not key:
        return ""
    sitekey = sitekey or "6ef421cc-2fbc-493a-96ec-550c43f8ecd2"
    hosts = [
        "https://sctg.xyz",
        "https://ru.sctg.xyz",
        "https://api.sctg.xyz",
        "http://2captcha.com",
        "https://2captcha.com",
    ]
    import requests as _rq
    for base in hosts:
        try:
            r = _rq.get(
                base.rstrip("/") + "/in.php",
                params={
                    "key": key,
                    "method": "hcaptcha",
                    "sitekey": sitekey,
                    "pageurl": pageurl,
                    "json": 1,
                },
                timeout=30,
            )
            j = r.json() if r.text else {}
            if str(j.get("status")) != "1":
                # text format
                t = (r.text or "").strip()
                if t.startswith("OK|"):
                    req_id = t.split("|", 1)[1]
                else:
                    continue
            else:
                req_id = j.get("request")
            if not req_id:
                continue
            for _ in range(40):
                time.sleep(3)
                rr = _rq.get(
                    base.rstrip("/") + "/res.php",
                    params={"key": key, "action": "get", "id": req_id, "json": 1},
                    timeout=30,
                )
                try:
                    jj = rr.json()
                except Exception:
                    tt = (rr.text or "").strip()
                    if tt.startswith("OK|"):
                        return tt.split("|", 1)[1]
                    if "CAPCHA_NOT_READY" in tt or "NOT_READY" in tt:
                        continue
                    break
                if str(jj.get("status")) == "1":
                    return str(jj.get("request") or "")
                if "NOT_READY" in str(jj.get("request") or "").upper():
                    continue
                break
        except Exception:
            continue
    return ""


def email_verify_status(aid: int) -> dict:
    """settings: Verify email tugmasi bormi yoki allaqachon verified."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found", "verified": None}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    try:
        s = _acc_session(acc)
        r = s.get(host + "settings.php", timeout=30, allow_redirects=True)
        if "login.php" in (r.url or "").lower():
            try:
                ok_login = _login_session_for_deposit(acc, s, host)
                msg = "login fail" if not ok_login else "ok"
            except Exception as e:
                ok_login, msg = False, str(e)
            if not ok_login:
                return {"ok": False, "error": f"login: {msg}", "verified": None}
            r = s.get(host + "settings.php", timeout=30, allow_redirects=True)
        html = r.text or ""
        try:
            _persist_cookie(acc, _merge_cookie_strings(acc.get("cookie") or "", _session_cookie_string(s)))
        except Exception:
            pass
        has_btn = bool(re.search(r'id=["\']process_verify_email["\']|onclick=["\']process_verify_email', html, re.I))
        # ba'zi saytlar verified yozuvi
        verified_txt = bool(re.search(r'email\s+(is\s+)?verified|verified\s+successfully|already\s+verified', html, re.I))
        # agar tugma yo'q va settings ochiq — verified deb hisobla
        verified = (not has_btn) or verified_txt
        if has_btn and not verified_txt:
            verified = False
        return {
            "ok": True,
            "verified": verified,
            "has_button": has_btn,
            "mes": "Email verified" if verified else "Email not verified — Verify email yuborish mumkin",
        }
    except Exception as e:
        return {"ok": False, "error": str(e), "verified": None}




def verify_email_send(aid: int) -> dict:
    """settings.php Verify email — tronpick JS: captcha_type=2 (hCaptcha)."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "account not found"}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    # platform sitekeys
    sitekeys = {
        "tronpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "tonpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "suipick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "dogepick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "litepick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
        "solpick": "6ef421cc-2fbc-493a-96ec-550c43f8ecd2",
    }
    plat = (acc.get("platform") or "").lower()
    hkey = sitekeys.get(plat, "6ef421cc-2fbc-493a-96ec-550c43f8ecd2")
    try:
        s = _acc_session(acc)

        def _settings():
            return s.get(host + "settings.php", timeout=30, allow_redirects=True)

        r = _settings()
        if "login.php" in (r.url or "").lower():
            if not (acc.get("email") and acc.get("password")):
                return {"ok": False, "error": "session yo'q — email/parol kerak"}
            if not _login_session_for_deposit(acc, s, host):
                return {"ok": False, "error": "login muvaffaqiyatsiz"}
            acc = get_account(aid) or acc
            s = _acc_session(acc)
            r = _settings()
            if "login.php" in (r.url or "").lower():
                return {"ok": False, "error": "session yo'q"}

        html = r.text or ""
        has_btn = bool(re.search(
            r'id=["\']process_verify_email["\']|onclick=["\']process_verify_email|Verify\s*email',
            html, re.I,
        ))
        verified_txt = bool(re.search(
            r'email\s+(is\s+)?verified|already\s+verified|verified\s+successfully',
            html, re.I,
        ))
        if verified_txt or not has_btn:
            if not has_btn:
                return {"ok": True, "success": True, "verified": True, "mes": "Email already verified"}

        csrf = _parse_csrf(html, s)
        # sitekey from page if present
        mk = re.search(r'data-sitekey=["\']([^"\']+)["\']', html, re.I)
        if mk:
            hkey = mk.group(1)

        def _post(data):
            return s.post(
                host + "process.php",
                data=data,
                headers={
                    "X-Requested-With": "XMLHttpRequest",
                    "Referer": host + "settings.php",
                    "Origin": host.rstrip("/"),
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                },
                timeout=50,
            )

        # 1) hCaptcha (sayt JS shuni ishlatadi)
        htok = ""
        try:
            htok = _solve_hcaptcha_xevil(host + "settings.php", hkey) or ""
        except Exception as e:
            htok = ""
        data = {
            "action": "verify_email",
            "csrf_test_name": csrf or "",
            "captcha_type": "2",
            "h-captcha-response": htok,
            "g-recaptcha-response": "",
        }
        if not htok:
            # 2) IconCaptcha fallback
            ic = None
            try:
                if re.search(r"iconcaptcha|_iconcaptcha-token", html, re.I):
                    ic = _solve_icon_http(s, host, html, host + "settings.php")
            except Exception:
                ic = None
            if ic:
                data = {
                    "action": "verify_email",
                    "csrf_test_name": csrf or "",
                    "captcha_type": "0",
                    "h-captcha-response": "",
                    "g-recaptcha-response": "",
                    "_iconcaptcha-token": ic.get("_iconcaptcha-token", ""),
                    "ic-rq": ic.get("ic-rq", "1"),
                    "ic-wid": ic.get("ic-wid", ""),
                    "ic-cid": ic.get("ic-cid", ""),
                    "ic-hp": ic.get("ic-hp", ""),
                }
            else:
                # xevil yo'q — ochiq xabar
                return {
                    "ok": False,
                    "error": "Verify email uchun hCaptcha kerak. Settings → xevil_apikey qo'shing yoki Open sayt → Settings dan Verify bosing.",
                    "mes": "hCaptcha required",
                }

        resp = _post(data)
        text = (resp.text or "").strip()
        try:
            obj = resp.json() if text[:1] == "{" else {}
        except Exception:
            obj = {}
        mes = str((obj.get("mes") if isinstance(obj, dict) else None) or text[:200])
        ok = isinstance(obj, dict) and obj.get("ret") in (1, "1", True)

        # 5 min wait message is soft success-ish
        if re.search(r"wait for \d+ minute|another email", mes, re.I):
            return {
                "ok": True,
                "success": True,
                "mes": mes,
                "note": "Email yaqinda yuborilgan — 5 daqiqa kuting, keyin pochtani tekshiring",
            }

        try:
            _persist_cookie(acc, _merge_cookie_strings(acc.get("cookie") or "", _session_cookie_string(s)))
        except Exception:
            pass

        if ok:
            return {"ok": True, "success": True, "mes": mes or "Verification email sent — pochtani tekshiring"}
        return {"ok": False, "success": False, "mes": mes, "error": mes}

    except Exception as e:
        return {"ok": False, "error": str(e)}


def confirm_site_link(aid: int, url: str) -> dict:
    """Email dagi confirm.php?act=...&key=... havolasini bot UA/cookie bilan ochadi."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "not found"}
    url = (url or "").strip()
    if not url.startswith("http"):
        return {"ok": False, "error": "URL http(s) bilan boshlanishi kerak"}
    host = _host_for(acc)
    from urllib.parse import urlparse, parse_qs
    try:
        u = urlparse(url)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    # faqat shu platform hostiga ruxsat
    try:
        allowed = urlparse(host).hostname or ""
        if u.hostname and allowed and u.hostname.lower() != allowed.lower():
            return {"ok": False, "error": f"Host mos emas: {u.hostname} (kutilgan {allowed})"}
    except Exception:
        pass
    qs = parse_qs(u.query or "")
    act = (qs.get("act") or [""])[0]
    key = (qs.get("key") or [""])[0]
    if not key:
        return {"ok": False, "error": "URL da key yo'q"}
    s = _acc_session(acc)
    try:
        r = s.get(url, timeout=30, allow_redirects=True)
        text = r.text or ""
        low = text.lower()
        ok = r.status_code < 400
        mes = ""
        for pat in (
            r'<div[^>]*class=["\'][^"\']*alert[^"\']*["\'][^>]*>([^<]{5,200})',
            r'<p[^>]*class=["\'][^"\']*success[^"\']*["\'][^>]*>([^<]{5,200})',
            r'(email verified|successfully|confirmed|success|activated|withdrawal confirmed)[^.<]{0,80}',
            r'(invalid|expired|already|error|failed)[^.<]{0,80}',
        ):
            mm = re.search(pat, text, re.I)
            if mm:
                mes = re.sub(r"\s+", " ", mm.group(0 if mm.lastindex is None else 1)).strip()[:160]
                break
        if not mes:
            mes = f"HTTP {r.status_code}"
        # muvaffaqiyat belgisi
        success = any(x in low for x in (
            "success", "verified", "confirmed", "activated", "thank you", "already confirmed", "already verified"
        )) and not any(x in low for x in ("invalid key", "expired", "not found"))
        if "already" in low:
            success = True
        # cookie yangilash
        try:
            jar = []
            for c in s.cookies:
                jar.append(f"{c.name}={c.value}")
            if jar:
                # merge with old
                old = (acc.get("cookie") or "").strip()
                merged = {}
                for part in (old + "; " + "; ".join(jar)).split(";"):
                    part = part.strip()
                    if "=" in part:
                        k, v = part.split("=", 1)
                        merged[k.strip()] = v.strip()
                new_c = "; ".join(f"{k}={v}" for k, v in merged.items() if k)
                if new_c:
                    update_account(aid, cookie=new_c)
                    try:
                        write_account_files(get_account(aid))
                    except Exception:
                        pass
        except Exception:
            pass
        return {
            "ok": bool(success or ok),
            "success": success,
            "act": act or "confirm",
            "mes": mes,
            "status_code": r.status_code,
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


# ── Dice auto (Games) ─────────────────────────────────────────────

def browse_as_account(aid: int, path: str = "faucet.php") -> dict:
    """Bot cookie/UA bilan sayt sahifasini olish (Open oynasi)."""
    acc = get_account(aid)
    if not acc:
        return {"ok": False, "error": "not found"}
    try:
        sync_cookie_from_disk(acc)
        acc = get_account(aid) or acc
    except Exception:
        pass
    host = _host_for(acc)
    path = (path or "faucet.php").lstrip("/")
    # ba'zan base href tufayli path ichida browse/ID qoladi
    path = re.sub(r"^browse/\d+/", "", path)
    path = path.split("?")[0].strip() or "faucet.php"
    # alias
    aliases = {
        "deposit": "deposit.php",
        "deposit/": "deposit.php",
        "profile": "profile.php",
        "settings": "settings.php",
        "dice": "dice.php",
        "faucet": "faucet.php",
        "withdraw": "withdraw.php",
        "account": "account.php",
    }
    low = path.lower().rstrip("/")
    if low in aliases:
        path = aliases[low]
    if not path.endswith(".php") and "." not in path and path not in ("",):
        # profile -> profile.php
        path = path + ".php"

    def _is_404(html: str, status: int) -> bool:
        if status == 404:
            return True
        h = (html or "").lower()
        return ("404 page not found" in h) or ("the page you requested was not found" in h)

    def _is_login(html: str, url: str) -> bool:
        u = (url or "").lower()
        h = (html or "").lower()
        return "login.php" in u or ("sign in" in h and "user_balance" not in h and "deposit_address" not in h)

    # path fallbacks (platform farqi)
    tries = [path]
    if path == "deposit.php":
        tries += ["wallet.php", "account.php", "profile.php", "faucet.php"]
    elif path == "profile.php":
        tries += ["account.php", "settings.php", "faucet.php"]
    elif path == "settings.php":
        tries += ["account.php", "profile.php"]
    # unique preserve order
    seen = set()
    tries = [p for p in tries if not (p in seen or seen.add(p))]

    s = _acc_session(acc)
    last_err = ""
    try:
        # session tekshiruv
        try:
            pr = s.get(host + "faucet.php", timeout=25, allow_redirects=True)
            if _is_login(pr.text or "", pr.url or "") and acc.get("email") and acc.get("password"):
                _login_session_for_deposit(acc, s, host)
                acc = get_account(aid) or acc
                s = _acc_session(acc)
        except Exception as e:
            last_err = str(e)

        html, final, status, used = "", host, 0, path
        for p in tries:
            try:
                url = host + p.lstrip("/")
                r = s.get(url, timeout=30, allow_redirects=True)
                html = r.text or ""
                final = r.url or url
                status = getattr(r, "status_code", 0) or 0
                used = p
                if _is_login(html, final) and acc.get("email") and acc.get("password"):
                    if _login_session_for_deposit(acc, s, host):
                        acc = get_account(aid) or acc
                        s = _acc_session(acc)
                        r = s.get(url, timeout=30, allow_redirects=True)
                        html = r.text or ""
                        final = r.url or url
                        status = getattr(r, "status_code", 0) or 0
                if not _is_404(html, status):
                    break
            except Exception as e:
                last_err = str(e)
                continue

        try:
            cur = _session_cookie_string(s)
            if cur:
                _persist_cookie(get_account(aid) or acc, cur)
        except Exception:
            pass
        ck2 = ((get_account(aid) or acc).get("cookie") or "")
        if _is_404(html, status):
            # foydali xabar
            tip = (
                "<div style='padding:16px;font-family:system-ui'>"
                "<h3>404 — sahifa topilmadi</h3>"
                "<p>So'ralgan: <b>%s</b></p>"
                "<p>Host: %s</p>"
                "<p>Session: %s</p>"
                "<p><a href='/browse/%s/faucet.php'>Faucet</a> · "
                "<a href='/browse/%s/dice.php'>Dice</a></p>"
                "<p style='color:#64748b;font-size:12px'>%s</p></div>"
            ) % (
                path,
                host,
                "OK" if ("user_session=" in ck2 or "remember_token=" in ck2) else "YO'Q — login qiling",
                aid,
                aid,
                last_err or "",
            )
            html = tip
            status = 404
        return {
            "ok": True,
            "url": final,
            "host": host,
            "path": used,
            "status": status,
            "html": html,
            "cookie_ok": ("user_session=" in ck2) or ("remember_token=" in ck2),
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def rewrite_browse_html(html: str, aid: int, host: str) -> str:
    """Havolalar/formlarni /browse/<aid>/ proxy orqali. CDN tashqi qoladi."""
    if not html:
        return ""
    base = "/browse/%d/" % aid
    host_bare = host.rstrip("/")
    bar = (
        '<div id="caps-open-bar" style="position:sticky;top:0;z-index:99999;background:#0f172a;color:#e2e8f0;'
        'padding:8px 12px;font:12px/1.4 system-ui,sans-serif;display:flex;gap:10px;align-items:center;'
        'flex-wrap:wrap;border-bottom:1px solid #334155">'
        '<b style="color:#fbbf24">CAPS Open</b><span style="opacity:.8">bot cookie/UA</span>'
        '<a style="color:#38bdf8;font-weight:700" href="%sfaucet.php">Faucet</a>'
        '<a style="color:#38bdf8;font-weight:700" href="%sdice.php">Dice</a>'
        '<a style="color:#38bdf8;font-weight:700" href="%saccount.php">Account</a>'
        '<a style="color:#38bdf8;font-weight:700" href="%sdeposit.php">Deposit</a>'
        '<a style="color:#38bdf8;font-weight:700" href="%swithdraw.php">Withdraw</a>'
        '<a style="color:#38bdf8;font-weight:700" href="%ssettings.php">Settings</a>'
        '</div>'
    ) % (base, base, base, base, base, base)
    out = html
    if re.search(r"<body[^>]*>", out, re.I):
        out = re.sub(r"(<body[^>]*>)", r"\1" + bar, out, count=1, flags=re.I)
    elif re.search(r"<head[^>]*>", out, re.I):
        out = re.sub(r"(<head[^>]*>)", r"\1" + bar, out, count=1, flags=re.I)
    else:
        out = bar + out

    asset_ext = (".css", ".js", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".woff", ".woff2", ".ico", ".map")

    def _sub_abs(m):
        attr = m.group(1)
        u = m.group(2)
        if not u.startswith(host_bare):
            return m.group(0)
        rel = u[len(host_bare):].lstrip("/")
        low = rel.lower()
        if any(low.endswith(ext) for ext in asset_ext) or "assets/" in low:
            return m.group(0)
        return attr + '="' + base + rel + '"'

    out = re.sub(r'(href|src|action)="(https?://[^"]+)"', _sub_abs, out, flags=re.I)
    out = re.sub(r"(href|src|action)='(https?://[^']+)'", _sub_abs, out, flags=re.I)

    def _sub_rel(m):
        attr = m.group(1)
        rel = m.group(2)
        low = rel.lower()
        if any(low.endswith(ext) for ext in asset_ext) or low.startswith("assets/"):
            return attr + '="' + host_bare + '/' + rel.lstrip('/') + '"'
        return attr + '="' + base + rel + '"'

    out = re.sub(r'(href|src|action)="/(?!/)([^"]*)"', _sub_rel, out, flags=re.I)
    out = re.sub(r"(href|src|action)='/(?!/)([^']*)'", _sub_rel, out, flags=re.I)
    return out



def dice_status(aid: int) -> dict:
    st = dict(DICE_JOBS.get(aid) or {})
    acc = get_account(aid) or {}
    st.setdefault("running", False)
    st.setdefault("bets", 0)
    st.setdefault("wins", 0)
    st.setdefault("losses", 0)
    st.setdefault("profit", 0.0)
    st.setdefault("wager", 0.0)
    st.setdefault("balance", acc.get("balance"))
    st.setdefault("msg", "")
    st.setdefault("last", "")
    st["level"] = acc.get("level")
    st["wager_pct"] = acc.get("wager_pct")
    return st


def dice_stop(aid: int) -> dict:
    st = DICE_JOBS.get(aid)
    if st is not None:
        st["stop"] = True
        st["running"] = False
        st["msg"] = "stopped"
    return dice_status(aid)



def dice_start(aid: int, opts: dict | None = None) -> dict:
    """Auto dice — profil sozlamalari bilan. Thread xavfsiz (acc shadow yo'q)."""
    acc0 = get_account(aid)
    if not acc0:
        return {"ok": False, "error": "not found"}
    try:
        sync_cookie_from_disk(acc0)
        acc0 = get_account(aid) or acc0
    except Exception:
        pass
    if DICE_JOBS.get(aid, {}).get("running"):
        return {"ok": True, "msg": "already running", **dice_status(aid)}

    opts = opts or {}
    def _f(name, *alts, default=0.0):
        for k in (name,) + alts:
            if k in opts and opts[k] is not None and str(opts[k]).strip() != "":
                try:
                    return float(opts[k])
                except Exception:
                    pass
        return float(default)

    bet0 = max(1e-8, _f("bet_amount", "bet", default=0.0001))
    payout = max(1.01, min(_f("payout", "multiplier", default=2.0), 96.0))
    bet_on = (opts.get("bet_on") or opts.get("side") or "higher").lower()
    if bet_on not in ("higher", "lower"):
        try:
            roll = float(opts.get("roll") or 50)
            bet_on = "higher" if roll >= 50 else "lower"
        except Exception:
            bet_on = "higher"
    on_win = (opts.get("on_win") or "reset").lower()
    on_loss = (opts.get("on_loss") or "increase").lower()
    win_inc = _f("win_increase", default=100) / 100.0
    loss_inc = _f("loss_increase", default=100) / 100.0
    stop_profit = _f("stop_profit", default=0)
    stop_loss = _f("stop_loss", default=0)
    try:
        max_bets = int(opts.get("max_bets") or 500)
    except Exception:
        max_bets = 500

    st = {
        "running": True,
        "stop": False,
        "bets": 0,
        "wins": 0,
        "losses": 0,
        "profit": 0.0,
        "wager": 0.0,
        "balance": acc0.get("balance"),
        "msg": "starting",
        "last": "",
        "bet": bet0,
        "payout": payout,
        "side": bet_on,
        "last_roll": None,
        "threshold": None,
        "win_chance": None,
        "won": None,
    }
    DICE_JOBS[aid] = st

    def _run():
        import json as _json
        st["msg"] = "connecting…"
        acc = get_account(aid) or acc0
        try:
            try:
                sync_cookie_from_disk(acc)
                acc = get_account(aid) or acc
            except Exception as e:
                st["msg"] = "cookie sync: " + str(e)[:40]
            s = _acc_session(acc)
            host = _host_for(acc)
            bet = float(bet0)
            base_bet = float(bet0)
            profit = 0.0
            page = ""

            st["msg"] = "dice.php…"
            try:
                pr = s.get(host + "dice.php", timeout=25, allow_redirects=True)
                page = pr.text or ""
                url_l = (pr.url or "").lower()
                body_l = page.lower()
                ck = (acc.get("cookie") or "")
                logged_out = (
                    ("user_session=" not in ck and "remember_token=" not in ck)
                    or "login.php" in url_l
                    or ("sign in" in body_l and "bet_amount" not in body_l and "user_balance" not in body_l)
                )
                if logged_out:
                    st["msg"] = "login…"
                    if acc.get("email") and acc.get("password"):
                        ok_l = False
                        try:
                            ok_l = bool(_login_session_for_deposit(acc, s, host))
                        except Exception as e:
                            st["msg"] = "login err: " + str(e)[:50]
                        acc = get_account(aid) or acc
                        s = _acc_session(acc)
                        pr = s.get(host + "dice.php", timeout=25, allow_redirects=True)
                        page = pr.text or ""
                        if "login.php" in (pr.url or "").lower() and not ok_l:
                            st["msg"] = "session yo'q — cookie/login"
                            return
                    else:
                        st["msg"] = "cookie yo'q — email/parol kerak"
                        return
            except Exception as e:
                st["msg"] = "dice.php: " + str(e)[:60]
                try:
                    page = s.get(host + "faucet.php", timeout=25).text or ""
                except Exception:
                    page = ""

            csrf = _parse_csrf(page, s)
            if not csrf:
                try:
                    for c in s.cookies:
                        if c.name == "csrf_cookie_name" and c.value:
                            csrf = c.value
                            break
                except Exception:
                    pass
            if not csrf:
                st["msg"] = "csrf topilmadi — refresh/login"
                # baribir urinish

            # balance from page
            try:
                for pat in (
                    r'user_balance\s*=\s*([0-9.]+)',
                    r'class=["\'][^"\']*user_balance[^"\']*["\'][^>]*>([0-9.]+)',
                ):
                    mm = re.search(pat, page or "", re.I)
                    if mm:
                        st["balance"] = float(mm.group(1))
                        break
            except Exception:
                pass

            st["msg"] = "ready"
            for _n in range(max(1, max_bets)):
                if st.get("stop"):
                    st["msg"] = "stopped"
                    break
                # stop rules
                if stop_profit > 0 and profit >= stop_profit:
                    st["msg"] = "stop profit"
                    break
                if stop_loss > 0 and profit <= -abs(stop_loss):
                    st["msg"] = "stop loss"
                    break
                if bet < 1e-12:
                    bet = base_bet

                # csrf refresh every few bets
                if _n == 0 or _n % 8 == 0 or not csrf:
                    try:
                        pr = s.get(host + "dice.php", timeout=20)
                        page = pr.text or page
                        csrf = _parse_csrf(page, s) or csrf
                        if "login.php" in (pr.url or "").lower():
                            st["msg"] = "session expired"
                            break
                    except Exception:
                        pass

                st["msg"] = "betting #%d…" % (int(st.get("bets") or 0) + 1)
                post = {
                    "action": "bet_game_dice",
                    "bet_amount": ("%.8f" % bet).rstrip("0").rstrip(".") if bet >= 0.0001 else ("%.8f" % bet),
                    "payout": str(payout),
                    "bet_on": bet_on if bet_on in ("higher", "lower") else "higher",
                    "csrf_test_name": csrf or "",
                }
                # ensure 8 decimals format
                post["bet_amount"] = "%.8f" % float(bet)

                try:
                    r = s.post(
                        host + "process.php",
                        data=post,
                        timeout=35,
                        headers={
                            "Referer": host + "dice.php",
                            "Origin": host.rstrip("/"),
                            "X-Requested-With": "XMLHttpRequest",
                            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                            "Accept": "application/json, text/javascript, */*; q=0.01",
                        },
                    )
                    raw = (r.text or "").strip()
                except Exception as e:
                    st["msg"] = "net: " + str(e)[:50]
                    st["last"] = str(e)[:80]
                    time.sleep(1.5)
                    continue

                j = {}
                # JSON (boshida yoki ichida)
                if "{" in raw:
                    try:
                        i0 = raw.find("{")
                        j, _ = _json.JSONDecoder().raw_decode(raw[i0:])
                    except Exception:
                        try:
                            j = _json.loads(raw)
                        except Exception:
                            j = {}
                low = raw.lower()
                is_html = (not j) and (
                    raw.startswith("<!") or "<html" in low or "<title>error</title>" in low
                    or "something went wrong" in low
                )
                if is_html or (not j and "login" in low):
                    # CSRF / session yangilash
                    st["msg"] = "csrf/session yangilanmoqda…"
                    try:
                        if acc.get("email") and acc.get("password"):
                            try:
                                _login_session_for_deposit(acc, s, host)
                            except Exception:
                                pass
                        pr = s.get(host + "dice.php", timeout=25, allow_redirects=True)
                        page = pr.text or ""
                        csrf = _parse_csrf(page, s) or csrf
                        try:
                            for c in s.cookies:
                                if c.name == "csrf_cookie_name" and c.value:
                                    csrf = c.value
                        except Exception:
                            pass
                        try:
                            cur = _session_cookie_string(s)
                            if cur:
                                _persist_cookie(get_account(aid) or acc, cur)
                                acc = get_account(aid) or acc
                                s = _acc_session(acc)
                        except Exception:
                            pass
                    except Exception as e:
                        st["msg"] = "refresh: " + str(e)[:40]
                    st["last"] = "HTML error — retry"
                    time.sleep(1.2 + random.random())
                    continue

                if not j:
                    st["msg"] = "bo'sh javob"
                    time.sleep(1.0)
                    continue

                mes = str(j.get("mes") or j.get("message") or "")
                ret = j.get("ret")
                # nested data
                data = j.get("data") if isinstance(j.get("data"), dict) else j

                # balance — faqat JSON maydonlardan, HTML/xato sonlardan EMAS
                prev_bal = st.get("balance")
                try:
                    prev_bal = float(prev_bal) if prev_bal is not None else None
                except Exception:
                    prev_bal = None
                bal = prev_bal
                for k in ("balance", "user_balance", "new_balance", "bal"):
                    if k in data and data[k] is not None and str(data[k]).strip() != "":
                        try:
                            cand = float(data[k])
                            # faucet realist: 0..1e6
                            if 0 <= cand < 1_000_000:
                                bal = cand
                                break
                        except Exception:
                            pass
                # mes dan faqat oddiy "balance: 0.12" format
                if bal is None or (prev_bal is not None and bal == prev_bal):
                    mbal = re.search(r'(?:balance|bal)[^0-9]{0,12}([0-9]+\.[0-9]{4,12})', mes, re.I)
                    if mbal:
                        try:
                            cand = float(mbal.group(1))
                            if 0 <= cand < 1_000_000:
                                bal = cand
                        except Exception:
                            pass

                # win/loss
                won = None
                low = mes.lower()
                if "congrat" in low or "you win" in low or re.search(r"\byou won\b", low):
                    won = True
                if "lose" in low or "loss" in low or "not win" in low or "you lost" in low:
                    won = False
                # explicit fields
                for k in ("win", "is_win", "won", "result"):
                    if k in data:
                        v = data[k]
                        if v in (True, 1, "1", "win", "WIN"):
                            won = True
                        elif v in (False, 0, "0", "lose", "LOSS", "loss"):
                            won = False
                # profit delta
                delta = None
                for k in ("profit", "win_amount", "amount", "payoff"):
                    if k in data and data[k] is not None:
                        try:
                            delta = float(data[k])
                            break
                        except Exception:
                            pass
                if delta is None and isinstance(bal, (int, float)) and st.get("balance") is not None:
                    try:
                        delta = float(bal) - float(st["balance"])
                    except Exception:
                        delta = None
                if won is None and delta is not None:
                    if delta > 1e-12:
                        won = True
                    elif delta < -1e-12:
                        won = False

                if won is True:
                    st["wins"] = int(st.get("wins") or 0) + 1
                    if delta is None:
                        delta = bet * (payout - 1.0)
                    profit += float(delta)
                    if on_win == "increase":
                        bet = bet * (1.0 + win_inc)
                    else:
                        bet = base_bet
                elif won is False:
                    st["losses"] = int(st.get("losses") or 0) + 1
                    if delta is None:
                        delta = -bet
                    profit += float(delta)
                    if on_loss == "increase":
                        bet = bet * (1.0 + loss_inc)
                    else:
                        bet = base_bet
                else:
                    # noaniq — bet o'zgarmasin, lekin urinish sanalsin
                    if delta is not None:
                        profit += float(delta)

                # roll display
                roll_v = data.get("roll") or data.get("number") or data.get("result_number")
                try:
                    roll_v = float(roll_v) if roll_v is not None else None
                except Exception:
                    roll_v = None
                wc = max(0.5, min(98.0, 99.0 / payout))
                thr = round(100.0 - wc, 2) if bet_on == "higher" else round(wc, 2)
                st["win_chance"] = round(wc, 2)
                st["threshold"] = thr
                st["last_roll"] = roll_v
                st["won"] = won
                st["payout"] = payout
                st["side"] = bet_on
                st["bet"] = bet
                st["bets"] = int(st.get("bets") or 0) + 1
                st["wager"] = float(st.get("wager") or 0) + float(post["bet_amount"])
                st["profit"] = profit
                if bal is not None:
                    st["balance"] = bal
                st["last"] = (mes or ("WIN" if won else ("LOSS" if won is False else "?")))[:60]
                st["msg"] = "#%d %s bet=%.6g" % (
                    st["bets"],
                    "W" if won else ("L" if won is False else "?"),
                    float(post["bet_amount"]),
                )

                if j.get("csrf"):
                    csrf = str(j.get("csrf"))
                try:
                    for c in s.cookies:
                        if c.name == "csrf_cookie_name" and c.value:
                            csrf = c.value
                except Exception:
                    pass
                try:
                    cur = _session_cookie_string(s)
                    if cur:
                        _persist_cookie(get_account(aid) or acc, cur)
                except Exception:
                    pass

                # error mes that should stop
                if re.search(r"insufficient|not enough|minimum|invalid|login|captcha|forbidden", mes, re.I):
                    if re.search(r"insufficient|not enough balance", mes, re.I):
                        st["msg"] = "balans yetarli emas"
                        break
                    if re.search(r"login|session", mes, re.I):
                        st["msg"] = "session: " + mes[:40]
                        break

                time.sleep(0.35 + random.random() * 0.55)

            if not st.get("msg") or st["msg"] in ("starting", "connecting…", "ready"):
                st["msg"] = "done"
            try:
                nb = sticky_balance((get_account(aid) or acc).get("balance"), st.get("balance"))
                kw = {"last_msg": "dice %sb" % st.get("bets")}
                if nb is not None:
                    kw["balance"] = nb
                update_account(aid, **kw)
            except Exception:
                pass
        except Exception as e:
            st["msg"] = "err: " + str(e)[:70]
            st["last"] = str(e)[:100]
        finally:
            st["running"] = False

    import threading
    t = threading.Thread(target=_run, daemon=True, name="dice-%s" % aid)
    _dice_threads[aid] = t
    t.start()
    return {"ok": True, "msg": "dice started", **dice_status(aid)}


